<?php return array('dependencies' => array('wp-polyfill'), 'version' => '9fa37d655c3fbf877279');
