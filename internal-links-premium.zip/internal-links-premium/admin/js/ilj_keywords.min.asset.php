<?php return array('dependencies' => array('wp-polyfill'), 'version' => '2126e39dd30fb30e39f2');
