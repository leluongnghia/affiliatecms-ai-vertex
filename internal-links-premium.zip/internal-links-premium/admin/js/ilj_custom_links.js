/*!******************************************!*\
  !*** ./src/admin/js/ilj_custom_links.js ***!
  \******************************************/
(function ($) {
  $(function () {
    $('.ilj-menu-settings #post_status').ilj_select2({
      minimumResultsForSearch: 10,
      width: '30%'
    });
    $('#save-post').on('click', function () {
      var $spinner = jQuery(this).siblings('.spinner');
      var url_length = jQuery('input[name="ilj_custom_link_url"]').val().length;
      if (url_length !== 0) {
        $spinner.css('visibility', 'visible');
      }
    });
  });
})(jQuery);
