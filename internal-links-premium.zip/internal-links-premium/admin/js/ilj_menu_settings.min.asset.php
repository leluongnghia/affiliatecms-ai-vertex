<?php return array('dependencies' => array('wp-polyfill'), 'version' => 'newversion123');
