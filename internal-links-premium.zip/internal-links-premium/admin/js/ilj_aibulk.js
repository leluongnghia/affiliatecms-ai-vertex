jQuery(document).ready(function ($) {
  if (window.ilj_aibulk_initialized) {
    return;
  }
  window.ilj_aibulk_initialized = true;

  if ($('.ilj-select2').length) {
    $('.ilj-select2').select2({
      placeholder: 'Select options',
      allowClear: true
    });
  }

  var postsToProcess = [];
  var currentIndex = 0;
  var successCount = 0;
  var failedCount = 0;
  var isStopped = false;
  var bulkMode = 'no_keywords';
  var retryCounts = {};

  function appendLog(message, type) {
    var color = '#00ff00';
    if (type === 'error') {
      color = '#ff3333';
    } else if (type === 'info') {
      color = '#3399ff';
    } else if (type === 'warn') {
      color = '#ffcc00';
    }
    var time = new Date().toLocaleTimeString();
    var logLine = $('<div>').html('[' + time + '] ' + message).css('color', color);
    $('#ilj-bulk-log').append(logLine);
    var logDiv = document.getElementById('ilj-bulk-log');
    if (logDiv) {
      logDiv.scrollTop = logDiv.scrollHeight;
    }
  }

  function updateProgress() {
    var total = postsToProcess.length;
    var processed = currentIndex;
    var percentage = total > 0 ? Math.round((processed / total) * 100) : 0;

    $('#ilj-bulk-progress-bar').css('width', percentage + '%');
    $('#ilj-bulk-percentage').text(percentage + '%');
    $('#ilj-bulk-processed-count').text(processed);
    $('#ilj-bulk-success-count').text(successCount);
    $('#ilj-bulk-failed-count').text(failedCount);
  }

  function isTransientError(errorMsg) {
    var msg = (errorMsg || '').toLowerCase();
    return msg.indexOf('429') !== -1 ||
         msg.indexOf('resource_exhausted') !== -1 ||
         msg.indexOf('rate limit') !== -1 ||
         msg.indexOf('quota') !== -1 ||
         msg.indexOf('timed out') !== -1 ||
         msg.indexOf('timeout') !== -1 ||
         msg.indexOf('curl error 28') !== -1 ||
         msg.indexOf('curl error 6') !== -1 ||
         msg.indexOf('curl error 7') !== -1 ||
         msg.indexOf('502') !== -1 ||
         msg.indexOf('503') !== -1 ||
         msg.indexOf('504') !== -1;
  }

  function processNextPost() {
    if (isStopped) {
      appendLog('Bulk generation paused by user.', 'warn');
      $('#ilj-start-bulk-ai').prop('disabled', false).text('Resume Bulk Generation');
      $('#ilj-stop-bulk-ai').prop('disabled', true);
      return;
    }

    if (currentIndex >= postsToProcess.length) {
      appendLog('All posts processed successfully!', 'info');
      $('#ilj-bulk-current-post-info').text('Completed!');
      $('#ilj-start-bulk-ai').prop('disabled', false).text('Start Bulk Generation');
      $('#ilj-stop-bulk-ai').prop('disabled', true);
      return;
    }

    var currentPost = postsToProcess[currentIndex];
    $('#ilj-bulk-current-post-info').html('Processing ID <strong>' + currentPost.ID + '</strong>: ' + currentPost.post_title);
    appendLog('Sending request for post: "' + currentPost.post_title + '"...', 'info');

    $.ajax({
      url: ilj_aibulk_data.ajax_url,
      type: 'POST',
      data: {
        action: 'ilj_ai_bulk_process_post',
        post_id: currentPost.ID,
        mode: bulkMode,
        nonce: ilj_aibulk_data.nonce
      },
      success: function (response) {
        if (response.success) {
          if (response.data.skipped) {
            appendLog('Skipped post "' + currentPost.post_title + '" (already has keywords).', 'warn');
          } else {
            successCount++;
            appendLog('Successfully generated keywords for "' + currentPost.post_title + '": ' + response.data.keywords, 'success');
          }
          delete retryCounts[currentPost.ID];
          currentIndex++;
          updateProgress();
          setTimeout(processNextPost, 1000);
        } else {
          var errorMsg = response.data || 'Unknown error';
          if (isTransientError(errorMsg)) {
            var retries = retryCounts[currentPost.ID] || 0;
            if (retries < 3) {
              retryCounts[currentPost.ID] = retries + 1;
              var delayTime = (errorMsg.indexOf('429') !== -1 || errorMsg.indexOf('RESOURCE_EXHAUSTED') !== -1 || errorMsg.toLowerCase().indexOf('rate limit') !== -1) ? 20000 : 15000;
              appendLog('Transient error for "' + currentPost.post_title + '" (' + errorMsg + '). Retrying in ' + (delayTime / 1000) + ' seconds... (Attempt ' + (retries + 1) + '/3)', 'warn');
              setTimeout(processNextPost, delayTime);
            } else {
              delete retryCounts[currentPost.ID];
              failedCount++;
              appendLog('Failed for "' + currentPost.post_title + '" after 3 attempts: ' + errorMsg, 'error');
              currentIndex++;
              updateProgress();
              setTimeout(processNextPost, 1000);
            }
          } else {
            delete retryCounts[currentPost.ID];
            failedCount++;
            appendLog('Failed for "' + currentPost.post_title + '": ' + errorMsg, 'error');
            currentIndex++;
            updateProgress();
            setTimeout(processNextPost, 1000);
          }
        }
      },
      error: function (xhr, status, error) {
        var errorMsg = error || 'Unknown network error';
        if (isTransientError(errorMsg) || xhr.status === 429 || xhr.status === 502 || xhr.status === 503 || xhr.status === 504) {
          var retries = retryCounts[currentPost.ID] || 0;
          if (retries < 3) {
            retryCounts[currentPost.ID] = retries + 1;
            var delayTime = (xhr.status === 429) ? 20000 : 15000;
            appendLog('Network error for "' + currentPost.post_title + '" (' + errorMsg + '). Retrying in ' + (delayTime / 1000) + ' seconds... (Attempt ' + (retries + 1) + '/3)', 'warn');
            setTimeout(processNextPost, delayTime);
          } else {
            delete retryCounts[currentPost.ID];
            failedCount++;
            appendLog('Network error for "' + currentPost.post_title + '" after 3 attempts: ' + errorMsg, 'error');
            currentIndex++;
            updateProgress();
            setTimeout(processNextPost, 1000);
          }
        } else {
          delete retryCounts[currentPost.ID];
          failedCount++;
          appendLog('Network error for "' + currentPost.post_title + '": ' + errorMsg, 'error');
          currentIndex++;
          updateProgress();
          setTimeout(processNextPost, 1000);
        }
      }
    });
  }

  $('#ilj-start-bulk-ai').on('click', function (e) {
    e.preventDefault();

    var postTypes = $('#ilj-bulk-post-types').val();
    bulkMode = $('#ilj-bulk-mode').val();

    if (!postTypes || postTypes.length === 0) {
      alert('Please select at least one post type.');
      return;
    }

    // If resuming from pause
    if (isStopped && postsToProcess.length > 0 && currentIndex < postsToProcess.length) {
      isStopped = false;
      $('#ilj-start-bulk-ai').prop('disabled', true).text('Processing...');
      $('#ilj-stop-bulk-ai').prop('disabled', false);
      appendLog('Resuming bulk generation...', 'info');
      processNextPost();
      return;
    }

    $('#ilj-start-bulk-ai').prop('disabled', true).text('Analyzing database...');
    $('#ilj-bulk-log').empty();
    appendLog('Scanning database for matching posts...', 'info');

    $.ajax({
      url: ilj_aibulk_data.ajax_url,
      type: 'POST',
      data: {
        action: 'ilj_ai_bulk_get_posts',
        post_types: postTypes,
        mode: bulkMode,
        nonce: ilj_aibulk_data.nonce
      },
      success: function (response) {
        if (response.success) {
          postsToProcess = response.data.posts;
          currentIndex = 0;
          successCount = 0;
          failedCount = 0;
          isStopped = false;

          $('#ilj-bulk-total-count').text(postsToProcess.length);
          updateProgress();

          if (postsToProcess.length === 0) {
            appendLog('No matching posts found to process.', 'warn');
            $('#ilj-start-bulk-ai').prop('disabled', false).text('Analyze & Start Bulk Generation');
            return;
          }

          $('#ilj-bulk-progress-area').slideDown();
          $('#ilj-stop-bulk-ai').prop('disabled', false);
          $('#ilj-start-bulk-ai').text('Processing...');
          appendLog('Found ' + postsToProcess.length + ' posts to process. Starting batch run...', 'info');
          processNextPost();
        } else {
          alert('Error: ' + (response.data || 'Failed to fetch posts.'));
          $('#ilj-start-bulk-ai').prop('disabled', false).text('Analyze & Start Bulk Generation');
        }
      },
      error: function (xhr, status, error) {
        alert('Network error: ' + error);
        $('#ilj-start-bulk-ai').prop('disabled', false).text('Analyze & Start Bulk Generation');
      }
    });
  });

  $('#ilj-stop-bulk-ai').on('click', function (e) {
    e.preventDefault();
    isStopped = true;
    appendLog('Stopping process after current post finishes...', 'warn');
    $('#ilj-stop-bulk-ai').prop('disabled', true).text('Stopping...');
  });
});
