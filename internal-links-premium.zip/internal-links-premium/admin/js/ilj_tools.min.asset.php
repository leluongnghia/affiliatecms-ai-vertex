<?php return array('dependencies' => array('wp-polyfill'), 'version' => 'c66e13e573cf3fd92e99');
