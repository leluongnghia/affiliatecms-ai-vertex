/*!*********************************************!*\
  !*** ./src/admin/js/ilj-keywords-editor.js ***!
  \*********************************************/
jQuery(function ($) {
  // Debounce the events emitted from select2 input, to prevent multiple ajax calls.
  function debounce(func, delay) {
    var timeout_id;
    return function () {
      var context = this;
      var args = arguments;
      clearTimeout(timeout_id);
      timeout_id = setTimeout(function () {
        func.apply(context, args);
      }, delay);
    };
  }
  function check_keyword_duplicate(e, current_element) {
    // Get the full comma-separated value
    var all_values = $(current_element).val();
    // Check if it's an array (multiple select) or a single value
    var last_keyword;
    if (Array.isArray(all_values)) {
      last_keyword = all_values[all_values.length - 1]; // Get the last keyword in the array
    } else if ('string' === typeof all_values) {
      // Handle as a single comma-separated string
      var keywords_array = all_values.split(',');
      last_keyword = keywords_array[keywords_array.length - 1].trim();
    } else {
      console.error("Unexpected value type: ", typeof all_values);
      return;
    }
    var item_id = $(current_element).data('ilj-item-id');
    var item_type = $(current_element).data('ilj-item-type');

    // Check for duplicate function
    if (null != last_keyword) {
      var data = {
        'action': 'ilj_check_duplicate_keyword',
        'keyword': last_keyword,
        'nonce': ilj_editor_duplicate.nonce,
        'item-id': item_id,
        'item-type': item_type
      };
      $.ajax({
        url: ajaxurl,
        type: "POST",
        data: data,
        statusCode: {
          500: function (xhr) {
            if (!"responseJSON" in xhr || !["success", "error"].includes(xhr.responseJSON.status)) {
              return;
            }
          }
        },
        success: function (data, textStatus, xhr) {
          if (false == data) {
            return false;
          } else {
            $(e.currentTarget).closest('tr').find('.ilj-duplicate-notice').html(data);
            $(e.currentTarget).closest('tr').find('.ilj-duplicate-notice').show();
          }
        }
      });
    }
  }
  $('.ilj-keywords-editor-select-box').ilj_select2({
    minimumResultsForSearch: 10,
    width: '50%',
    tags: true,
    tokenSeparators: [',']
  });
  var handle_option_change = debounce(function (e, is_select) {
    var selected_values = [];
    if (is_select) {
      check_keyword_duplicate(e, this);
    }
    $(e.currentTarget).find('option:selected').each(function () {
      selected_values.push($(this).val());
    });

    /**
     * The current version of select2 loses focus when the option is selected, so we need to
     * set focus on search field again.
     * @see https://github.com/select2/select2/issues/5185
     */
    $(e.currentTarget).next('.ilj-select2-container').find('.ilj-select2-search__field').focus();
    var spinner = $(e.currentTarget).closest('tr').find('.spinner');
    spinner.addClass('is-active');
    $.ajax({
      url: $(e.currentTarget).data('iljSaveUrl'),
      type: 'POST',
      data: {
        keywords: selected_values
      }
    }).always(function () {
      spinner.removeClass('is-active');
    });
  }, 100);

  // Attach the event handlers with specific parameters for select and unselect
  $('.ilj-keywords-editor-select-box').on('select2:select', function (e) {
    handle_option_change.call(this, e, true);
  });
  $('.ilj-keywords-editor-select-box').on('select2:unselect', function (e) {
    handle_option_change.call(this, e, false);
  });
  $('.ilj-keywords-editor-select-box').on('select2:unselect', function (e) {
    var unselected_tag = e.params.data.id;

    // Remove the unselected tag from the dropdown options
    var select_box = $(this);
    var options = select_box.find('option[value="' + unselected_tag + '"]');
    options.remove();

    // Ensure the unselected tag is completely removed from the value list
    var current_values = select_box.val() || [];
    var new_values = current_values.filter(value => value !== unselected_tag);
    select_box.val(new_values).trigger('change');
  });
  $(document).on('click', '.ilj-duplicate-details', function (event) {
    event.preventDefault(); // Prevent default behavior, if any
    event.stopPropagation(); // Stop propagation, if necessary

    var keyword = $(this).data('keyword');
    var duplicate_count = $(this).data('duplicate-count');
    var headline = ilj_editor_translation.keyword_duplicate_title;
    var title = keyword;
    var item_id = $(this).data('ilj-item-id');
    var item_type = $(this).data('ilj-item-type');
    var data = {
      'action': 'ilj_render_duplicate_keyword_details',
      'keyword': keyword,
      'nonce': ilj_editor_duplicate.nonce,
      'item-id': item_id,
      'item-type': item_type
    };
    $.ajax({
      url: ajaxurl,
      type: 'POST',
      data: data
    }).done(function (data) {
      ilj_create_modal(headline + ' "' + title + '" (' + duplicate_count + ')', $('<div/>').addClass('ilj-duplicates').html(data));
    });
  });

  /**
   * Dismiss the notice
   */
  $(document).on('click', '.ilj-dismiss-notice', function () {
    $(this).closest('.ilj-duplicate-notice').hide();
  });
});
