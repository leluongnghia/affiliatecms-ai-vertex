<?php
namespace ILJ\Enumeration;

/**
 * Enum for TagExclusion
 *
 * @package ILJ\Enumerations
 * @since   1.1.1
 */
final class TagExclusion {

	const HEADLINE       = 'tag_headlines';
	const STRONG         = 'tag_strong';
	const DIV            = 'tag_div';
	const TABLE          = 'tag_table';
	const CAPTION        = 'tag_caption';
	const ORDERED_LIST   = 'tag_ordered_list';
	const UNORDERED_LIST = 'tag_unordered_list';
	const BLOCKQUOTE     = 'tag_blockquote';
	const ITALIC         = 'tag_italic';
	const CITE           = 'tag_cite';
	const CODE           = 'tag_code';

	/**
	 * Returns all enumeration values
	 *
	 * @since  1.1.1
	 * @return array
	 */
	public static function getValues() {
		$reflectionClass = new \ReflectionClass(static::class);
		return $reflectionClass->getConstants();
	}

	/**
	 * Translate enum to natural language
	 *
	 * @since  1.1.1
	 * @param  string $value The enum value
	 * @return string
	 */
	public static function translate($value) {
		switch ($value) {
			case self::HEADLINE:
				return htmlentities(__('Tiêu đề', 'internal-links') . ' (<h1-6>)');
			case self::STRONG:
				return htmlentities(__('Văn bản mạnh mẽ', 'internal-links') . ' (<strong>, <b>)');
			case self::DIV:
				return htmlentities(__('thùng chứa div', 'internal-links') . ' (<div>)');
			case self::TABLE:
				return htmlentities(__('Bàn', 'internal-links') . ' (<table>)');
			case self::CAPTION:
				return htmlentities(__('Chú thích hình ảnh', 'internal-links') . ' (<figcaption>)');
			case self::ORDERED_LIST:
				return htmlentities(__('Danh sách theo thứ tự', 'internal-links') . ' (<ol>)');
			case self::UNORDERED_LIST:
				return htmlentities(__('Danh sách không có thứ tự', 'internal-links') . ' (<ul>)');
			case self::BLOCKQUOTE:
				return htmlentities(__('Trích dẫn khối', 'internal-links') . ' (<blockquote>)');
			case self::ITALIC:
				return htmlentities(__('Văn bản in nghiêng', 'internal-links') . ' (<em>, <i>)');
			case self::CITE:
				return htmlentities(__('Dấu ngoặc kép nội tuyến', 'internal-links') . ' (<cite>)');
			case self::CODE:
				return htmlentities(__('Mã nguồn', 'internal-links') . ' (<code>)');
		}
		return 'N/A';
	}

	/**
	 * Returns the regex for the exclusion
	 *
	 * @since  1.1.1
	 * @param  string $deputy The name of the html area
	 * @return string|bool
	 */
	public static function getRegex($deputy) {
		if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			return self::getRegex__premium_only($deputy);
		}

		switch ($deputy) {
			case self::HEADLINE:
				return '/(?<parts><h[1-6]\b[^>]*>.*<\/h[1-6]>)/sU';
			case self::STRONG:
				return '/(?<parts><strong\b[^>]*>.*<\/strong>|<b\b[^>]*>.*<\/b>)/sU';
		}
		return false;
	}

	/**
	 * Returns the regex for the exclusion
	 *
	 * @since  1.1.1
	 * @param  string $deputy The name of the html area
	 * @return string|bool
	 */
	public static function getRegex__premium_only($deputy) {
		switch ($deputy) {
			case self::HEADLINE:
				return '/(?<parts><h[1-6]\b[^>]*>.*<\/h[1-6]>)/sU';
			case self::TABLE:
				return '/(?<parts><table\b[^>]*>.*<\/table>)/sU';
			case self::CAPTION:
				return '/(?<parts><figcaption\b[^>]*>.*<\/figcaption>)/sU';
			case self::DIV:
				return '/(?<parts><div\b[^>]*>.*<\/div>)/sU';
			case self::ORDERED_LIST:
				return '/(?<parts><ol\b[^>]*>.*<\/ol>)/sU';
			case self::UNORDERED_LIST:
				return '/(?<parts><ul\b[^>]*>.*<\/ul>)/sU';
			case self::BLOCKQUOTE:
				return '/(?<parts><blockquote\b[^>]*>.*<\/blockquote>)/sU';
			case self::STRONG:
				return '/(?<parts><strong\b[^>]*>.*<\/strong>|<b\b[^>]*>.*<\/b>)/sU';
			case self::ITALIC:
				return '/(?<parts><em\b[^>]*>.*<\/em>|<i\b[^>]*>.*<\/i>)/sU';
			case self::CITE:
				return '/(?<parts><cite\b[^>]*>.*<\/cite>)/sU';
			case self::CODE:
				return '/(?<parts><code\b[^>]*>.*<\/code>)/sU';
		}
		return false;
	}
}
