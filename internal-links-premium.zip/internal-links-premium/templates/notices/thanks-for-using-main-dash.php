<?php
if (!defined('ILJ_PATH')) die('No direct access allowed');
?>

<div id="ilj-dashnotice" class="updated">
	<div style="float: right;"><a href="#" onclick="jQuery('#ilj-dashnotice').slideUp(); jQuery.post(ajaxurl, {action: 'ilj_notice_dismiss', subaction: 'ilj_dismiss_dash_notice_until', nonce: '<?php echo esc_js(wp_create_nonce('ilj-notice-ajax-nonce')); ?>'});"><?php /* translators: %1s represents the notice dismiss 'month' value. */ printf(esc_html__('Loại bỏ (trong %s tháng)', 'internal-links'), 12); ?></a></div>
	<h3><?php esc_html_e('Cảm ơn bạn đã cài đặt Internal Link Juicer.', 'internal-links'); ?></h3>	

	<a href="https://www.internallinkjuicer.com/" target="_blank"><img id="ilj-notice-logo" alt="<?php esc_html_e('Máy ép trái cây liên kết nội bộ', 'internal-links'); ?>" title="<?php esc_html_e('Máy ép trái cây liên kết nội bộ', 'internal-links'); ?>" src="<?php echo esc_url(ILJ_URL . 'admin/img/plugin-logos/internal-link-juicer-logo-sm.png'); ?>"></a>
	<div id="aiowps-dashnotice_wrapper" style="max-width: 800px;">
		<p>
			<?php
				esc_html_e('Tự động hóa việc xây dựng các liên kết nội bộ trên trang web WordPress của bạn.', 'internal-links') . ' ' . esc_html_e('Tiết kiệm thời gian và tăng cường SEO.', 'internal-links') . ' ' . esc_html_e('Bạn không cần phải là chuyên gia SEO để sử dụng plugin này.', 'internal-links');
				echo '&nbsp;';
				esc_html_e('Nhận thêm các plugin được xếp hạng bên dưới:', 'internal-links');
			?>
		</p>
		<ul>
			<li>
				<a href="https://aiosplugin.com/" target="_blank"><strong><?php esc_html_e('Bảo mật tất cả trong một (AIOS)', 'internal-links'); ?>:</strong></a>
				<?php
					esc_html_e('Vẫn còn trên hàng rào?', 'internal-links');
					echo '&nbsp;';
					esc_html_e('Bảo mật trang web WordPress của bạn với AIOS.', 'internal-links');
					echo '&nbsp;';
					esc_html_e('Toàn diện, tiết kiệm chi phí, được đánh giá 5* và dễ sử dụng.', 'internal-links');
				?>
			</li>
			<li>
				<a href="https://getwpo.com/buy/" target="_blank"><strong><?php esc_html_e('Tối ưu hóa WP', 'internal-links'); ?>:</strong></a>
				<?php
					esc_html_e('Tăng tốc và tối ưu hóa trang web WordPress của bạn.', 'internal-links');
					echo '&nbsp;';
					esc_html_e('Lưu trữ trang web của bạn, làm sạch cơ sở dữ liệu và nén hình ảnh.', 'internal-links');
				?>
			</li>
			<li>
				<a href="https://teamupdraft.com/updraftplus/" target="_blank"><strong><?php esc_html_e('UpdraftPlus', 'internal-links'); ?>:</strong></a>
				<?php
					esc_html_e('Sao lưu trang web của bạn bằng plugin sao lưu và di chuyển hàng đầu thế giới.', 'internal-links');
					echo '&nbsp;';
					esc_html_e('Được cài đặt tích cực trên hơn 3 triệu trang web WordPress.', 'internal-links');
				?>
			</li>
			<li>
				<a href="https://wpgetapi.com" target="_blank"><strong><?php esc_html_e('WPGetAPI', 'internal-links'); ?>:</strong></a>
				<?php
					esc_html_e('Kết nối WordPress với các API bên ngoài mà không cần mã.', 'internal-links');
				?>
			</li>
			<li>
				<a href="https://wpovernight.com/" target="_blank"><strong><?php esc_html_e('WP qua đêm', 'internal-links'); ?>:</strong></a>
				<?php
					esc_html_e('Tiện ích bổ sung chất lượng cho WooC Commerce.', 'internal-links');
					echo '&nbsp;';
					esc_html_e('Được thiết kế để tối ưu hóa cửa hàng của bạn, nâng cao trải nghiệm người dùng và tăng doanh thu.', 'internal-links');
				?>
			</li>
		</ul>
	</div>
	<p>
		<strong><?php esc_html_e('Nhiều plugin chất lượng hơn', 'internal-links'); ?>: </strong><a href="https://www.simbahosting.co.uk/s3/shop/" target="_blank" ><?php esc_html_e('Plugin WooC Commerce cao cấp', 'internal-links'); ?></a>;
	</p>
	<div style="float: right;"><a href="#" onclick="jQuery('#ilj-dashnotice').slideUp(); jQuery.post(ajaxurl, {action: 'ilj_notice_dismiss', subaction: 'ilj_dismiss_dash_notice_until', nonce: '<?php echo esc_js(wp_create_nonce('ilj-notice-ajax-nonce')); ?>'});"><?php /* translators: %1s represents the notice dismiss 'month' value. */ printf(esc_html__('Loại bỏ (trong %s tháng)', 'internal-links'), 12); ?></a></div>
	<p>&nbsp;</p>
</div>
