<?php
namespace ILJ\Posttypes;

use ILJ\Core\Options;
use ILJ\Database\Postmeta;
use ILJ\Helper\Capabilities;
use ILJ\Helper\Help;
use ILJ\Helper\Options as OptionsHelper;

/**
 * Custom links posttype
 *
 * Handles the custom post type for custom links
 *
 * @package ILJ\Posttypes
 * @since   1.0.1
 */
class CustomLinks {

	const ILJ_POSTTYPE_CUSTOM_LINKS_SLUG           = 'ilj_customlinks';
	const ILJ_FIELD_CUSTOM_LINKS_URL               = 'ilj_custom_link_url';
	const ILJ_FIELD_CUSTOM_LINKS_OPTION_NOFOLLOW   = 'ilj_custom_link_option_nofollow';
	const ILJ_FIELD_CUSTOM_LINKS_OPTION_NEW_WINDOW = 'ilj_custom_link_option_new_window';

	protected function __construct() {
		$this->register();

		add_filter('manage_' . self::ILJ_POSTTYPE_CUSTOM_LINKS_SLUG . '_posts_columns', array($this, 'configureColumns'));

		add_filter('parent_file', array($this, 'keepMenu'));

		add_filter(
			'post_row_actions',
			function ($actions, $post) {
				if (self::ILJ_POSTTYPE_CUSTOM_LINKS_SLUG != $post->post_type) {
					return $actions;
				}

				if (isset($actions['inline hide-if-no-js'])) {
					unset($actions['inline hide-if-no-js']);
				}

				return $actions;
			},
			10,
			2
		);

		add_action('add_meta_boxes', array($this, 'addMetaboxes'));

		add_action('add_meta_boxes', array($this, 'cleanMetaboxes'), 99, 1);

		add_action('dbx_post_sidebar', array($this, 'nonce'));

		add_action(
			'save_post',
			array($this, 'savePost'),
			10,
			2
		);

		add_action(
			'manage_' . self::ILJ_POSTTYPE_CUSTOM_LINKS_SLUG . '_posts_custom_column',
			array($this, 'singleColumn'),
			10,
			2
		);

		add_filter(
			'post_row_actions',
			function ($actions, $post) {
				if (self::ILJ_POSTTYPE_CUSTOM_LINKS_SLUG == $post->post_type) {
					$url             = get_post_meta($post->ID, self::ILJ_FIELD_CUSTOM_LINKS_URL, true);
					$actions['open'] = sprintf('<a href="%s" target="_blank" rel="noopener noreferrer"><span class="dashicons dashicons-external"></span> %s</a>', esc_html($url), __('Mở URL', 'internal-links'));
				}

				return $actions;
			},
			10,
			2
		);

		add_action(
			'load-post-new.php',
			array(get_class($this), 'disable_autosave')
		);

		add_action(
			'load-post.php',
			array(get_class($this), 'disable_autosave')
		);

		add_action(
			'load-edit.php',
			array(get_class($this), 'customize_overview')
		);

		add_action(
			'admin_enqueue_scripts',
			function () {
				$current_screen = get_current_screen();

				if (self::ILJ_POSTTYPE_CUSTOM_LINKS_SLUG !== $current_screen->post_type) {
					return;
				}

				if ('edit' == $current_screen->base) {
					echo '
		            <style>
		            	th.column-new_window,
		            	th.column-nofollow {
  							width: 10%;
						}
						.dashicons.red {
							color: rgb(237, 73, 56);
						}
						.dashicons.green {
							color: rgb(173, 198, 7);
						}
					</style>
		        ';
				} elseif ('post' == $current_screen->base) {
					\ILJ\Helper\Loader::enqueue_script('ilj_select2', ILJ_URL . 'admin/js/select2.js', array(), ILJ_VERSION);
					\ILJ\Helper\Loader::enqueue_script(self::ILJ_POSTTYPE_CUSTOM_LINKS_SLUG, ILJ_URL . 'admin/js/ilj_custom_links.js', array(), ILJ_VERSION);
					\ILJ\Helper\Loader::enqueue_style('ilj_menu_settings', ILJ_URL . 'admin/css/ilj_menu_settings.css', array(), ILJ_VERSION);
					\ILJ\Helper\Loader::enqueue_style('ilj_select2', ILJ_URL . 'admin/css/select2.css', array(), ILJ_VERSION);
				}
			}
		);

		add_action(
			'admin_footer',
			function () {
				$current_screen = get_current_screen();

				if (!in_array($current_screen->base, array('edit', 'post')) || self::ILJ_POSTTYPE_CUSTOM_LINKS_SLUG != $current_screen->post_type) {
					return;
				}

				$url_manual = Help::getLinkUrl('custom-links/', null, 'edit', 'custom links');
				?>
				<script type="text/javascript">
					<?php if ('post' == $current_screen->base && 'add' == $current_screen->action) { ?>
					jQuery('h1.wp-heading-inline').after('<a href="<?php echo esc_js($url_manual);?>" target="_blank" rel="noopener" class="page-title-action"><?php esc_html_e('Giúp đỡ', 'internal-links'); ?></a>')
					<?php } else { ?>
					jQuery('.page-title-action').after('<a href="<?php echo esc_js($url_manual);?>" target="_blank" rel="noopener" class="page-title-action"><?php esc_html_e('Giúp đỡ', 'internal-links'); ?></a>');
					<?php } ?>
				</script>
				<?php
			},
			100
		);

		add_filter('post_updated_messages', array($this, 'custom_links_updated_messages'), 10, 1);
	}

	/**
	 * Init the post type
	 *
	 * @since  1.0.1
	 * @return CustomLinks
	 */
	public static function init() {
		 new self();
	}

	/**
	 * Registers the post type
	 *
	 * @since  1.0.1
	 * @return void
	 */
	protected function register() {
		$labels = array(
			'name'               => __('Liên kết tùy chỉnh', 'internal-links'),
			'singular_name'      => __('Liên kết tùy chỉnh', 'internal-links'),
			'add_new'            => __('Thêm liên kết', 'internal-links'),
			'all_items'          => __('Tất cả các liên kết', 'internal-links'),
			'add_new_item'       => __('Thêm liên kết', 'internal-links'),
			'edit_item'          => __('Chỉnh sửa liên kết', 'internal-links'),
			'new_item'           => __('Thêm liên kết', 'internal-links'),
			'search_items'       => __('Tìm kiếm liên kết', 'internal-links'),
			'not_found'          => __('Không tìm thấy liên kết', 'internal-links'),
			'not_found_in_trash' => __('Không tìm thấy liên kết', 'internal-links'),
			'menu_name'          => __('Liên kết tùy chỉnh', 'internal-links'),
		);

		$args = array(
			'label'               => __('Liên kết tùy chỉnh', 'internal-links'),
			'labels'              => $labels,
			'description'         => __('Liên kết tùy chỉnh để liên kết tự động.', 'internal-links'),
			'public'              => false,
			'show_ui'             => true,
			'show_in_menu'        => false,
			'menu_position'       => 110,
			'supports'            => array('title', 'ilj_editor', 'excerpt'),
			'exclude_from_search' => true,
			'has_archive'         => false,
		);

		register_post_type(
			self::ILJ_POSTTYPE_CUSTOM_LINKS_SLUG,
			$args
		);
	}

	/**
	 * Takes care of keeping navigation activated if editing a custom link
	 *
	 * @since  1.0.1
	 * @param  string $parent_file The parent file
	 * @return string
	 */
	public function keepMenu($parent_file) {
		global $plugin_page, $post_type, $submenu_file;

		if (self::ILJ_POSTTYPE_CUSTOM_LINKS_SLUG == $post_type) {
			$plugin_page = $submenu_file = 'edit.php?post_type=' . self::ILJ_POSTTYPE_CUSTOM_LINKS_SLUG;
		}

		return $parent_file;
	}

	/**
	 * Sets the columns in the custom links overview
	 *
	 * @since  1.0.1
	 * @param  array $columns An array of column name => label
	 * @return array
	 */
	public function configureColumns($columns) {
		unset($columns['author']);

		$columns['url']        = __('Mục tiêu liên kết', 'internal-links');
		$columns['nofollow']   = __('Không theo dõi', 'internal-links');
		$columns['new_window'] = __('Cửa sổ mới', 'internal-links');

		return $columns;
	}

	/**
	 * Renders the single value within an row/column entry within the custom link overview
	 *
	 * @since  1.0.1
	 * @param  string $column  The name of the column to display
	 * @param  int    $post_id The ID of the current post
	 * @return void
	 */
	public static function singleColumn($column, $post_id) {
		switch ($column) {
			case 'url':
			$url = get_post_meta($post_id, self::ILJ_FIELD_CUSTOM_LINKS_URL, true);
			if ($url) {
					echo esc_html($url);
			} else {
								esc_html_e('Không có URL nào được đặt.', 'internal-links');
			}
				break;
			case 'nofollow':
			$nofollow = get_post_meta($post_id, self::ILJ_FIELD_CUSTOM_LINKS_OPTION_NOFOLLOW, true);
			if ($nofollow) {
					echo '<span class="dashicons dashicons-yes-alt green"></span>';
			} else {
								echo '<span class="dashicons dashicons-dismiss red"></span>';
			}
				break;
			case 'new_window':
			$new_window = get_post_meta($post_id, self::ILJ_FIELD_CUSTOM_LINKS_OPTION_NEW_WINDOW, true);
			if ($new_window) {
					echo '<span class="dashicons dashicons-yes-alt green"></span>';
			} else {
								echo '<span class="dashicons dashicons-dismiss red"></span>';
			}
				break;
		}
	}

	/**
	 * Adds all the meta boxes to the custom links editor interface
	 *
	 * @since  1.0.1
	 * @return void
	 */
	public function addMetaboxes() {
		add_meta_box(
			'ilj-url',
			__('Mục tiêu', 'internal-links'),
			array($this, 'renderUrlBox'),
			self::ILJ_POSTTYPE_CUSTOM_LINKS_SLUG,
			'normal',
			'high'
		);

		add_meta_box(
			'ilj-link-options',
			__('Tùy chọn liên kết', 'internal-links'),
			array($this, 'renderLinkOptions'),
			self::ILJ_POSTTYPE_CUSTOM_LINKS_SLUG,
			'normal',
			'high'
		);

		add_meta_box(
			'ilj-submitdiv',
			__('Cứu', 'internal-links'),
			array($this, 'renderSubmitDiv'),
			self::ILJ_POSTTYPE_CUSTOM_LINKS_SLUG,
			'side',
			'low'
		);
	}

	/**
	 * Derigisters all unused stuff from the custom link interface
	 *
	 * @since  1.0.1
	 * @param  string $post_type The current post type
	 * @return void
	 */
	public function cleanMetaboxes($post_type) {
		$slug = self::ILJ_POSTTYPE_CUSTOM_LINKS_SLUG;

		$exceptions = array($slug, Postmeta::ILJ_META_KEY_LINKDEFINITION, 'ilj-url', 'ilj-link-options', 'ilj-submitdiv', 'postexcerpt');

		$exceptions = apply_filters('add_to_meta_box_exception', $exceptions);

		if ($post_type == $slug) {
			global $wp_meta_boxes;
			/**
			 * Loop through each page key of the '$wp_meta_boxes' global...
			 */
			if (!empty($wp_meta_boxes)) :
				foreach ($wp_meta_boxes as $page => $page_boxes) :
					/**
					 * Loop through each content...
					 */
					if (!empty($page_boxes)) :
						foreach ($page_boxes as $context => $box_context) :
							/**
							 * Loop through each type of meta box...
							 */
							if (!empty($box_context)) :
								foreach ($box_context as $box_type) :
									/**
									 * Loop through each individual box...
									 */
									if (!empty($box_type)) :
										foreach ($box_type as $id => $box) :
											/**
											 * Check to see if the meta box should be removed...
											 */
											if (!in_array($id, $exceptions)) :

												/**
												 * Remove the meta box
												 */
												remove_meta_box($id, $page, $context);
											endif;
										endforeach;
									endif;
								endforeach;
							endif;
						endforeach;
					endif;
				endforeach;
			endif;
		}
	}

	/**
	 * Generates the nonce field for the interface
	 *
	 * @since  1.0.1
	 * @return void
	 */
	public static function nonce() {
		wp_nonce_field(
			self::ILJ_POSTTYPE_CUSTOM_LINKS_SLUG,
			self::ILJ_POSTTYPE_CUSTOM_LINKS_SLUG,
			false
		);
	}

	/**
	 * Renders the submit box within the interface
	 *
	 * @since  1.0.1
	 * @param  WP_Post $post The post object
	 * @return void
	 */
	public function renderSubmitDiv($post) {
		$editor_capability = Capabilities::mapRoleToCapability(Options::getOption(\ILJ\Core\Options\EditorRole::getKey()));

		if (!current_user_can($editor_capability)) {
			echo '<p>' . esc_html__('Không có quyền chỉnh sửa liên kết.', 'internal-links') . '</p>';
			return;
		}
		?>
		<div id="major-publishing-action" style="margin:15px 0 10px 0;">
		<div id="save-action" style="display:inline-block;margin-right:15px;">
			<input type="submit" name="save" id="save-post" class="button button-primary" value="<?php esc_attr_e('Cứu', 'internal-links'); ?>">&nbsp;
			<div class="spinner"></div>
		</div>
		<?php
			$current_screen = get_current_screen();
			if ('add' != $current_screen->action) {
			$confirm_text = __('Bạn có chắc không?', 'internal-links');
			$delete_url = get_delete_post_link($post->ID);
			?>
				<div style="display:inline-block;">
					<a class="button button-secondary"
					   onclick="return confirm('<?php echo esc_js($confirm_text); ?>');"
						href="<?php echo esc_url($delete_url); ?>"
					   >
			<?php esc_html_e('Xóa bỏ', 'internal-links'); ?>
					</a>
				</div>
			<?php } ?>
		</div>
		<?php
	}

	/**
	 * Renders the url box within the interface
	 *
	 * @since  1.0.1
	 * @param  mixed $post
	 * @return void
	 */
	public function renderUrlBox($post) {
		 $url = get_post_meta(get_the_ID(), self::ILJ_FIELD_CUSTOM_LINKS_URL, true);
		?>
			<div class="ilj-menu-settings">
				<input type="hidden" name="hidden_post_status" id="hidden_post_status" value="draft">
				<table class="form-table">
					<tbody>
						<tr>
							<th scope="row">
								<label
									for="<?php esc_attr(self::ILJ_FIELD_CUSTOM_LINKS_URL); ?>"><?php esc_html_e('URL mục tiêu', 'internal-links'); ?></label>
							</th>
							<td>
								<input type="text"
									   style="width:70%;"
									   class="widefat"
									   name="<?php echo esc_attr(self::ILJ_FIELD_CUSTOM_LINKS_URL); ?>"
									   value="<?php echo esc_attr($url); ?>"
									   required="required"
									   placeholder="https://..."
								/>
								<p class="description"><?php esc_html_e('URL cần được liên kết.', 'internal-links'); ?></p>
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="post_status"><?php esc_html_e('Trạng thái liên kết', 'internal-links'); ?></label>
							</th>
							<td>
								<select name="post_status" id="post_status">
									<option value="publish" <?php selected($post->post_status, 'publish'); ?>>
										<?php esc_html_e('Tích cực', 'internal-links'); ?>
									</option>
									<option value="draft" <?php selected($post->post_status, 'draft'); ?>>
										<?php esc_html_e('Không hoạt động', 'internal-links'); ?>
									</option>
								</select>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
			<?php
	}

	/**
	 * Renders the link options box within the interface
	 *
	 * @since  1.0.1
	 * @param  mixed $post
	 * @return void
	 */
	public function renderLinkOptions($post) {
		$nofollow   = get_post_meta($post->ID, self::ILJ_FIELD_CUSTOM_LINKS_OPTION_NOFOLLOW, true);
		$new_window = get_post_meta($post->ID, self::ILJ_FIELD_CUSTOM_LINKS_OPTION_NEW_WINDOW, true);
		?>
		<div class="ilj-menu-settings">
			<table class="form-table">
				<tbody>
				<tr>
					<th scope="row">
						<label for="<?php echo esc_attr(self::ILJ_FIELD_CUSTOM_LINKS_OPTION_NOFOLLOW); ?>"><?php esc_html_e('Thêm thuộc tính nofollow', 'internal-links'); ?></label>
					</th>
					<td>
						<?php OptionsHelper::render_toggle_field(self::ILJ_FIELD_CUSTOM_LINKS_OPTION_NOFOLLOW, $nofollow, false); ?>
						<p class="description">
							<?php echo wp_kses(__('URL tùy chỉnh được liên kết với thuộc tính <code>rel="nofollow"</code>.', 'internal-links'), array('code' => array())); ?>
						</p>

					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="<?php echo esc_attr(self::ILJ_FIELD_CUSTOM_LINKS_OPTION_NEW_WINDOW); ?>"><?php esc_html_e('Mở trong cửa sổ mới', 'internal-links'); ?></label>
					</th>
					<td>
						<?php OptionsHelper::render_toggle_field(self::ILJ_FIELD_CUSTOM_LINKS_OPTION_NEW_WINDOW, $new_window, false); ?>
						<p class="description"><?php esc_html_e('Liên kết tới URL tùy chỉnh sẽ được mở trong tab mới.', 'internal-links'); ?></p>
					</td>
				</tr>
				</tbody>
			</table>
		</div>
		<?php
	}

	/**
	 * Handles the saving process of a custom link
	 *
	 * @since  1.0.1
	 * @param  int     $post_id The post id of the custom link
	 * @param  WP_Post $post    The post object of the custom link
	 * @return void
	 */
	public function savePost($post_id, $post) {
		$editor_capability = Capabilities::mapRoleToCapability(Options::getOption(\ILJ\Core\Options\EditorRole::getKey()));

		if ((self::ILJ_POSTTYPE_CUSTOM_LINKS_SLUG != $post->post_type)
			|| (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
			|| (!current_user_can($editor_capability))
			|| (!isset($_POST[self::ILJ_POSTTYPE_CUSTOM_LINKS_SLUG]) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST[self::ILJ_POSTTYPE_CUSTOM_LINKS_SLUG])), self::ILJ_POSTTYPE_CUSTOM_LINKS_SLUG))
		) {
			return;
		}

		// saving the url
		$url = (isset($_POST[self::ILJ_FIELD_CUSTOM_LINKS_URL])) ? sanitize_url(wp_unslash($_POST[self::ILJ_FIELD_CUSTOM_LINKS_URL])) : '';
		$url = filter_var($url, FILTER_SANITIZE_URL);

		if (!filter_var($url, FILTER_VALIDATE_URL)) {
			return;
		}

		update_post_meta($post_id, self::ILJ_FIELD_CUSTOM_LINKS_URL, $url);

		// saving options
		$nofollow = (isset($_POST[self::ILJ_FIELD_CUSTOM_LINKS_OPTION_NOFOLLOW])) ? 1 : 0;
		update_post_meta($post_id, self::ILJ_FIELD_CUSTOM_LINKS_OPTION_NOFOLLOW, $nofollow);

		$new_window = (isset($_POST[self::ILJ_FIELD_CUSTOM_LINKS_OPTION_NEW_WINDOW])) ? 1 : 0;
		update_post_meta($post_id, self::ILJ_FIELD_CUSTOM_LINKS_OPTION_NEW_WINDOW, $new_window);
	}

	/**
	 * Disables the autosave functionality for this post type
	 *
	 * @since  1.0.1
	 * @return void
	 */
	public static function disable_autosave() {
		global $typenow;

		if (self::ILJ_POSTTYPE_CUSTOM_LINKS_SLUG == $typenow) {
			wp_deregister_script('autosave');
		}
	}

	/**
	 * Customizes the overview of all custom link posts
	 *
	 * @since  1.0.1
	 * @return void
	 */
	public static function customize_overview() {
		$current_screen = get_current_screen();
		if (!empty($current_screen->post_type) && self::ILJ_POSTTYPE_CUSTOM_LINKS_SLUG == $current_screen->post_type) {
			add_filter(
				"views_{$current_screen->id}",
				function ($views) {
					if (isset($views['draft'])) {
						unset($views['draft']);
					}

					if (isset($views['publish'])) {
						unset($views['publish']);
					}

					if (count($views) == 1) {
						return array();
					}

					return $views;
				}
			);

			add_filter(
				"bulk_actions-{$current_screen->id}",
				function ($actions) {

					if (isset($actions['edit'])) {
						unset($actions['edit']);
					}

					return $actions;
				}
			);

			add_filter(
				'display_post_states',
				function ($states) {

					if (isset($states['draft'])) {
						$states['draft'] = __('Không hoạt động', 'internal-links');
					}

					return $states;
				}
			);
		}
	}

	/**
	 * Removes all data related to the registered posttype (post, postmeta)
	 *
	 * @since  1.2.8
	 * @return void
	 */
	public static function removePostData() {
		$posts = get_posts(
			array(
				'post_type'   => self::ILJ_POSTTYPE_CUSTOM_LINKS_SLUG,
				'numberposts' => -1,
			)
		);

		foreach ($posts as $post) {
			wp_delete_post($post->ID, true);
		}
	}

	/**
	 * Custom Links update messages.
	 *
	 * @see /wp-admin/edit-form-advanced.php
	 *
	 * @param  array $messages Existing post update messages.
	 * @return array
	 */
	public function custom_links_updated_messages($messages) {
		$messages[self::ILJ_POSTTYPE_CUSTOM_LINKS_SLUG] = array(
			0  => '', // Unused. Messages start at index 1.
			1  => __('Liên kết tùy chỉnh đã được cập nhật.', 'internal-links'),
			4  => __('Liên kết tùy chỉnh đã được cập nhật.', 'internal-links'),
			6  => __('Liên kết tùy chỉnh đã được xuất bản.', 'internal-links'),
			7  => __('Liên kết tùy chỉnh đã được lưu.', 'internal-links'),
			10 => __('Bản nháp liên kết tùy chỉnh đã được cập nhật.', 'internal-links'),
		);

		return $messages;
	}
}
