<?php
namespace ILJ\Command;

use ILJ\Cache\Transient_Cache;
use ILJ\Core\IndexBuilder;
use ILJ\Database\Linkindex;
use ILJ\Backend\Environment;
use ILJ\Backend\IndexRebuildNotifier;
use ILJ\Core\Options;

if (class_exists('WP_CLI_Command')) {
	/**
	 * Manage the linkindex through CLI
	 *
	 * @since 1.2.10
	 */
	class IndexCommand extends \WP_CLI_Command {

		/**
		 * (Re-)build the index
		 *
		 * ## OPTIONS
		 *
		 * [--force]
		 * : Force the execution in automatic index mode
		 *
		 * ## EXAMPLES
		 *     # Build / rebuild the index
		 *     $ wp ilj index build
		 *     $ wp ilj index build --force - to bypass auto mode
		 *
		 * @param  mixed $args
		 * @param  mixed $assoc_args
		 * @return void
		 */
		public function build($args, $assoc_args) {
			if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
				$index_mode = Options::getOption(\ILJ\Core\Options\IndexGeneration::getKey());
				if (!isset($assoc_args['force'])) {
					if (\ILJ\Enumeration\IndexMode::AUTOMATIC === $index_mode) {
						\WP_CLI::error('Index mode is set to automatic, a build of the index via the CLI is thus blocked. To force the execution, add the parameter --force to the command. ');
						return;
					}
				}
			}
			$index_builder = new IndexBuilder();
			$index_stat    = $index_builder->buildIndex();
			Transient_Cache::delete_all();
			\WP_CLI::success("Index built successfully. Built " . $index_stat['last_update']['entries'] . " records in " . $index_stat['last_update']['duration'] . " seconds.");
		}

		/**
		 * Flush the whole index (be careful with that in production mode!)
		 *
		 * ## OPTIONS
		 *
		 * [--force]
		 * : Force the execution in automatic index mode
		 *
		 * ## EXAMPLES
		 *     # Flush the whole index tables
		 *     $ wp ilj index flush
		 *     $ wp ilj index flush --force - to bypass auto mode
		 *
		 * @param  mixed $args
		 * @param  mixed $assoc_args
		 * @return void
		 */
		public function flush($args, $assoc_args) {
			if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
				$index_mode = Options::getOption(\ILJ\Core\Options\IndexGeneration::getKey());
				if (!isset($assoc_args['force'])) {

					if (\ILJ\Enumeration\IndexMode::AUTOMATIC === $index_mode) {
						\WP_CLI::error('Index Mode set to Automatic flush failed. Try using wp ilj index flush --force to force flush in auto mode. ');
						return;
					}
				}
			}
			\WP_CLI::confirm('Are you sure to flush the whole index?', $assoc_args);
			Linkindex::flush();

			$feedback = array(
				'last_update' => array(
					'date'     => new \DateTime(),
					'entries'  => 0,
					'duration' => null,
				),
			);
			
			Environment::update('linkindex', $feedback);
			Transient_Cache::delete_all();
			\WP_CLI::success("Index flushed successfully.");
		}
	}
}
