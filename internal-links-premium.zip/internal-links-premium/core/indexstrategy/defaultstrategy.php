<?php

namespace ILJ\Core\IndexStrategy;

use ILJ\Core\Options;
use ILJ\Database\Postmeta;
use ILJ\Enumeration\IndexMode;
use ILJ\Enumeration\KeywordOrder;
use ILJ\Enumeration\LinkType;
use ILJ\Helper\Encoding;
use ILJ\Helper\IndexAsset;
use ILJ\Helper\Keyword;
use ILJ\Helper\Regex;
use ILJ\Helper\Blacklist;
use ILJ\Helper\Statistic;
use ILJ\Type\Ruleset;
use ILJ\Helper\Misc;

/**
 * Default indexbuilder
 *
 * The default index builder strategy
 *
 * @package ILJ\Core\Indexbuilder
 *
 * @since 1.2.0
 */
class DefaultStrategy implements StrategyInterface {

	/**
	 * Link Rules
	 *
	 * @var   Ruleset
	 * @since 1.0.0
	 */
	public $link_rules;

	/**
	 * Link Options
	 *
	 * @var   array
	 * @since 1.0.1
	 */
	public $link_options = array();

	/**
	 * List of blacklisted Posts
	 *
	 * @var   array
	 * @since 1.2.15
	 */
	public $blacklisted_posts = array();

	/**
	 * List of blacklisted terms
	 *
	 * @var   array
	 * @since 1.2.15
	 */
	public $blacklisted_terms = array();

	public function __construct() {
		 $this->link_rules = new Ruleset();

		$this->blacklisted_posts = Blacklist::getBlacklistedList('post');

		if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			$this->blacklisted_terms = Blacklist::getBlacklistedList('term');
		}
	}
	
	/**
	 * Responsible for building the index and writing possible internal links to it
	 *
	 * @return void
	 */
	public function setIndices() {
		$index_count = 0;

		$this->loadLinkConfigurations();
		$posts = IndexAsset::getPosts();
		if (is_array($posts) && !empty($posts)) {
			$this->writeToIndex(
				$posts,
				'post',
				array(
					'id'      => 'ID',
					'content' => 'post_content',
				),
				$index_count,
				IndexAsset::ILJ_FULL_BUILD,
				IndexMode::NONE
			);
		}

		if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			$terms = IndexAsset::getTerms__premium_only();
			if (is_array($terms) && !empty($terms)) {
				$this->writeToIndex(
					$terms,
					'term',
					array(
						'id'      => 'term_id',
						'content' => 'description',
					),
					$index_count,
					IndexAsset::ILJ_FULL_BUILD,
					IndexMode::NONE
				);

			}

			$custom_fields_to_link_post = Options::getOption(\ILJ\Core\Options\CustomFieldsToLinkPost::getKey());
			$custom_fields_to_link_term = Options::getOption(\ILJ\Core\Options\CustomFieldsToLinkTerm::getKey());

			$custom_fields_posts = IndexAsset::getCustomFieldsValue__premium_only('post');
			$custom_fields_terms = IndexAsset::getCustomFieldsValue__premium_only('term');

			if (!empty($custom_fields_to_link_post)) {
				$this->writeToIndex(
					json_decode($custom_fields_posts),
					'post_meta',
					array(
						'id'      => 'ID',
						'content' => 'custom_field',
					),
					$index_count,
					IndexAsset::ILJ_FULL_BUILD,
					IndexMode::NONE
				);
			}
			if (!empty($custom_fields_to_link_term)) {
				$this->writeToIndex(
					json_decode($custom_fields_terms),
					'term_meta',
					array(
						'id'      => 'ID',
						'content' => 'custom_field',
					),
					$index_count,
					IndexAsset::ILJ_FULL_BUILD,
					IndexMode::NONE
				);

			}
		}

		return $index_count;
	}

	/**
	 * Set Batched Index Builds
	 *
	 * @param  mixed $data
	 * @param  mixed $data_type
	 * @param  mixed $keyword_offset
	 * @param  mixed $keyword_type
	 * @return void
	 */
	public function setBatchedIndices($data, $data_type, $keyword_offset, $keyword_type) {
		$index_count = 0;

		$this->loadLinkConfigurationsBatched($keyword_offset, $keyword_type);
		if ('post' == $data_type) {
			$posts = $data;
			if (is_array($posts) && !empty($posts)) {
				$this->writeToIndex(
					$posts,
					'post',
					array(
						'id'      => 'ID',
						'content' => 'post_content',
					),
					$index_count,
					IndexAsset::ILJ_FULL_BUILD,
					IndexMode::AUTOMATIC
				);
			}
		}

		if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			if ('term' == $data_type) {
				$terms = $data;
				if (is_array($terms) && !empty($terms)) {
					$this->writeToIndex(
						$terms,
						'term',
						array(
							'id'      => 'term_id',
							'content' => 'description',
						),
						$index_count,
						IndexAsset::ILJ_FULL_BUILD,
						IndexMode::AUTOMATIC
					);
				}
			}

			if ('post_meta' == $data_type) {
				$post_meta = IndexAsset::getCustomFieldsValue__premium_only('post');
				$post_meta = json_decode($post_meta);
				if (is_array($post_meta) && !empty($post_meta)) {
					$this->writeToIndex(
						$post_meta,
						'post_meta',
						array(
							'id'      => 'ID',
							'content' => 'custom_field',
						),
						$index_count,
						IndexAsset::ILJ_FULL_BUILD,
						IndexMode::AUTOMATIC
					);
				}
			}

			if ('term_meta' == $data_type) {
				$term_meta = IndexAsset::getCustomFieldsValue__premium_only('term');
				$term_meta = json_decode($term_meta);
				if (is_array($term_meta) && !empty($term_meta)) {
					$this->writeToIndex(
						$term_meta,
						'term_meta',
						array(
							'id'      => 'ID',
							'content' => 'custom_field',
						),
						$index_count,
						IndexAsset::ILJ_FULL_BUILD,
						IndexMode::AUTOMATIC
					);
				}
			}
		}

		return $index_count;
	}

	/**
	 * Set individual index builds for post/term/metas in automatic mode
	 *
	 * @param  mixed $id
	 * @param  mixed $type
	 * @param  mixed $link_type
	 * @param  mixed $keyword_offset
	 * @param  mixed $keyword_type
	 * @param  mixed $batched_data
	 * @param  mixed $batched_data_type
	 * @return int
	 */
	public function setIndividualIndices($id, $type, $link_type, $keyword_offset, $keyword_type, $batched_data, $batched_data_type) {
		$index_count  = Statistic::getLinkIndexCount();
		$posts        = array();
		if (LinkType::OUTGOING == $link_type) {
			$this->loadLinkConfigurationsBatched($keyword_offset, $keyword_type);
			if ('post' == $batched_data_type) {
				array_push($posts, $id);
			}

			if ('post' == $batched_data_type) {
				$this->writeToIndex(
					$posts,
					'post',
					array(
						'id'      => 'ID',
						'content' => 'post_content',
					),
					$index_count,
					IndexAsset::ILJ_INDIVIDUAL_BUILD,
					IndexMode::AUTOMATIC,
					$link_type
				);
			}

			if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
				if ('post_meta' == $batched_data_type) {
					$posts_meta          = array();
					$custom_fields_value = IndexAsset::getCustomFieldsValuePerID__premium_only($id, 'post');
					if (is_array($custom_fields_value) && !empty($custom_fields_value)) {
						$posts_meta[] = $custom_fields_value;
					}
				} elseif ('term' == $batched_data_type) {
					$terms = array();
					array_push($terms, $id);
				} elseif ('term_meta' == $batched_data_type) {
					$terms_meta          = array();
					$custom_fields_value = IndexAsset::getCustomFieldsValuePerID__premium_only($id, 'term');
					if (is_array($custom_fields_value) && !empty($custom_fields_value)) {
						$terms_meta[] = $custom_fields_value;
					}
				}

				if ('term' == $batched_data_type) {
					$this->writeToIndex(
						$terms,
						'term',
						array(
							'id'      => 'term_id',
							'content' => 'description',
						),
						$index_count,
						IndexAsset::ILJ_INDIVIDUAL_BUILD,
						IndexMode::AUTOMATIC,
						$link_type
					);
				} elseif ('term_meta' == $batched_data_type) {
					if (is_array($terms_meta) && !empty($terms_meta)) {
						$this->writeToIndex(
							$terms_meta,
							'term_meta',
							array(
								'id'      => 'ID',
								'content' => 'custom_field',
							),
							$index_count,
							IndexAsset::ILJ_INDIVIDUAL_BUILD,
							IndexMode::AUTOMATIC,
							$link_type
						);
					}
				} elseif ('post_meta' == $batched_data_type) {
					if (is_array($posts_meta) && !empty($posts_meta)) {
						$this->writeToIndex(
							$posts_meta,
							'post_meta',
							array(
								'id'      => 'ID',
								'content' => 'custom_field',
							),
							$index_count,
							IndexAsset::ILJ_INDIVIDUAL_BUILD,
							IndexMode::AUTOMATIC,
							$link_type
						);
					}
				}
			}
		} elseif (LinkType::INCOMING == $link_type) {
			$this->loadLinkIndividualConfigurations($id, $type);
			$data = $batched_data;

			if ('post' == $batched_data_type) {
				$this->writeToIndex(
					$data,
					'post',
					array(
						'id'      => 'ID',
						'content' => 'post_content',
					),
					$index_count,
					IndexAsset::ILJ_INDIVIDUAL_BUILD,
					IndexMode::AUTOMATIC,
					$link_type
				);
			}
			if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
				if ('term' == $batched_data_type) {
					$this->writeToIndex(
						$data,
						'term',
						array(
							'id'      => 'term_id',
							'content' => 'description',
						),
						$index_count,
						IndexAsset::ILJ_INDIVIDUAL_BUILD,
						IndexMode::AUTOMATIC,
						$link_type
					);
				} elseif ('term_meta' == $batched_data_type) {
					$this->writeToIndex(
						$data,
						'term_meta',
						array(
							'id'      => 'ID',
							'content' => 'custom_field',
						),
						$index_count,
						IndexAsset::ILJ_INDIVIDUAL_BUILD,
						IndexMode::AUTOMATIC,
						$link_type
					);
				} elseif ('post_meta' == $batched_data_type) {
					$this->writeToIndex(
						$data,
						'post_meta',
						array(
							'id'      => 'ID',
							'content' => 'custom_field',
						),
						$index_count,
						IndexAsset::ILJ_INDIVIDUAL_BUILD,
						IndexMode::AUTOMATIC,
						$link_type
					);
				}
			}
		}
		return $index_count;
	}

	/**
	 * Set the Link options value
	 *
	 * @param  array $link_options
	 * @return void
	 */
	public function setLinkOptions(array $link_options) {
		$this->link_options = $link_options;
	}

	/**
	 * Picks up all meta definitions for configured keywords and adds them to internal ruleset
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	protected function loadLinkConfigurations() {
		$post_definitions = Postmeta::getAllLinkDefinitions();
		foreach ($post_definitions as $definition) {
			$type = 'post';

			if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
				if (get_post_type($definition->post_id) == \ILJ\Posttypes\CustomLinks::ILJ_POSTTYPE_CUSTOM_LINKS_SLUG) {
					$type = 'custom';
				}
			}

			$anchors = Misc::unserialize($definition->meta_value);
			if (!$anchors || !is_array($anchors)) {
				continue;
			}

			$anchors = $this->applyKeywordOrder($anchors);

			$this->addAnchorsToLinkRules(
				$anchors,
				array(
					'id'   => $definition->post_id,
					'type' => $type,
				)
			);
		}

		if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			$term_definitions = \ILJ\Database\Termmeta::getAllLinkDefinitions();
			$term_definitions = isset($term_definitions) ? $term_definitions : array();
			foreach ($term_definitions as $definition) {
				$anchors = Misc::unserialize($definition->meta_value);

				if (!$anchors) {
					continue;
				}

				$anchors = $this->applyKeywordOrder($anchors);

				$this->addAnchorsToLinkRules(
					$anchors,
					array(
						'id'   => $definition->term_id,
						'type' => 'term',
					)
				);
			}
		}
	}

	/**
	 * Picks up all meta definitions for configured keywords and adds them to internal ruleset
	 *
	 * @since 1.0.0
	 *
	 * @param  mixed $offset
	 * @param  mixed $keyword_type
	 *
	 * @return void
	 */
	public function loadLinkConfigurationsBatched($offset, $keyword_type) {
		if ('post' == $keyword_type) {
			$post_definitions = Postmeta::getAllLinkDefinitionsByBatch($offset);
			foreach ($post_definitions as $definition) {
				$post_type = 'post';

				if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
					if (get_post_type($definition->post_id) == \ILJ\Posttypes\CustomLinks::ILJ_POSTTYPE_CUSTOM_LINKS_SLUG) {
						$post_type = 'custom';
					}
				}

				$anchors = Misc::unserialize($definition->meta_value);
				if (!$anchors || !is_array($anchors)) {
					continue;
				}

				$anchors = $this->applyKeywordOrder($anchors);

				$this->addAnchorsToLinkRules(
					$anchors,
					array(
						'id'   => $definition->post_id,
						'type' => $post_type,
					)
				);
			}
			return;
		}

		if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			if ('term' == $keyword_type) {

				$term_definitions = \ILJ\Database\Termmeta::getAllLinkDefinitionsByBatch($offset);
				$term_definitions = isset($term_definitions) ? $term_definitions : array();

				foreach ($term_definitions as $definition) {
					$anchors = Misc::unserialize($definition->meta_value);

					if (!$anchors) {
						continue;
					}

					$anchors = $this->applyKeywordOrder($anchors);

					$this->addAnchorsToLinkRules(
						$anchors,
						array(
							'id'   => $definition->term_id,
							'type' => 'term',
						)
					);
				}

				return;
			}
		}
	}

	/**
	 * Picks up all meta definitions for configured keywords and adds them to internal ruleset for Individual index builds
	 *
	 * @param  int    $id
	 * @param  string $type
	 * @return void
	 */
	protected function loadLinkIndividualConfigurations($id, $type) {
		if ('post' == $type) {
			$post_definitions = Postmeta::getLinkDefinitionsById($id);

			foreach ($post_definitions as $definition) {
				$post_type = 'post';

				if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
					if (get_post_type($definition->post_id) == \ILJ\Posttypes\CustomLinks::ILJ_POSTTYPE_CUSTOM_LINKS_SLUG) {
						$post_type = 'custom';
					}
				}

				$anchors = Misc::unserialize($definition->meta_value);
				if (!$anchors || !is_array($anchors)) {
					continue;
				}

				$anchors = $this->applyKeywordOrder($anchors);

				$this->addAnchorsToLinkRules(
					$anchors,
					array(
						'id'   => $definition->post_id,
						'type' => $post_type,
					)
				);
			}

			return;
		}

		if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			if ('term' == $type) {
				$term_definitions = \ILJ\Database\Termmeta::getLinkDefinitionsById($id);

				$term_definitions = isset($term_definitions) ? $term_definitions : array();

				foreach ($term_definitions as $definition) {
					$anchors = Misc::unserialize($definition->meta_value);

					if (!$anchors) {
						continue;
					}

					$anchors = $this->applyKeywordOrder($anchors);

					$this->addAnchorsToLinkRules(
						$anchors,
						array(
							'id'   => $definition->term_id,
							'type' => 'term',
						)
					);
				}
				return;
			}
		};
	}

	/**
	 * Adds anchors to link_rules
	 *
	 * @since 1.2.0
	 * @param array $anchors The bag of anchor texts
	 * @param array $params  The params
	 *
	 * @return void
	 */
	protected function addAnchorsToLinkRules(array $anchors, array $params) {
		foreach ($anchors as $anchor) {
			$anchor = Encoding::unmaskSlashes($anchor);

			if (!Regex::isValid($anchor)) {
				continue;
			}

			$pattern = Regex::escapeDot($anchor);
			$this->link_rules->addRule($pattern, $params['id'], $params['type']);
		}
	}

	/**
	 * Reorders the configured anchors depending on the plugin settings
	 *
	 * @since 1.2.0
	 * @param array $anchors The bag of anchor texts
	 *
	 * @return array
	 */
	protected function applyKeywordOrder(array $anchors) {
		$keyword_order = Options::getOption(\ILJ\Core\Options\KeywordOrder::getKey());

		switch ($keyword_order) {
			case KeywordOrder::HIGH_WORDCOUNT_FIRST:
				usort(
					$anchors,
					function ($a, $b) {
						return Keyword::gapWordCount($b) - Keyword::gapWordCount($a);
					}
				);
				break;
			case KeywordOrder::LOW_WORDCOUNT_FIRST:
				usort(
					$anchors,
					function ($a, $b) {
						return Keyword::gapWordCount($a) - Keyword::gapWordCount($b);
					}
				);
				break;
			case KeywordOrder::HIGH_CHARCOUNT_FIRST:
				usort(
					$anchors,
					function ($a, $b) {
						return Keyword::gapCharacterCount($b) - Keyword::gapCharacterCount($a);
					}
				);
				break;
			case KeywordOrder::LOW_CHARCOUNT_FIRST:
				usort(
					$anchors,
					function ($a, $b) {
						return Keyword::gapCharacterCount($a) - Keyword::gapCharacterCount($b);
					}
				);
				break;
		}

		return $anchors;
	}

	/**
	 * Writes a set of data to the linkindex
	 *
	 * @since 1.0.1
	 *
	 * @param  array  $data       The data container
	 * @param  string $data_type  Type of the data inside the container
	 * @param  array  $fields     Field settings for the container objects
	 * @param  int    $counter    Counts the written operations
	 * @param  mixed  $scope
	 * @param  mixed  $build_mode
	 * @param  mixed  $link_type
	 * @return void
	 */
	protected function writeToIndex($data, $data_type, array $fields, &$counter, $scope, $build_mode, $link_type = null) {
		if (!is_array($data) || !count($data)) {
			return;
		}
		$fields = wp_parse_args(
			$fields,
			array(
				'id'      => '',
				'content' => '',
			)
		);

		$IndexStrategy = new IndexStrategy($data_type, $fields, $this->link_options, $build_mode);
		$IndexStrategy->setCounter($counter);
		$IndexStrategy->setLinkRules($this->link_rules);
		$IndexStrategy->buildLinksPerData($data, $data_type, $scope, $link_type);
		$counter = $IndexStrategy->getCounter();

	}
}
