<?php
namespace ILJ\Core\Options;

/**
 * Option: Ckey Model
 *
 * @package ILJ\Core\Options
 */
class CkeyModel extends AbstractOption {
	
	/**
	 * Get the unique identifier for the option
	 *
	 * @return string
	 */
	public static function getKey() {
		return self::ILJ_OPTIONS_PREFIX . 'ckey_model';
	}
	
	/**
	 * Get the default value of the option
	 *
	 * @return mixed
	 */
	public static function getDefault() {
		return '';
	}
	
	/**
	 * Get the frontend label for the option
	 *
	 * @return string
	 */
	public function getTitle() {
		return __('Ckey Model', 'internal-links');
	}
	
	/**
	 * Get the frontend description for the option
	 *
	 * @return string
	 */
	public function getDescription() {
		return __('Select the Ckey model to use.', 'internal-links');
	}

	/**
	 * Outputs the options form element for backend administration
	 *
	 * @param  mixed $value
	 * @return mixed
	 */
	public function renderField($value) {
		$key = self::getKey();
		$models = self::getAvailableModels();
		?>
		<select name="<?php echo esc_attr($key); ?>" id="<?php echo esc_attr($key); ?>">
			<?php if (empty($models)) : ?>
				<option value=""><?php esc_html_e('Hãy thêm custom model ở dưới...', 'internal-links'); ?></option>
			<?php else : ?>
				<?php foreach ($models as $val => $label) : ?>
					<option value="<?php echo esc_attr($val); ?>" <?php selected($value, $val); ?>><?php echo esc_html($label); ?></option>
				<?php endforeach; ?>
			<?php endif; ?>
		</select>
		<?php
	}

	/**
	 * Get available Ckey models
	 *
	 * @return array
	 */
	public static function getAvailableModels() {
		$models = array();
		
		$custom_models_json = \ILJ\Core\Options::getOption(\ILJ\Core\Options\CkeyCustomModels::getKey());
		if (empty($custom_models_json) || $custom_models_json instanceof \WP_Error) {
			$custom_models_json = \ILJ\Core\Options\CkeyCustomModels::getDefault();
		}
		
		$custom_models = json_decode($custom_models_json, true);
		if (is_array($custom_models)) {
			foreach ($custom_models as $model) {
				$model = trim($model);
				if (!empty($model)) {
					$models[$model] = $model . ' ✍️';
				}
			}
		}
		return $models;
	}
	
	/**
	 * Checks if a value is a valid value for option
	 *
	 * @param  mixed $value The value that gets validated
	 * @return bool
	 */
	public function isValidValue($value) {
		return is_string($value);
	}
}
