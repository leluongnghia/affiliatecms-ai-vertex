<?php
// Deprecated. OpenAI has been removed.
