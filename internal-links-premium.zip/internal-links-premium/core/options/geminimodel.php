<?php
namespace ILJ\Core\Options;

/**
 * Option: Gemini Model
 *
 * @package ILJ\Core\Options
 */
class GeminiModel extends AbstractOption {
	
	/**
	 * Get the unique identifier for the option
	 *
	 * @return string
	 */
	public static function getKey() {
		return self::ILJ_OPTIONS_PREFIX . 'gemini_model';
	}
	
	/**
	 * Get the default value of the option
	 *
	 * @return mixed
	 */
	public static function getDefault() {
		return 'gemini-2.5-flash';
	}
	
	/**
	 * Get the frontend label for the option
	 *
	 * @return string
	 */
	public function getTitle() {
		return __('Gemini Model', 'internal-links');
	}
	
	/**
	 * Get the frontend description for the option
	 *
	 * @return string
	 */
	public function getDescription() {
		return __('Select the Gemini model to use. gemini-2.5-flash is highly recommended for speed and cost.', 'internal-links');
	}

	/**
	 * Outputs the options form element for backend administration
	 *
	 * @param  mixed $value
	 * @return mixed
	 */
	public function renderField($value) {
		$key = self::getKey();
		?>
		<select name="<?php echo esc_attr($key); ?>" id="<?php echo esc_attr($key); ?>">
			<option value="gemini-3.5-flash" <?php selected($value, 'gemini-3.5-flash'); ?>><?php esc_html_e('Gemini 3.5 Flash', 'internal-links'); ?></option>
			<option value="gemini-3.1-pro" <?php selected($value, 'gemini-3.1-pro'); ?>><?php esc_html_e('Gemini 3.1 Pro', 'internal-links'); ?></option>
			<option value="gemini-3.1-flash-lite" <?php selected($value, 'gemini-3.1-flash-lite'); ?>><?php esc_html_e('Gemini 3.1 Flash Lite', 'internal-links'); ?></option>
			<option value="gemini-3.0-flash" <?php selected($value, 'gemini-3.0-flash'); ?>><?php esc_html_e('Gemini 3.0 Flash', 'internal-links'); ?></option>
			<option value="gemini-2.5-pro" <?php selected($value, 'gemini-2.5-pro'); ?>><?php esc_html_e('Gemini 2.5 Pro', 'internal-links'); ?></option>
			<option value="gemini-2.5-flash" <?php selected($value, 'gemini-2.5-flash'); ?>><?php esc_html_e('Gemini 2.5 Flash', 'internal-links'); ?></option>
			<option value="gemini-2.5-flash-lite" <?php selected($value, 'gemini-2.5-flash-lite'); ?>><?php esc_html_e('Gemini 2.5 Flash Lite', 'internal-links'); ?></option>
			<option value="gemini-2.0-flash" <?php selected($value, 'gemini-2.0-flash'); ?>><?php esc_html_e('Gemini 2.0 Flash', 'internal-links'); ?></option>
			<option value="gemini-1.5-flash" <?php selected($value, 'gemini-1.5-flash'); ?>><?php esc_html_e('Gemini 1.5 Flash', 'internal-links'); ?></option>
			<option value="gemini-1.5-pro" <?php selected($value, 'gemini-1.5-pro'); ?>><?php esc_html_e('Gemini 1.5 Pro', 'internal-links'); ?></option>
			<option value="gemma-4-31b-it" <?php selected($value, 'gemma-4-31b-it'); ?>><?php esc_html_e('Gemma 4 31B', 'internal-links'); ?></option>
			<option value="gemma-4-26b-a4b-it" <?php selected($value, 'gemma-4-26b-a4b-it'); ?>><?php esc_html_e('Gemma 4 26B', 'internal-links'); ?></option>
			<option value="gemma-4-12b-it" <?php selected($value, 'gemma-4-12b-it'); ?>><?php esc_html_e('Gemma 4 12B', 'internal-links'); ?></option>
			<option value="gemma-2-27b-it" <?php selected($value, 'gemma-2-27b-it'); ?>><?php esc_html_e('Gemma 2 27B', 'internal-links'); ?></option>
			<option value="gemma-2-9b-it" <?php selected($value, 'gemma-2-9b-it'); ?>><?php esc_html_e('Gemma 2 9B', 'internal-links'); ?></option>
			<option value="gemma-2-2b-it" <?php selected($value, 'gemma-2-2b-it'); ?>><?php esc_html_e('Gemma 2 2B', 'internal-links'); ?></option>
		</select>
		<?php
	}
	
	/**
	 * Checks if a value is a valid value for option
	 *
	 * @param  mixed $value The value that gets validated
	 * @return bool
	 */
	public function isValidValue($value) {
		return in_array($value, array(
			'gemini-3.5-flash',
			'gemini-3.1-pro',
			'gemini-3.1-flash-lite',
			'gemini-3.0-flash',
			'gemini-2.5-pro',
			'gemini-2.5-flash',
			'gemini-2.5-flash-lite',
			'gemini-2.0-flash',
			'gemini-1.5-flash',
			'gemini-1.5-pro',
			'gemma-4-31b-it',
			'gemma-4-26b-a4b-it',
			'gemma-4-12b-it',
			'gemma-2-27b-it',
			'gemma-2-9b-it',
			'gemma-2-2b-it'
		));
	}
}
