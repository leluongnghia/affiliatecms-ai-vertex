<?php
namespace ILJ\Core\Options;

use ILJ\Helper\Options as OptionsHelper;

/**
 * Option: Respect existing links
 *
 * @package ILJ\Core\Options
 * @since   1.1.3
 */
class RespectExistingLinks extends AbstractOption {
	
	/**
	 * Get the unique identifier for the option
	 *
	 * @return string
	 */
	public static function getKey() {
		return self::ILJ_OPTIONS_PREFIX . 'link_output_respect_existing_links';
	}
	
	/**
	 * Get the default value of the option
	 *
	 * @return mixed
	 */
	public static function getDefault() {
		return true;
	}
	
	/**
	 * Identifies if the current option is pro only
	 *
	 * @return bool
	 */
	public static function isPro() {
		return true;
	}

	/**
	 * Adds the option to an option group
	 *
	 * @param  string $option_group The option group to which the option gets connected
	 * @return void
	 */
	public function register($option_group) {
		if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			register_setting($option_group, static::getKey(), 'intval');
		}
	}
	
	/**
	 * Get the frontend label for the option
	 *
	 * @return string
	 */
	public function getTitle() {
		return __('Xem xét các liên kết hiện có hoặc được tạo thủ công', 'internal-links');
	}
	
	/**
	 * Get the frontend description for the option
	 *
	 * @return string
	 */
	public function getDescription() {
		return __('Không liên kết các mục tiêu liên kết đã được xây dựng thủ công', 'internal-links') . '<br>' . __('Ngăn chặn liên kết đến các URL đã được liên kết trong nội dung', 'internal-links');
	}
	
	/**
	 * Outputs the options form element for backend administration
	 *
	 * @param  mixed $value
	 * @return mixed
	 */
	public function renderField($value) {
		if (!\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			$value = false;
		}
		OptionsHelper::renderToggle($this, $value);
	}

	/**
	 * Checks if a value is a valid value for option
	 *
	 * @param  mixed $value The value that gets validated
	 * @return bool
	 */
	public function isValidValue($value) {
		if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			return 1 === (int) $value || 0 === (int) $value;
		}

		return false;
	}
}
