<?php
namespace ILJ\Core\Options;

/**
 * Option: AI Source
 *
 * @package ILJ\Core\Options
 */
class AiSource extends AbstractOption {
	
	/**
	 * Get the unique identifier for the option
	 *
	 * @return string
	 */
	public static function getKey() {
		return self::ILJ_OPTIONS_PREFIX . 'ai_source';
	}
	
	/**
	 * Get the default value of the option
	 *
	 * @return mixed
	 */
	public static function getDefault() {
		return 'gemini_api';
	}
	
	/**
	 * Get the frontend label for the option
	 *
	 * @return string
	 */
	public function getTitle() {
		return __('AI Engine / Source', 'internal-links');
	}
	
	/**
	 * Get the frontend description for the option
	 *
	 * @return string
	 */
	public function getDescription() {
		return __('Select the AI Source to use for keyword generation. If using Vertex AI Agent, configure credentials below.', 'internal-links');
	}

	/**
	 * Outputs the options form element for backend administration
	 *
	 * @param  mixed $value
	 * @return mixed
	 */
	public function renderField($value) {
		$key = self::getKey();
		?>
		<select name="<?php echo esc_attr($key); ?>" id="<?php echo esc_attr($key); ?>">
			<option value="gemini_api" <?php selected($value, 'gemini_api'); ?>><?php esc_html_e('Google Gemini API (AI Studio)', 'internal-links'); ?></option>
			<option value="vertex_ai_api" <?php selected($value, 'vertex_ai_api'); ?>><?php esc_html_e('Vertex AI Model API (Vertex AI Studio)', 'internal-links'); ?></option>
			<option value="vertex_ai_agent" <?php selected($value, 'vertex_ai_agent'); ?>><?php esc_html_e('Vertex AI Agent Platform (Vertex AI Studio)', 'internal-links'); ?></option>
			<option value="ckey" <?php selected($value, 'ckey'); ?>><?php esc_html_e('CKEY.VN (Claude/GPT Proxy)', 'internal-links'); ?></option>
			<option value="cliproxy" <?php selected($value, 'cliproxy'); ?>><?php esc_html_e('CLIProxyAPI (api.azevent.vn)', 'internal-links'); ?></option>
		</select>
		<?php
	}
	
	/**
	 * Checks if a value is a valid value for option
	 *
	 * @param  mixed $value The value that gets validated
	 * @return bool
	 */
	public function isValidValue($value) {
		return in_array($value, array('gemini_api', 'vertex_ai_api', 'vertex_ai_agent', 'ckey', 'cliproxy'));
	}
}
