<?php
namespace ILJ\Core\Options;

/**
 * Option: Vertex Agent Location
 *
 * @package ILJ\Core\Options
 */
class VertexAgentLocation extends AbstractOption {
	
	/**
	 * Get the unique identifier for the option
	 *
	 * @return string
	 */
	public static function getKey() {
		return self::ILJ_OPTIONS_PREFIX . 'vertex_agent_location';
	}
	
	/**
	 * Get the default value of the option
	 *
	 * @return mixed
	 */
	public static function getDefault() {
		return 'global';
	}
	
	/**
	 * Get the frontend label for the option
	 *
	 * @return string
	 */
	public function getTitle() {
		return __('Vertex AI Location / Region', 'internal-links');
	}
	
	/**
	 * Get the frontend description for the option
	 *
	 * @return string
	 */
	public function getDescription() {
		return __('Select the region/location where your Agent is deployed.', 'internal-links');
	}

	/**
	 * Outputs the options form element for backend administration
	 *
	 * @param  mixed $value
	 * @return mixed
	 */
	public function renderField($value) {
		$key = self::getKey();
		?>
		<select name="<?php echo esc_attr($key); ?>" id="<?php echo esc_attr($key); ?>">
			<option value="global" <?php selected($value, 'global'); ?>><?php esc_html_e('global', 'internal-links'); ?></option>
			<option value="us-central1" <?php selected($value, 'us-central1'); ?>><?php esc_html_e('us-central1', 'internal-links'); ?></option>
			<option value="us-east1" <?php selected($value, 'us-east1'); ?>><?php esc_html_e('us-east1', 'internal-links'); ?></option>
			<option value="europe-west1" <?php selected($value, 'europe-west1'); ?>><?php esc_html_e('europe-west1', 'internal-links'); ?></option>
			<option value="asia-northeast1" <?php selected($value, 'asia-northeast1'); ?>><?php esc_html_e('asia-northeast1', 'internal-links'); ?></option>
		</select>
		<?php
	}
	
	/**
	 * Checks if a value is a valid value for option
	 *
	 * @param  mixed $value The value that gets validated
	 * @return bool
	 */
	public function isValidValue($value) {
		return is_string($value);
	}
}
