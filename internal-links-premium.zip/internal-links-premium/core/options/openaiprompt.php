<?php
namespace ILJ\Core\Options;

/**
 * Option: OpenAI Prompt
 *
 * @package ILJ\Core\Options
 */
class OpenAIPrompt extends AbstractOption {
	
	/**
	 * Get the unique identifier for the option
	 *
	 * @return string
	 */
	public static function getKey() {
		return self::ILJ_OPTIONS_PREFIX . 'openai_prompt';
	}
	
	/**
	 * Get the default value of the option
	 *
	 * @return mixed
	 */
	public static function getDefault() {
		return "Extract SEO keywords for internal linking from the post below.\n\nOUTPUT FORMAT: Return ONLY a valid JSON array of strings. No explanation, no markdown, no code block. Example: [\"keyword one\", \"keyword two\"]\n\nRULES:\n1. IDENTIFY POST TYPE:\n- If this is a specific product review/comparison of a specific model (e.g., \"GE5654 Bluetooth Tube Preamp\"), prioritize exact product-specific keywords that include the brand/model name (e.g., \"GE5654 review\", \"GE5654 preamp\"). Avoid generic category terms (like \"headphone amplifier\" or \"desktop audio\") as keywords for a specific product review to prevent wrong page targeting.\n- If this is a general/category/pillar article (e.g., \"Best headphone amplifiers\"), use general category terms (e.g., \"headphone amplifier\", \"vacuum tube preamp\").\n\n2. CONSTRAINTS:\n- Each keyword must be 1-5 words, no punctuation.\n- Same language as the post.\n- No duplicate or near-duplicate keywords.\n\nPost Title: {title}\nPost Content: {content}";
	}
	
	/**
	 * Get the frontend label for the option
	 *
	 * @return string
	 */
	public function getTitle() {
		return __('AI Prompt Template', 'internal-links');
	}
	
	/**
	 * Get the frontend description for the option
	 *
	 * @return string
	 */
	public function getDescription() {
		return __('Customize the prompt sent to the AI service. Use <code>{title}</code> and <code>{content}</code> as placeholders.', 'internal-links');
	}

	/**
	 * Outputs the options form element for backend administration
	 *
	 * @param  mixed $value
	 * @return mixed
	 */
	public function renderField($value) {
		$key     = self::getKey();
		$default = self::getDefault();
		?>
		<textarea name="<?php echo esc_attr($key); ?>" id="<?php echo esc_attr($key); ?>" rows="8" cols="60" style="width: 100%; max-width: 600px;"><?php echo esc_html($value); ?></textarea>
		<br>
		<button type="button" id="ilj-reset-prompt-btn" class="button button-secondary" style="margin-top: 6px;"
			onclick="document.getElementById('<?php echo esc_js($key); ?>').value = <?php echo esc_attr(wp_json_encode($default)); ?>; return false;">
			&#8635; <?php _e('Reset to Default Prompt', 'internal-links'); ?>
		</button>
		<span style="margin-left: 8px; color: #646970; font-style: italic; font-size: 0.9em;"><?php _e('(click then Save Settings)', 'internal-links'); ?></span>
		<?php
	}
	
	/**
	 * Checks if a value is a valid value for option
	 *
	 * @param  mixed $value The value that gets validated
	 * @return bool
	 */
	public function isValidValue($value) {
		return is_string($value) && !empty($value);
	}
}
