<?php
namespace ILJ\Core\Options;

/**
 * Option: Vertex JSON Path
 *
 * @package ILJ\Core\Options
 */
class VertexJsonPath extends AbstractOption {
	
	/**
	 * Get the unique identifier for the option
	 *
	 * @return string
	 */
	public static function getKey() {
		return self::ILJ_OPTIONS_PREFIX . 'vertex_json_path';
	}
	
	/**
	 * Get the default value of the option
	 *
	 * @return mixed
	 */
	public static function getDefault() {
		return 'f:\\internal-links-premium_v2.26.0\\vertex-ai-api-498407-b08de5bf2bcc.json';
	}
	
	/**
	 * Get the frontend label for the option
	 *
	 * @return string
	 */
	public function getTitle() {
		return __('Vertex AI Credentials Path', 'internal-links');
	}
	
	/**
	 * Get the frontend description for the option
	 *
	 * @return string
	 */
	public function getDescription() {
		return __('Enter the absolute file path to the Vertex AI service account credentials JSON file.', 'internal-links');
	}

	/**
	 * Outputs the options form element for backend administration
	 *
	 * @param  mixed $value
	 * @return mixed
	 */
	public function renderField($value) {
		$key = self::getKey();
		?>
		<div style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
			<input type="text" name="<?php echo esc_attr($key); ?>" id="<?php echo esc_attr($key); ?>" value="<?php echo esc_attr($value); ?>" style="width: 450px;" placeholder="f:\path\to\credentials.json" />
			<span style="color: #646970; font-weight: bold;"><?php _e('OR', 'internal-links'); ?></span>
			<input type="file" id="ilj-vertex-json-file" accept=".json" style="display: none;" />
			<button type="button" id="ilj-vertex-json-upload-btn" class="button button-secondary">
				&#128194; <?php _e('Upload Credentials JSON', 'internal-links'); ?>
			</button>
			<span id="ilj-vertex-json-upload-status" style="font-weight: bold; font-size: 0.95em;"></span>
		</div>

		<script type="text/javascript">
		jQuery(document).ready(function($) {
			$('#ilj-vertex-json-upload-btn').on('click', function(e) {
				e.preventDefault();
				$('#ilj-vertex-json-file').click();
			});

			$('#ilj-vertex-json-file').on('change', function(e) {
				var file = e.target.files[0];
				if (!file) return;

				var reader = new FileReader();
				reader.onload = function(evt) {
					var content = evt.target.result;
					var filename = file.name;

					$('#ilj-vertex-json-upload-status').css('color', '#3399ff').text('<?php echo esc_js(__('Uploading...', 'internal-links')); ?>');
					$('#ilj-vertex-json-upload-btn').prop('disabled', true);

					$.ajax({
						url: ajaxurl,
						type: 'POST',
						data: {
							action: 'ilj_upload_vertex_json',
							filename: filename,
							content: content,
							nonce: '<?php echo wp_create_nonce('ilj-general-nonce'); ?>'
						},
						success: function(response) {
							$('#ilj-vertex-json-upload-btn').prop('disabled', false);
							if (response.success) {
								$('#<?php echo esc_attr($key); ?>').val(response.data.path);
								$('#ilj-vertex-json-upload-status').css('color', '#46b450').text('<?php echo esc_js(__('Uploaded successfully!', 'internal-links')); ?>');
								// Clear file input
								$('#ilj-vertex-json-file').val('');
							} else {
								$('#ilj-vertex-json-upload-status').css('color', '#dc3232').text('<?php echo esc_js(__('Upload failed: ', 'internal-links')); ?>' + (response.data || 'Unknown error'));
							}
						},
						error: function(xhr, status, error) {
							$('#ilj-vertex-json-upload-btn').prop('disabled', false);
							$('#ilj-vertex-json-upload-status').css('color', '#dc3232').text('<?php echo esc_js(__('Network error: ', 'internal-links')); ?>' + error);
						}
					});
				};
				reader.readAsText(file);
			});
		});
		</script>
		<?php
	}
	
	/**
	 * Checks if a value is a valid value for option
	 *
	 * @param  mixed $value The value that gets validated
	 * @return bool
	 */
	public function isValidValue($value) {
		return is_string($value);
	}
}
