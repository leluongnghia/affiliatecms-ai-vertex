<?php
namespace ILJ\Core\Options;

use ILJ\Helper\Options as OptionsHelper;
use ILJ\Core\Options as Options;
use ILJ\Helper\IndexAsset;

/**
 * Option: List of Term Custom Fields used for limiting links
 *
 * @package ILJ\Core\Options
 * @since   2.1.0
 */
class CustomFieldsToLinkTerm extends Custom_Fields_Option {

	const ILJ_ACF_HINT_FILTER_TERM = 'ilj_hint_for_acf_term';
	
	/**
	 * Get the unique identifier for the option
	 *
	 * @return string
	 */
	public static function getKey() {
		return self::ILJ_OPTIONS_PREFIX . 'custom_fields_to_link_term';
	}
	
	/**
	 * Get the default value of the option
	 *
	 * @return mixed
	 */
	public static function getDefault() {
		return array();
	}
	
	/**
	 * Identifies if the current option is pro only
	 *
	 * @return bool
	 */
	public static function isPro() {
		return true;
	}

	/**
	 * Adds the option to an option group
	 *
	 * @param  string $option_group The option group to which the option gets connected
	 * @return void
	 */
	public function register($option_group) {
		if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			register_setting(
				$option_group,
				static::getKey(),
				array(
					'sanitize_callback' => array($this, 'sanitize_option'),
				)
			);
		}
	}

	/**
	 * Sanitize option value.
	 *
	 * @param  mixed $input Input value.
	 * @return mixed
	 */
	public function sanitize_option($input) {
		if (empty($input)) {
			return $input;
		}
		return array_map('sanitize_text_field', wp_unslash($input));
	}
	
	/**
	 * Get the frontend label for the option
	 *
	 * @return string
	 */
	public function getTitle() {
		return __('Các trường thuật ngữ tùy chỉnh được sử dụng để liên kết', 'internal-links');
	}
	
	/**
	 * Get the frontend description for the option
	 *
	 * @return string
	 */
	public function getDescription() {
		return __('Đây là danh sách các trường tùy chỉnh thuật ngữ nên được sử dụng để liên kết tự động.<br>Để trống để không liên kết bất kỳ trường tùy chỉnh nào.', 'internal-links');
	}

	/**
	 * Gets all custom fields that can be used with the plugin
	 *
	 * @since   2.1.0
	 * @return array
	 */
	public function getCustomFields__premium_only() {
		$custom_fields = $this->getAllAvailableCustomFields__premium_only();
		return array_values($custom_fields);
	}

	/**
	 * Fetch all custom fields from database.
	 *
	 * @return array
	 */
	private function getAllAvailableCustomFields__premium_only() {
		global $wpdb;
		$query = "SELECT DISTINCT($wpdb->termmeta.meta_key) FROM $wpdb->terms LEFT JOIN $wpdb->termmeta ON $wpdb->terms.term_id = $wpdb->termmeta.term_id WHERE $wpdb->termmeta.meta_key != '' AND $wpdb->termmeta.meta_key NOT RegExp '(^[_0-9].+$)' AND $wpdb->termmeta.meta_key NOT RegExp '(^[0-9]+$)' AND $wpdb->termmeta.meta_key NOT LIKE %s ";
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- Direct query required for complex term metadata filtering; caching is not applicable.
		$meta_keys = $wpdb->get_results($wpdb->prepare($query, 'ilj_%'));
		return $meta_keys;
	}

	/**
	 * Outputs the options form element for backend administration
	 *
	 * @param  mixed $value
	 * @return mixed
	 */
	public function renderField($value) {
		if ('' == $value) {
			$value = array();
		}

		$custom_fields = array();

		if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			$custom_fields = $this->getCustomFields__premium_only();
		}
		$key = self::getKey();
		?>
		<select name="<?php echo esc_attr($key); ?>[]"
			id="<?php echo esc_attr($key); ?>"
			multiple="multiple"
			<?php OptionsHelper::render_disabler($this); ?>
		>
		<?php if (count($custom_fields)) { ?>
			<?php foreach ($custom_fields as $custom_field) { ?>
				<option
					value="<?php echo esc_attr($custom_field->meta_key); ?>"
					<?php selected(in_array($custom_field->meta_key, $value)); ?>
				>
					<?php echo esc_html($custom_field->meta_key); ?>
				</option>
			<?php } ?>
		<?php } ?>
		<?php $this->render_saved_regex_options($value); ?>
		</select>
		<?php
	}

	/**
	 * Checks if a value is a valid value for option
	 *
	 * @param  mixed $value The value that gets validated
	 * @return bool
	 */
	public function isValidValue($value) {
		if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			if (!is_array($value)) {
				return false;
			}

			$custom_fields = $this->getCustomFields__premium_only();

			$custom_fields_names = array_map(
				function ($taxonomy) {
					return $taxonomy->meta_key;
				},
				$custom_fields
			);

			foreach ($value as $val) {
				if (!in_array($val, $custom_fields_names)) {
					return false;
				}
			}

			return true;
		}

		return false;
	}
	
	/**
	 * Returns a hint text for the option, if given
	 *
	 * @return string
	 */
	public function getHint() {
		 $hint = '';

		$hint = apply_filters(self::ILJ_ACF_HINT_FILTER_TERM, $hint);

		return $hint;
	}
	
	/**
	 * Check if field is empty
	 *
	 * @return bool
	 */
	public static function is_empty() {
		$custom_fields = Options::getOption(self::getKey());
		if (empty($custom_fields)) {
			return true;
		}
		return false;
	}
}
