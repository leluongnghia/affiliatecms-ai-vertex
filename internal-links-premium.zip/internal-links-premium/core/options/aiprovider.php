<?php
// Deprecated. Only Google Gemini is supported.
