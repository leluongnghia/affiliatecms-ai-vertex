<?php
namespace ILJ\Core\Options;

use ILJ\Helper\Help;

/**
 * Option: Link template for internal links
 *
 * @package ILJ\Core\Options
 * @since   1.1.3
 */
class LinkOutputInternal extends AbstractOption {

	/**
	 * Adds the option to an option group
	 *
	 * @param  string $option_group The option group to which the option gets connected
	 * @return void
	 */
	public function register($option_group) {
		register_setting(
			$option_group,
			static::getKey(),
			array(
				'type'              => 'string',
				'sanitize_callback' => 'esc_html',
			)
		);
	}
	
	/**
	 * Get the unique identifier for the option
	 *
	 * @return string
	 */
	public static function getKey() {
		return self::ILJ_OPTIONS_PREFIX . 'link_output_internal';
	}
	
	/**
	 * Get the default value of the option
	 *
	 * @return mixed
	 */
	public static function getDefault() {
		return esc_html('<a href="{{url}}">{{anchor}}</a>');
	}
	
	/**
	 * Get the frontend label for the option
	 *
	 * @return string
	 */
	public function getTitle() {
		return __('Mẫu cho đầu ra liên kết (liên kết từ khóa)', 'internal-links');
	}
	
	/**
	 * Get the frontend description for the option
	 *
	 * @return string
	 */
	public function getDescription() {
		return __('Đánh dấu cho đầu ra của các liên kết nội bộ được tạo ra.', 'internal-links');
	}

	
	/**
	 * Outputs the options form element for backend administration
	 *
	 * @param  mixed $value
	 * @return mixed
	 */
	public function renderField($value) {
		$key = self::getKey();
		?>
		<input type="text" name="<?php echo esc_attr($key); ?>" id="<?php echo esc_attr($key); ?>" value="<?php echo esc_attr($value); ?>"
		/>
		<?php Help::render_options_link('link-templates/', '', 'link templates');
	}

	
	/**
	 * Returns a hint text for the option, if given
	 *
	 * @return string
	 */
	public function getHint() {
		if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			return '<p>' . __('Bạn có thể sử dụng phần giữ chỗ <code>{{url}</code> cho mục tiêu, <code>{{excerpt}</code> cho đoạn trích, <code>{{anchor}</code> cho văn bản liên kết được tạo và <code>{{title}</code> để xuất tiêu đề bài đăng hoặc thuật ngữ.', 'internal-links') . '</p>';
		}
		$output  = '<p>' . __('Bạn có thể sử dụng phần giữ chỗ <code>{{url}</code> cho mục tiêu và <code>{{anchor}</code> cho văn bản liên kết được tạo.', 'internal-links') . '</p>';
		$output .= '<p><small><strong>' . __('Với phiên bản Pro, bạn cũng sẽ có sẵn phần giữ chỗ <code>{{excerpt}</code> để xuất đoạn trích và <code>{{title}</code> để xuất tiêu đề bài đăng/thuế.', 'internal-links') . '</strong></small></p>';

		return $output;
	}

	
	/**
	 * Checks if a value is a valid value for option
	 *
	 * @param  mixed $value The value that gets validated
	 * @return bool
	 */
	public function isValidValue($value) {
		return is_string($value);
	}
}
