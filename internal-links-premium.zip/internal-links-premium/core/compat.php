<?php

namespace ILJ\Core;

use ILJ\Backend\MenuPage\Tools;
use ILJ\Core\IndexStrategy\PolylangStrategy;
use ILJ\Core\IndexStrategy\WPMLStrategy;
use ILJ\Core\Links\Text_To_Link_Converter_Factory;
use ILJ\Core\Options\CustomFieldsToLinkPost;
use ILJ\Core\Options\CustomFieldsToLinkTerm;
use ILJ\Core\Options\Whitelist;
use ILJ\Enumeration\LinkType;
use ILJ\Helper\Ajax;
use ILJ\Helper\BatchInfo;
use ILJ\Helper\CustomMetaData;
use ILJ\Helper\IndexAsset;
use ILJ\Helper\LinkBuilding;
use ILJ\Posttypes\CustomLinks;
use ILJ\Type\KeywordList;
use ILJ\Helper\Misc;

/**
 * Compatibility handler
 *
 * Responsible for managing compatibility with other 3rd party plugins
 *
 * @package ILJ\Core
 *
 * @since 1.2.0
 */
class Compat {

	/**
	 * Initializes the Compat module
	 *
	 * @static
	 * @since  1.2.0
	 *
	 * @return void
	 */
	public static function init() {
		 self::enableWpml();
		self::enableYoast();
		self::enableRankMath();
		self::enablePolylang();
		self::enableDivi();
		self::enableACF();

		if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			self::enableMuffinBuilder__premium_only();
			self::enableOxygen__premium_only();
		}
	}

	/**
	 * Responsible for handling Polylang integration
	 *
	 * @static
	 * @since  1.2.2
	 *
	 * @return void
	 */
	public static function enablePolylang() {
		if (!defined('POLYLANG_BASENAME')) {
			return;
		}

		add_filter(
			IndexBuilder::ILJ_FILTER_INDEX_STRATEGY,
			function () {
				return new PolylangStrategy();
			}
		);

		if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			add_filter(
				'pll_get_post_types',
				function ($post_types, $is_settings) {
					if ($is_settings) {
						// hide from the list of custom post types in Polylang settings
						unset($post_types[CustomLinks::ILJ_POSTTYPE_CUSTOM_LINKS_SLUG]);
					} else {
						  // enables language and translation management
						  $post_types[CustomLinks::ILJ_POSTTYPE_CUSTOM_LINKS_SLUG] = CustomLinks::ILJ_POSTTYPE_CUSTOM_LINKS_SLUG;
					}

					return $post_types;
				},
				10,
				2
			);
		}

		// fallback language is English whatever the default language
		add_filter(
			'pll_preferred_language',
			function ($slug) {
				return false === $slug ? 'en' : $slug;
			}
		);

		add_filter(
			'add_to_meta_box_exception',
			function ($metabox) {
				array_push($metabox, 'ml_box');
				return $metabox;
			}
		);

		add_filter(
			Ajax::ILJ_FILTER_AJAX_SEARCH_POSTS,
			function ($data) {
				for ($i = 0; $i < count($data); $i++) {
					$data[$i]['text'] = $data[$i]['text'] . ' (' . pll_get_post_language($data[$i]['id']) . ')';
				}

				return $data;
			},
			10,
			2
		);

		if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			add_filter(
				Ajax::ILJ_FILTER_AJAX_SEARCH_TERMS,
				function ($data) {
					for ($i = 0; $i < count($data); $i++) {
						$data[$i]['text'] = $data[$i]['text'] . ' (' . pll_get_term_language($data[$i]['id']) . ')';
					}

					return $data;
				},
				10,
				2
			);
		}

		add_filter(
			IndexAsset::ILJ_FILTER_INDEX_ASSET,
			function ($meta_data, $type, $id) {

				$asset_language     = '';
				$language_container = array();

				if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
					if ('term' == $type) {
						$asset_language = pll_get_term_language($id);
					}
				}

				$asset_language = ('' == $asset_language) ? pll_get_post_language($id) : $asset_language;

				if (!$asset_language || '' == $asset_language) {
					return $meta_data;
				}

				if (!isset($language_container[$asset_language])) {
					$language_container[$asset_language] = PLL()->model->get_language($asset_language);
				}

				$flag_url         = $language_container[$asset_language]->flag_url;
				$flag_img         = sprintf('<img class="tip" src="%s" title="%s" />', $flag_url, $language_container[$asset_language]->name);
				$meta_data->title = $flag_img . ' ' . $meta_data->title;

				return $meta_data;
			},
			10,
			3
		);
	}

	/**
	 * Responsible for handling WPML integration
	 *
	 * @static
	 * @since  1.2.0
	 *
	 * @return void
	 */
	protected static function enableWpml() {
		if (!function_exists('icl_object_id') || defined('POLYLANG_BASENAME')) {
			return;
		}

		add_filter(
			IndexBuilder::ILJ_FILTER_INDEX_STRATEGY,
			function () {
				return new WPMLStrategy();
			}
		);

		add_filter(
			Ajax::ILJ_FILTER_AJAX_SEARCH_POSTS,
			function ($data, $args) {
				global $sitepress;

				$languages        = WPMLStrategy::getLanguages();
				$current_language = $sitepress->get_current_language();

				for ($i = 0; $i < count($data); $i++) {
					 $data[$i]['text'] = $data[$i]['text'] . ' (' . $current_language . ')';
				}

				foreach ($languages as $language) {
					if ($language == $current_language) {
						  continue;
					}

					$sitepress->switch_lang($language, true);

					$query = new \WP_Query($args);

					foreach ($query->posts as $post) {
						$data[] = array(
							'id'   => $post->ID,
							'text' => $post->post_title . ' (' . $language . ')',
						);
					}

					$sitepress->switch_lang($current_language, true);
				}

				return $data;
			},
			10,
			2
		);

		if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			add_filter(
				Ajax::ILJ_FILTER_AJAX_SEARCH_TERMS,
				function ($data, $args) {
					global $sitepress;

					$data             = array();
					$languages        = WPMLStrategy::getLanguages();
					$current_language = $sitepress->get_current_language();

					foreach ($languages as $language) {

						 $sitepress->switch_lang($language, true);

						 $query = new \WP_Term_Query($args);

						if ($query->terms && !empty($query) && !is_wp_error($query)) {
							foreach ($query->terms as $term) {
								$taxonomy = get_taxonomy($term->taxonomy);
								$data[]   = array(
									'id'   => $term->term_id,
									'text' => $term->name . ' [' . $taxonomy->label . ']' . ' (' . $language . ')',
								);
							}
						}

						$sitepress->switch_lang($current_language, true);
					}

					return $data;
				},
				10,
				2
			);
		}

		add_filter(
			IndexAsset::ILJ_FILTER_INDEX_ASSET,
			function ($meta_data, $type, $id) {
				global $sitepress;

				if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
					if ('term' == $type) {

						$term = get_term((int) $id);

						$language_code = apply_filters(
							'wpml_element_language_code',
							null,
							array(
								'element_id'   => (int) $id,
								'element_type' => $term->taxonomy,
							)
						);

						if ('' != $language_code) {
									$language = $sitepress->get_language_for_element((int) $id, 'tax_' . $term->taxonomy);

									$current_language = $sitepress->get_current_language();

							if ($current_language != $language_code) {
								$sitepress->switch_lang($language_code, true);

								$term = get_term((int) $id);

								$meta_data->title    = $term->name;
								$meta_data->url      = get_term_link($term);
								$meta_data->url_edit = get_edit_term_link($term->term_id);

								$sitepress->switch_lang($current_language, true);
							}

								$language_information = $sitepress->get_language_details($language);

								$language_info = array(
									'language_code'      => $language,
									'locale'             => $sitepress->get_locale($language),
									'text_direction'     => $sitepress->is_rtl($language),
									'display_name'       => $sitepress->get_display_language_name($language, $current_language),
									'native_name'        => isset($language_information['display_name']) ? $language_information['display_name'] : '',
									'different_language' => $language !== $current_language,
								);
						}
					}
				}

				$language_info = !isset($language_info) ? wpml_get_language_information(null, (int) $id) : $language_info;

				if (!$language_info) {
					return $meta_data;
				}

				$flag_url = $sitepress->get_flag_url($language_info['language_code']);
				$flag_img = sprintf('<img class="tip" src="%s" title="%s" />', $flag_url, $language_info['display_name']);

				$meta_data->title = $flag_img . ' ' . $meta_data->title;

				return $meta_data;
			},
			10,
			3
		);
	}

	/**
	 * Responsible for handling Yoast-SEO integration
	 *
	 * @static
	 * @since  1.2.0
	 *
	 * @return void
	 */
	protected static function enableYoast() {
		if (!defined('WPSEO_VERSION')) {
			return;
		}

		add_filter(
			Tools::ILJ_FILTER_MENUPAGE_TOOLS_KEYWORD_IMPORT_POST,
			function ($keyword_import_source) {
				$import_source = array(
					'title' => __('Từ khóa trọng tâm Yoast', 'internal-links'),
					'class' => 'yoast-seo',
				);

				$keyword_import_source[] = $import_source;
				return $keyword_import_source;
			}
		);

		add_filter(
			Tools::ILJ_FILTER_MENUPAGE_TOOLS_KEYWORD_IMPORT_TERM,
			function ($keyword_import_source) {
				$import_source = array(
					'title' => __('Từ khóa trọng tâm Yoast', 'internal-links'),
					'class' => 'yoast-seo',
				);

				$keyword_import_source[] = $import_source;
				return $keyword_import_source;
			}
		);

		if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			add_action(
				Tools::ILJ_MENUPAGE_TOOLS_IMPORT_INTERN_POST . '-' . 'yoast-seo',
				function ($post) {
					$keywords      = new KeywordList();
					$focus_keyword = \WPSEO_Meta::get_value('focuskw', $post->ID);
					$keywords->addKeyword($focus_keyword);

					$focus_keywords_additional = get_post_meta($post->ID, '_yoast_wpseo_focuskeywords', true);
					$focus_keywords_additional = json_decode($focus_keywords_additional, true);

					if (!empty($focus_keywords_additional)) {
						$extra_keywords = new KeywordList($focus_keywords_additional);
						$keywords->merge($extra_keywords);
					}

					return $keywords;
				}
			);

			add_action(
				Tools::ILJ_MENUPAGE_TOOLS_IMPORT_INTERN_TERM . '-' . 'yoast-seo',
				function ($term) {
					$keywords = new KeywordList();

					$taxonomy_meta = get_option('wpseo_taxonomy_meta');

					if (empty($taxonomy_meta)) {
						return $keywords;
					}

					$taxonomies = array();

					foreach ($taxonomy_meta as $meta) {
						$taxonomies = $taxonomies + $meta;
					}

					if (!isset($taxonomies[$term->term_id]) || !isset($taxonomies[$term->term_id]['wpseo_focuskw'])) {
						return $keywords;
					}

					$focus_kw = strtolower($taxonomies[$term->term_id]['wpseo_focuskw']);
					$keywords = KeywordList::fromInput($focus_kw);

					return $keywords;
				}
			);
		}
	}

	/**
	 * Responsible for handling RankMath integration
	 *
	 * @static
	 * @since  1.2.0
	 *
	 * @return void
	 */
	protected static function enableRankMath() {
		if (!class_exists('RankMath')) {
			return;
		}

		add_filter(
			Tools::ILJ_FILTER_MENUPAGE_TOOLS_KEYWORD_IMPORT_POST,
			function ($keyword_import_source) {
				$import_source = array(
					'title' => __('Từ khóa trọng tâm RankMath', 'internal-links'),
					'class' => 'rankmath',
				);

				$keyword_import_source[] = $import_source;
				return $keyword_import_source;
			}
		);

		add_filter(
			Tools::ILJ_FILTER_MENUPAGE_TOOLS_KEYWORD_IMPORT_TERM,
			function ($keyword_import_source) {
				$import_source = array(
					'title' => __('Từ khóa trọng tâm RankMath', 'internal-links'),
					'class' => 'rankmath',
				);

				$keyword_import_source[] = $import_source;
				return $keyword_import_source;
			}
		);

		if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			add_action(
				Tools::ILJ_MENUPAGE_TOOLS_IMPORT_INTERN_POST . '-' . 'rankmath',
				function ($post) {
					$focus_keyword_meta = get_post_meta($post->ID, 'rank_math_focus_keyword', true);
					$focus_keywords     = KeywordList::fromInput($focus_keyword_meta);

					return $focus_keywords;
				}
			);

			add_action(
				Tools::ILJ_MENUPAGE_TOOLS_IMPORT_INTERN_TERM . '-' . 'rankmath',
				function ($term) {
					$focus_keyword_meta = get_term_meta($term->term_id, 'rank_math_focus_keyword', true);
					$focus_keywords     = KeywordList::fromInput($focus_keyword_meta);

					return $focus_keywords;
				}
			);
		}
	}

	/**
	 * Responsible for loading Divi's ET Builder's code
	 *
	 * @static
	 * @since  1.3.12
	 */
	public static function enableDivi() {

		if (!is_plugin_active('divi-builder/divi-builder.php')) {
			return;
		}

		$index_mode = Options::getOption(\ILJ\Core\Options\IndexGeneration::getKey());

		if (\ILJ\Enumeration\IndexMode::NONE != $index_mode && \ILJ\Enumeration\IndexMode::AUTOMATIC != $index_mode) {
			return;
		}

		add_action(
			'builder_compat',
			function() {
				if (!did_action('et_builder_ready')) {
					require_once ET_BUILDER_DIR . 'class-et-builder-value.php';
					require_once ET_BUILDER_DIR . 'ab-testing.php';
					require_once ET_BUILDER_DIR . 'class-et-builder-element.php';
					require_once ET_BUILDER_DIR . 'class-et-global-settings.php';
					require_once ET_BUILDER_DIR . 'framework.php';
					require_once ET_BUILDER_DIR . 'class-et-builder-settings.php';

					et_builder_init_global_settings();
					et_builder_add_main_elements();
					et_builder_settings_init();
				}
			},
			10
		);
	}

	/**
	 * The below method iteratively search for `content` key, when the content is string, it gets
	 * concatenated to single string which is used for building index.
	 *
	 * @param array $items
	 *
	 * @return string
	 */
	private static function extract_content_from_field($items) {
		$content  = '';
		$queue = $items;
		while ($queue) {
			$items = array_shift($queue);
			if (wp_is_numeric_array($items)) {
				$queue = array_merge($queue, $items);
			} elseif (is_array($items)) {
				foreach ($items as $key => $value) {
					if ('content' === $key || is_array($value)) {
						$queue[] = $value;
					}
				}
			} elseif (is_string($items)) {
				$content .= wpautop($items);
			}
		}
		return $content;

	}

	/**
	 * Enables Muffin Builder Index Building
	 *
	 * @return mixed
	 */
	protected static function enableMuffinBuilder__premium_only() {

		if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			add_filter(
				IndexAsset::ILJ_FILTER_MUFFIN_BUILDER_FIELD,
				function($field_value) {
					try {
						if ($field_value && ! is_array($field_value)) {
							/**
							 * Muffin builder stores data in 2 ways
							 * 1. Serialized data with base64 encoding
							 * 2. Serialized data with no encoding.
							 * We need to check if its serialized string, then optionally apply base64_decode.
							 */
							$field_value = is_serialized($field_value) ? Misc::unserialize($field_value) : Misc::unserialize(base64_decode($field_value));
						}
						return self::extract_content_from_field($field_value);
					} catch (\Throwable $e) {
						return '';
					}
				},
				10,
				5
			);
		}

	}

		/**
		 * Link Builder for Oxygen Content
		 *
		 * @return void
		 */
	protected static function enableOxygen__premium_only() {

		if (!is_plugin_active('oxygen/functions.php')) {
			return;
		}

		add_action(
			'ct_builder_end',
			function() {
				global $template_content;
				if (is_admin()) {
					return;
				}

				if (LinkBuilding::excludeLinkBuilderFilter()) {
					return;
				}

				$type           = 'post_meta';
				$current_object = get_queried_object();
				$id             = 0;
				if (!empty($current_object)) {
					if (isset($current_object->term_id)) {
						$type = 'term_meta';
						$id   = $current_object->term_id;
					} elseif (isset($current_object->ID)) {
						$id = $current_object->ID;
					}
				}

				$link_builder     = Text_To_Link_Converter_Factory::create($id, $type);
				$template_content = $link_builder->link_content($template_content);
			},
			99
		);

		add_action(
			'updated_post_meta',
			function ($meta_id, $post_id, $meta_key) {
				if (CustomMetaData::ILJ_OXYGEN_BUILDER_META_FIELD != $meta_key) {
					return;
				}

				$whitelisted_post_types = \ILJ\Core\Options::getOption(Whitelist::getKey());
				if (!empty($whitelisted_post_types)) {
					if (!in_array(get_post_type($post_id), $whitelisted_post_types)) {
						return;
					}
				}
				$batch_build_info = new BatchInfo();

				if (false === as_has_scheduled_action(
					IndexBuilder::ILJ_SET_INDIVIDUAL_INDEX_REBUILD,
					array(
						array(
							'id'        => $post_id,
							'type'      => 'post',
							'link_type' => LinkType::OUTGOING,
							'meta'      => 'post_meta',
						),
					),
					BatchInfo::ILJ_ASYNC_GROUP
				)
				) {
					$batch_build_info->incrementBatchCounter();
					$batch_build_info->updateBatchBuildInfo();
					as_enqueue_async_action(
						IndexBuilder::ILJ_SET_INDIVIDUAL_INDEX_REBUILD,
						array(
							array(
								'id'        => $post_id,
								'type'      => 'post',
								'link_type' => LinkType::OUTGOING,
								'meta'      => 'post_meta',
							),
						),
						BatchInfo::ILJ_ASYNC_GROUP
					);
				}
			},
			30,
			3
		);
	}

	/**
	 * Check if ACF is enabled
	 *
	 * @return void
	 */
	protected static function enableACF() {

		if (!class_exists('ACF')) {
			return;
		}

		add_filter(
			CustomFieldsToLinkPost::ILJ_ACF_HINT_FILTER_POST,
			function($hint) {
				$hint = "<p class='description'> <span>&#8505;</span>  " . __('Bạn có thể chọn các trường do ACF tạo cho bài viết tại đây', 'internal-links') . '</p>';
				return $hint;
			},
			10,
			1
		);

		add_filter(
			CustomFieldsToLinkTerm::ILJ_ACF_HINT_FILTER_TERM,
			function($hint) {
				$hint = "<p class='description'> <span>&#8505;</span>  " . __('Bạn có thể chọn các trường do ACF tạo cho các thuật ngữ tại đây', 'internal-links') . '</p>';
				return $hint;
			},
			10,
			1
		);

		add_action(
			CustomFieldsToLinkPost::ILJ_ACTION_ADD_PRO_FEATURES,
			function() {
				?>
				<li><span><?php esc_html_e('Toàn bộ sức mạnh của ACF', 'internal-links'); ?></span>: <?php esc_html_e('Định cấu hình các trường tùy chỉnh từ ACF và bật liên kết tự động trong nội dung được tạo tùy chỉnh của bạn.', 'internal-links'); ?></li>
				<?php
			},
			20
		);

	}
}
