<?php
namespace ILJ\Helper;

/**
 * Helper: Vertex AI Service and API integrations
 *
 * @package ILJ\Helper
 */
class VertexAI {

	/**
	 * Resolve the credentials JSON path (applying the fallback if needed)
	 *
	 * @param string $json_path
	 * @return string
	 */
	public static function resolveJsonPath($json_path) {
		if (empty($json_path)) {
			return '';
		}
		if (file_exists($json_path)) {
			return $json_path;
		}
		// Fallback 1: Check in the uploads directory (secure, stable, and survives updates)
		$wp_upload_dir = wp_upload_dir();
		if (!empty($wp_upload_dir['basedir'])) {
			$uploads_fallback = $wp_upload_dir['basedir'] . '/ilj-credentials/' . basename($json_path);
			if (file_exists($uploads_fallback)) {
				return $uploads_fallback;
			}
			$uploads_fallback_direct = $wp_upload_dir['basedir'] . '/' . basename($json_path);
			if (file_exists($uploads_fallback_direct)) {
				return $uploads_fallback_direct;
			}
		}
		// Fallback 2: Check inside the plugin directory
		$plugin_path = defined('ILJ_PATH') ? ILJ_PATH : dirname(__DIR__) . '/';
		$fallback_path = $plugin_path . basename($json_path);
		if (file_exists($fallback_path)) {
			return $fallback_path;
		}
		return $json_path;
	}

	/**
	 * Get OAuth2 access token for Google Cloud Service Account
	 *
	 * Uses local caching to avoid issuing token on every request.
	 *
	 * @param string $json_path
	 * @return string|\WP_Error
	 */
	public static function getAccessToken($json_path) {
		$json_path = self::resolveJsonPath($json_path);
		if (empty($json_path) || !file_exists($json_path)) {
			$err = sprintf(__('Credentials JSON file not found at: %s', 'internal-links'), $json_path);
			self::writeLog('Token Error: ' . $err);
			return new \WP_Error('credentials_not_found', $err);
		}

		$json_content = file_get_contents($json_path);
		$credentials = json_decode($json_content, true);

		if (empty($credentials) || empty($credentials['private_key']) || empty($credentials['client_email'])) {
			$err = __('Invalid credentials JSON file.', 'internal-links');
			self::writeLog('Token Error: ' . $err);
			return new \WP_Error('credentials_invalid', $err);
		}

		// Try to get cached access token from transient
		$transient_key = 'ilj_vertex_access_token_' . md5($json_path);
		$cached_token = get_transient($transient_key);
		if ($cached_token) {
			return $cached_token;
		}

		$private_key = $credentials['private_key'];
		$client_email = $credentials['client_email'];
		$token_uri = isset($credentials['token_uri']) ? $credentials['token_uri'] : 'https://oauth2.googleapis.com/token';

		$header = array(
			'alg' => 'RS256',
			'typ' => 'JWT'
		);

		$now = time();
		$claim_set = array(
			'iss'   => $client_email,
			'scope' => 'https://www.googleapis.com/auth/cloud-platform',
			'aud'   => $token_uri,
			'iat'   => $now,
			'exp'   => $now + 3600
		);

		$encoded_header = self::base64UrlEncode(wp_json_encode($header));
		$encoded_claim  = self::base64UrlEncode(wp_json_encode($claim_set));

		$input = $encoded_header . '.' . $encoded_claim;
		$signature = '';

		if (!function_exists('openssl_sign')) {
			$err = __('The OpenSSL PHP extension is required for Vertex AI service account authentication.', 'internal-links');
			self::writeLog('Token Error: ' . $err);
			return new \WP_Error('openssl_missing', $err);
		}

		$success = openssl_sign($input, $signature, $private_key, 'SHA256');

		if (!$success) {
			$err = __('Failed to sign JWT with private key. Please check the credentials JSON file.', 'internal-links');
			self::writeLog('Token Error: ' . $err);
			return new \WP_Error('signing_failed', $err);
		}

		$encoded_signature = self::base64UrlEncode($signature);
		$assertion = $input . '.' . $encoded_signature;

		$response = wp_remote_post($token_uri, array(
			'timeout' => 30,
			'body' => array(
				'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
				'assertion'  => $assertion
			)
		));

		if (is_wp_error($response)) {
			$err = sprintf(__('Failed to obtain access token: %s', 'internal-links'), $response->get_error_message());
			self::writeLog('Token Error: ' . $err);
			return new \WP_Error('token_request_failed', $err);
		}

		$response_code = wp_remote_retrieve_response_code($response);
		$response_body = wp_remote_retrieve_body($response);

		if ($response_code !== 200) {
			$err = sprintf(__('Google Auth API returned error code %d: %s', 'internal-links'), $response_code, $response_body);
			self::writeLog('Token Error: ' . $err);
			return new \WP_Error('token_response_error', $err);
		}

		$token_data = json_decode($response_body, true);
		if (empty($token_data['access_token'])) {
			$err = __('No access token found in auth response.', 'internal-links');
			self::writeLog('Token Error: ' . $err);
			return new \WP_Error('token_missing', $err);
		}

		$access_token = $token_data['access_token'];
		$expires_in = isset($token_data['expires_in']) ? intval($token_data['expires_in']) - 60 : 3500;

		set_transient($transient_key, $access_token, $expires_in);

		return $access_token;
	}

	/**
	 * Send query/prompt to the Vertex AI Agent (Dialogflow CX detectIntent API)
	 *
	 * @param string $prompt
	 * @param int $post_id
	 * @return string|\WP_Error
	 */
	public static function queryAgent($prompt, $post_id = 0) {
		$json_path = \ILJ\Core\Options::getOption(\ILJ\Core\Options\VertexJsonPath::getKey());
		$agent_id = \ILJ\Core\Options::getOption(\ILJ\Core\Options\VertexAgentId::getKey());
		$location = \ILJ\Core\Options::getOption(\ILJ\Core\Options\VertexAgentLocation::getKey());

		if (empty($json_path)) {
			$err = __('Vertex AI Credentials Path is missing. Please configure it in AI Settings.', 'internal-links');
			self::writeLog('Agent Error: ' . $err);
			return new \WP_Error('vertex_json_missing', $err);
		}

		if (empty($agent_id)) {
			$err = __('Vertex AI Agent ID is missing. Please configure it in AI Settings.', 'internal-links');
			self::writeLog('Agent Error: ' . $err);
			return new \WP_Error('vertex_agent_missing', $err);
		}

		if (empty($location)) {
			$location = 'global';
		}

		$json_path = self::resolveJsonPath($json_path);
		$access_token = self::getAccessToken($json_path);
		if (is_wp_error($access_token)) {
			self::writeLog('Agent Error (OAuth failed): ' . $access_token->get_error_message());
			return $access_token;
		}

		// Read project_id from json file
		$json_content = @file_get_contents($json_path);
		$credentials = json_decode($json_content, true);
		$project_id = isset($credentials['project_id']) ? $credentials['project_id'] : '';

		if (empty($project_id)) {
			$err = __('Could not extract Project ID from credentials JSON.', 'internal-links');
			self::writeLog('Agent Error: ' . $err);
			return new \WP_Error('vertex_project_missing', $err);
		}

		$session_id = uniqid('ilj_');
		
		// Map location to the correct endpoint subdomain
		$domain = 'dialogflow.googleapis.com';
		if ($location !== 'global') {
			$domain = $location . '-dialogflow.googleapis.com';
		}

		$url = sprintf(
			'https://%s/v3/projects/%s/locations/%s/agents/%s/sessions/%s:detectIntent',
			$domain,
			$project_id,
			$location,
			$agent_id,
			$session_id
		);

		$locale_parts = explode('_', get_locale());
		$language_code = !empty($locale_parts[0]) ? $locale_parts[0] : 'en';

		$body = array(
			'queryInput' => array(
				'text' => array(
					'text' => $prompt
				),
				'languageCode' => $language_code
			)
		);

		$response = wp_remote_post($url, array(
			'timeout' => 180,
			'headers' => array(
				'Content-Type'  => 'application/json',
				'Authorization' => 'Bearer ' . $access_token
			),
			'body' => wp_json_encode($body)
		));

		if (is_wp_error($response)) {
			$err = sprintf(__('Vertex AI request failed: %s', 'internal-links'), $response->get_error_message());
			self::writeLog('Agent Error: ' . $err);
			return new \WP_Error('vertex_request_failed', $err);
		}

		$response_code = wp_remote_retrieve_response_code($response);
		$response_body = wp_remote_retrieve_body($response);

		// Log response for debugging
		self::writeLog('=== Vertex AI Agent Response ===');
		self::writeLog('URL: ' . $url);
		self::writeLog('Response Code: ' . $response_code);
		self::writeLog('Response Body: ' . $response_body);

		if ($response_code !== 200) {
			$error_data = json_decode($response_body, true);
			$error_msg = isset($error_data['error']['message']) ? $error_data['error']['message'] : __('Unknown Vertex API error', 'internal-links');
			$err = sprintf(__('Vertex AI Agent Error (Code %d): %s', 'internal-links'), $response_code, $error_msg);
			self::writeLog('Agent Error: ' . $err);
			return new \WP_Error('vertex_api_error', $err);
		}

		$data = json_decode($response_body, true);
		$result_text = '';

		if (!empty($data['queryResult']['responseMessages'])) {
			foreach ($data['queryResult']['responseMessages'] as $message) {
				if (!empty($message['text']['text'])) {
					foreach ($message['text']['text'] as $text_part) {
						$result_text .= $text_part . "\n";
					}
				}
			}
		}

		$result_text = trim($result_text);

		if (empty($result_text)) {
			$err = __('Vertex AI Agent returned an empty response.', 'internal-links');
			self::writeLog('Agent Error: ' . $err);
			return new \WP_Error('vertex_empty_response', $err);
		}

		return $result_text;
	}

	/**
	 * Send query/prompt to the Vertex AI Gemini Model (Model Garden API)
	 *
	 * @param string $prompt
	 * @param int $post_id
	 * @return string|\WP_Error
	 */
	public static function queryModel($prompt, $post_id = 0) {
		$json_path = \ILJ\Core\Options::getOption(\ILJ\Core\Options\VertexJsonPath::getKey());
		$location = \ILJ\Core\Options::getOption(\ILJ\Core\Options\VertexAgentLocation::getKey());
		$model = \ILJ\Core\Options::getOption(\ILJ\Core\Options\GeminiModel::getKey());

		if (empty($json_path)) {
			$err = __('Vertex AI Credentials Path is missing. Please configure it in AI Settings.', 'internal-links');
			self::writeLog('Model Error: ' . $err);
			return new \WP_Error('vertex_json_missing', $err);
		}

		if (empty($location)) {
			$location = 'us-central1';
		}
		if ($location === 'global') {
			$location = 'us-central1';
		}

		if (empty($model)) {
			$model = \ILJ\Core\Options\GeminiModel::getDefault();
		}

		$json_path = self::resolveJsonPath($json_path);
		$access_token = self::getAccessToken($json_path);
		if (is_wp_error($access_token)) {
			self::writeLog('Model Error (OAuth failed): ' . $access_token->get_error_message());
			return $access_token;
		}

		// Read project_id from json file
		$json_content = @file_get_contents($json_path);
		$credentials = json_decode($json_content, true);
		$project_id = isset($credentials['project_id']) ? $credentials['project_id'] : '';

		if (empty($project_id)) {
			$err = __('Could not extract Project ID from credentials JSON.', 'internal-links');
			self::writeLog('Model Error: ' . $err);
			return new \WP_Error('vertex_project_missing', $err);
		}

		// Map Model IDs according to Vertex AI Model Garden verified resource IDs
		$mapping = array(
			'gemini-3.5-flash'      => 'gemini-3.5-flash',
			'gemini-3.1-pro'        => 'gemini-3.1-pro-preview',
			'gemini-3.1-flash'      => 'gemini-3.1-flash-lite',
			'gemini-3.1-flash-lite' => 'gemini-3.1-flash-lite',
			'gemini-3.0-flash'      => 'gemini-3-flash-preview',
			'gemini-2.5-pro'        => 'gemini-2.5-pro',
			'gemini-2.5-flash'      => 'gemini-2.5-flash',
			'gemini-2.5-flash-lite' => 'gemini-2.5-flash-lite',
		);

		$mapped_model = isset($mapping[$model]) ? $mapping[$model] : $model;

		$body = array(
			'contents' => array(
				array(
					'role'  => 'user',
					'parts' => array(
						array(
							'text' => $prompt
						)
					)
				)
			),
			'generationConfig' => array(
				'temperature' => 0.3,
				'responseMimeType' => 'application/json',
				'responseSchema' => array(
					'type' => 'ARRAY',
					'items' => array(
						'type' => 'STRING'
					)
				)
			)
		);

		$regions_to_try = array_unique(array($location, 'global'));
		$last_error = '';

		foreach ($regions_to_try as $try_region) {
			$host = ($try_region === 'global') ? 'aiplatform.googleapis.com' : $try_region . '-aiplatform.googleapis.com';
			$url = sprintf(
				'https://%s/v1/projects/%s/locations/%s/publishers/google/models/%s:generateContent',
				$host,
				$project_id,
				$try_region,
				$mapped_model
			);

			$response = wp_remote_post($url, array(
				'timeout' => 180,
				'headers' => array(
					'Content-Type'  => 'application/json',
					'Authorization' => 'Bearer ' . $access_token
				),
				'body' => wp_json_encode($body)
			));

			if (is_wp_error($response)) {
				$last_error = $response->get_error_message();
				self::writeLog('Model Error (Region ' . $try_region . '): ' . $last_error);
				continue;
			}

			$response_code = wp_remote_retrieve_response_code($response);
			$response_body = wp_remote_retrieve_body($response);

			// Log response for debugging
			self::writeLog('=== Vertex AI Model Response ===');
			self::writeLog('URL: ' . $url);
			self::writeLog('Response Code: ' . $response_code);
			self::writeLog('Response Body: ' . $response_body);

			if ($response_code === 404 && $try_region !== 'global') {
				// Model not available in this region, try global endpoint
				continue;
			}

			if ($response_code !== 200) {
				$error_data = json_decode($response_body, true);
				$last_error = isset($error_data['error']['message']) ? $error_data['error']['message'] : __('Unknown Vertex API error', 'internal-links');
				self::writeLog('Model Error (Code ' . $response_code . '): ' . $last_error);
				continue;
			}

			$data = json_decode($response_body, true);
			$result_text = isset($data['candidates'][0]['content']['parts'][0]['text']) ? trim($data['candidates'][0]['content']['parts'][0]['text']) : '';

			if (empty($result_text)) {
				$err = __('Vertex AI Model returned an empty response.', 'internal-links');
				self::writeLog('Model Error: ' . $err);
				return new \WP_Error('vertex_model_empty_response', $err);
			}

			return $result_text;
		}

		$err_msg = sprintf(__('Vertex AI Model query failed: %s', 'internal-links'), $last_error);
		self::writeLog('Model Final Failure: ' . $err_msg);
		return new \WP_Error('vertex_model_failed', $err_msg);
	}

	/**
	 * Helper function for base64url encoding
	 *
	 * @param string $data
	 * @return string
	 */
	private static function base64UrlEncode($data) {
		return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
	}

	/**
	 * Log diagnostic messages to a dedicated file in the plugin folder
	 *
	 * @param string $message
	 */
	public static function writeLog($message) {
		error_log($message);
		$path = defined('ILJ_PATH') ? ILJ_PATH : dirname(__DIR__) . '/';
		$log_file = $path . 'vertex_ai_debug.log';
		$log_entry = '[' . date('Y-m-d H:i:s') . '] ' . $message . PHP_EOL;
		@file_put_contents($log_file, $log_entry, FILE_APPEND);
	}
}
