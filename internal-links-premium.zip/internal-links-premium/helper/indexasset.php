<?php
namespace ILJ\Helper;

use ILJ\Core\Options as CoreOptions;
use ILJ\Posttypes\CustomLinks;
use ILJ\Helper\Blacklist;
use ILJ\Backend\Editor;
use ILJ\Core\App;
use ILJ\Database\Linkindex;
use ILJ\Database\LinkindexIndividualTemp;
use ILJ\Database\LinkindexTemp;
use ILJ\Helper\Misc;

/**
 * Toolset for linkindex assets
 *
 * Methods for handling linkindex data
 *
 * @package ILJ\Helper
 * @since   1.1.0
 */
class IndexAsset {

	const ILJ_FILTER_INDEX_ASSET          = 'ilj_index_asset_title';
	const ILJ_FILTER_MUFFIN_BUILDER_FIELD = 'ilj_index_mb_field';

	const ILJ_FULL_BUILD       = 'full';
	const ILJ_INDIVIDUAL_BUILD = 'individual';

	/**
	 * Returns all meta data to a specific asset from index
	 *
	 * @since  1.1.0
	 * @param  int    $id   The id of the asset
	 * @param  string $type The type of the asset (post, term or custom)
	 * @return object
	 */
	public static function getMeta($id, $type) {
		if (!\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			if ('post' != $type || 'post_meta' == $type) {
				return null;
			}
		}

		if ('post' == $type || 'post_meta' == $type) {
			$post = get_post($id);

			if (!$post) {
				return null;
			}

			$asset_title    = $post->post_title;
			$asset_url      = get_the_permalink($post->ID);
			$asset_url_edit = get_edit_post_link($post->ID);
		}

		if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			if ('post' != $type && 'post_meta' != $type) {
				switch ($type) {
					case 'term':
						$term = get_term($id);

						if (!$term || is_wp_error($term)) {
							return null;
						}

						$asset_title    = $term->name;
						$asset_url      = get_term_link($term);
						$asset_url_edit = get_edit_term_link($term->term_id, $term->taxonomy);
						break;
					case 'term_meta':
						$term = get_term($id);

						if (!$term || is_wp_error($term)) {
							return null;
						}

						$asset_title    = $term->name;
						$asset_url      = get_term_link($term);
						$asset_url_edit = get_edit_term_link($term->term_id, $term->taxonomy);
						break;
					case 'custom':
						$asset_title    = get_the_title($id);
						$asset_url      = get_post_meta(
							$id,
							\ILJ\Posttypes\CustomLinks::ILJ_FIELD_CUSTOM_LINKS_URL,
							true
						);
						$asset_url_edit = get_edit_post_link($id);
						break;
					default:
						return null;
				}
			}
		}

		if (!isset($asset_title) || !isset($asset_url)) {
			return null;
		}

		$meta_data = (object) array(
			'title'    => $asset_title,
			'url'      => $asset_url,
			'url_edit' => $asset_url_edit,
		);

		/**
		 * Filters the index asset
		 *
		 * @since 1.6.0
		 *
		 * @param object $meta_data The index asset
		 * @param string $type The asset type
		 * @param int $id The asset id
		 */
		$meta_data = apply_filters(self::ILJ_FILTER_INDEX_ASSET, $meta_data, $type, $id);

		return $meta_data;
	}

	/**
	 * Returns all relevant posts for linking
	 *
	 * @param  mixed $fetch_fields Optional, define the needed fields in some use case
	 * @since  1.2.0
	 * @return array
	 */
	public static function getPosts($fetch_fields = null) {
		$whitelist = CoreOptions::getOption(\ILJ\Core\Options\Whitelist::getKey());
		if (!is_array($whitelist) || !count($whitelist)) {
			return array();
		}
		
		global $wpdb;
		$addition_query = '';
		$blacklisted_posts = Blacklist::getBlacklistedList('post');

		// If fetch_fields is null use default Fields
		$default_fields = array('ID', 'post_content');
		if (null != $fetch_fields) {
			$fields = $fetch_fields;
		} else {
			$fields = $default_fields;
		}

		if (!empty($blacklisted_posts)) {
			$addition_query = ' ID NOT IN ('.self::escape_array($blacklisted_posts).') AND ';
		}

		if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			if (!empty($blacklisted_posts) && CoreOptions::getOption(\ILJ\Core\Options\BlacklistChildPages::getKey())) {
				$addition_query .= ' post_parent NOT IN ('.self::escape_array($blacklisted_posts).') AND ';
			}
		}

		// this separates the $fields with comma
		$fields_placeholder = implode(', ', $fields);

		$post_query = "SELECT $fields_placeholder FROM $wpdb->posts WHERE". $addition_query ." post_type IN (".self::escape_array($whitelist).") AND post_status = 'publish' ORDER BY ID DESC ";
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- Direct query necessary for fetching posts dynamically, caching is not applicable.
		$posts = $wpdb->get_results($post_query, OBJECT);
		return $posts;
	}

	/**
	 * Returns relevant post ids for linking
	 *
	 * @since  2.0.3
	 * @param  mixed $building_batch_size
	 * @param  mixed $offset
	 *
	 * @return array
	 */
	public static function getPostsBatched($building_batch_size, $offset) {
		$whitelist = CoreOptions::getOption(\ILJ\Core\Options\Whitelist::getKey());
		if (!is_array($whitelist) || !count($whitelist)) {
			return array();
		}

		$args = array(
			'posts_per_page'   => $building_batch_size,
			'post__not_in'     => Blacklist::getBlacklistedList('post'),
			'post_type'        => $whitelist,
			'post_status'      => array('publish'),
			'suppress_filters' => true,
			'offset'           => $offset,
			'orderby'          => 'ID',
			'order'            => 'DESC',
			'lang'             => 'all',
			'fields'           => 'ids',
		);
		if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			if (CoreOptions::getOption(\ILJ\Core\Options\BlacklistChildPages::getKey())) {

				$args['post_parent__not_in'] = Blacklist::getBlacklistedList('post');
			}
		}

		$query = new \WP_Query($args);

		return $query->posts;
	}

	/**
	 * Returns all relevant term ids for linking
	 *
	 * @since  1.2.0
	 * @param  mixed $building_batch_size
	 * @param  mixed $offset
	 *
	 * @return array
	 */
	public static function getTermsBatched__premium_only($building_batch_size, $offset) {
		 $whitelist = CoreOptions::getOption(\ILJ\Core\Options\TaxonomyWhitelist::getKey());
		if (!is_array($whitelist) || !count($whitelist)) {
			return array();
		}

		$args = array(
			'taxonomy'         => $whitelist,
			'number'           => $building_batch_size,
			'exclude'          => Blacklist::getBlacklistedList('term'),
			'hide_empty'       => false,
			'suppress_filters' => true,
			'offset'           => $offset,
			'orderby'          => 'term_id',
			'order'            => 'DESC',
			'lang'             => 'all',
			'fields'           => 'ids',
		);

		$taxonomies = new \WP_Term_Query($args);
		return $taxonomies->terms;
	}

	/**
	 * Returns all relevant terms for linking
	 *
	 * @param  mixed $fetch_fields Optional, define the needed fields in some use case
	 * @since  1.2.0
	 * @return array
	 */
	public static function getTerms__premium_only($fetch_fields = null) {
		$whitelist = CoreOptions::getOption(\ILJ\Core\Options\TaxonomyWhitelist::getKey());
		if (!is_array($whitelist) || !count($whitelist)) {
			return array();
		}

		global $wpdb;
		$blacklisted_terms = Blacklist::getBlacklistedList('term');
		if (!is_array($blacklisted_terms) || !count($blacklisted_terms)) {
			$blacklisted_terms = array(-1); // just a negative integer that will never exist as a primary key
		}

		// If fetch_fields is null use default Fields
		$default_fields = array('t.term_id', 'tt.description');
		if (null != $fetch_fields) {
			$fields = $fetch_fields;
		} else {
			$fields = $default_fields;
		}

		// this separates the $fields with comma
		$fields_placeholder = implode(', ', $fields);

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Already prepared.
		$term_query = $wpdb->prepare("SELECT $fields_placeholder FROM $wpdb->terms AS t INNER JOIN $wpdb->term_taxonomy AS tt ON t.term_id = tt.term_id WHERE tt.taxonomy IN (".self::escape_array($whitelist).") and t.term_id NOT IN (%s) ORDER BY t.term_id DESC", self::escape_array($blacklisted_terms));
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Direct query required for taxonomy filtering, caching is not applicable.
		$terms = $wpdb->get_results($term_query, OBJECT);
		return $terms;
	}

	/**
	 * Returns all custom links for linking
	 *
	 * @since  1.2.0
	 * @return array
	 */
	public static function getCustomLinks__premium_only() {
		$args = array(
			'posts_per_page'   => -1,
			'post_type'        => CustomLinks::ILJ_POSTTYPE_CUSTOM_LINKS_SLUG,
			'post_status'      => array('publish'),
			'suppress_filters' => true,
			'orderby'          => 'ID',
			'order'            => 'DESC',
			'lang'             => 'all',
		);

		 $query = new \WP_Query($args);

		 return $query->posts;
	}

	/**
	 * Gets the concrete type of an asset
	 *
	 * @since 1.2.5
	 * @param string $id   ID of asset
	 * @param string $type Generic type of asset
	 *
	 * @return string
	 */
	public static function getDetailedType($id, $type) {
		if ('post' == $type) {
			$detailed_type = get_post_type($id);
		}

		if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			switch ($type) {
				case 'custom':
					$detailed_type = $type;
					break;
				case 'term':
					$term = get_term($id);
					if ($term) {
						$detailed_type = $term->taxonomy;
					}
					break;
				case 'post_meta':
					$detailed_type = 'post_meta';
					break;
				case 'term_meta':
					$detailed_type = 'term_meta';
					break;
			}
		}

		return $detailed_type;
	}

	/**
	 * Checks if two posts are in the same taxonomy
	 *
	 * @since 1.2.14
	 * @param int    $link_from ID of post the link is coming from
	 * @param int    $link_to   ID of post the link is going to
	 * @param string $type      Generic type of asset
	 *
	 * @return bool
	 */
	public static function postsInSameTaxonomy__premium_only($link_from, $link_to, $type) {
		if ('post' != $type && 'post_meta' != $type) {
			return false;
		}

		$taxonomies = CoreOptions::getOption(\ILJ\Core\Options\LimitTaxonomyList::getKey());
		if (empty($taxonomies)) {
			return false;
		}

		foreach ($taxonomies as $taxonomy) {
			$has_tax_from = has_term('', $taxonomy, $link_from);
			$has_tax_to   = has_term('', $taxonomy, $link_to);

			if ($has_tax_from || $has_tax_to) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Checks if two posts share the same term
	 *
	 * @since 1.2.14
	 * @param int    $link_from ID of post the link is coming from
	 * @param int    $link_to   ID of post the link is going to
	 * @param string $type      Generic type of asset
	 *
	 * @return boolean
	 */
	public static function postsInSameTerm__premium_only($link_from, $link_to, $type) {
		if ('post' != $type && 'post_meta' != $type) {
			return false;
		}

		$post_from = get_post($link_from);
		$post_to   = get_post($link_to);

		if (!$post_from || !$post_to) {
			return false;
		}

		if (CustomLinks::ILJ_POSTTYPE_CUSTOM_LINKS_SLUG == $post_to->post_type) {
			return true;
		}

		$taxonomies = CoreOptions::getOption(\ILJ\Core\Options\LimitTaxonomyList::getKey());

		if (empty($taxonomies)) {
			return false;
		}

		foreach ($taxonomies as $taxonomy) {
			$tax_from = wp_get_post_terms($post_from->ID, $taxonomy, array('fields' => 'ids'));
			$tax_to   = wp_get_post_terms($post_to->ID, $taxonomy, array('fields' => 'ids'));

			$same_tax = array_intersect($tax_from, $tax_to);
			if (count($same_tax) > 0) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Get Limit Links meta and Max incoming links meta value
	 *
	 * @param  int    $link_to post ID
	 * @param  string $type
	 * @return array
	 */
	public static function getLimitLinksMetas__premium_only($link_to, $type) {
		$limit_metas = 0;
		if ('post' == $type || 'custom' == $type) {
			$is_limit_enabled  = get_post_meta($link_to, Editor::ILJ_META_KEY_LIMITINCOMINGLINKS, true);
			$max_incoming_links    = get_post_meta($link_to, Editor::ILJ_META_KEY_MAXINCOMINGLINKS, true);
			$limit_metas = array(
				/**
				 * This filter is used to customize whether the limit needs to be applied on incoming links.
				 *
				 * @param $is_limit_enabled bool Boolean to indicate if the limit is enabled
				 *
				 * @since 2.23.5
				 */
				Editor::ILJ_META_KEY_LIMITINCOMINGLINKS => apply_filters('ilj_limit_incoming_links', $is_limit_enabled),
				/**
				 * This filter is used to customize the max amount of incoming links allowed.
				 *
				 * @param $is_limit_enabled bool Boolean to indicate if the limit is enabled
				 * @param $max_incoming_links int The allowed number of incoming links
				 *
				 * @since 2.23.5
				 */
				Editor::ILJ_META_KEY_MAXINCOMINGLINKS   => apply_filters('ilj_max_incoming_links', $max_incoming_links, $is_limit_enabled)
			);

		} elseif ('term' == $type) {
			$is_limit_enabled  = get_term_meta($link_to, Editor::ILJ_META_KEY_LIMITINCOMINGLINKS, true);
			$max_incoming_links    = get_term_meta($link_to, Editor::ILJ_META_KEY_MAXINCOMINGLINKS, true);
			$limit_metas = array(
				/**
				 * This filter is used to customize whether the limit needs to be applied on incoming links.
				 *
				 * @param $is_limit_enabled bool Boolean to indicate if the limit is enabled
				 *
				 * @since 2.23.5
				 */
				Editor::ILJ_META_KEY_LIMITINCOMINGLINKS => apply_filters('ilj_limit_incoming_links', $is_limit_enabled),
				/**
				 * This filter is used to customize the max amount of incoming links allowed.
				 *
				 * @param $is_limit_enabled bool Boolean to indicate if the limit is enabled
				 * @param $max_incoming_links int The allowed number of incoming links
				 *
				 * @since 2.23.5
				 */
				Editor::ILJ_META_KEY_MAXINCOMINGLINKS   => apply_filters('ilj_max_incoming_links', $max_incoming_links, $is_limit_enabled)
			);

		}




		return $limit_metas;
	}

	/**
	 * Get Incoming Links Count
	 *
	 * @param  int    $id           Post/term ID to count incoming links
	 * @param  string $type
	 * @param  string $scope
	 * @param  int    $exclude_id   Exclude this Post/term ID to count incoming links
	 * @param  string $exclude_type
	 * @return int
	 */
	public static function getIncomingLinksCount($id, $type, $scope, $exclude_id = null, $exclude_type = null) {
		global $wpdb;
		// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Direct query is necessary and caching is not applicable.
		if (self::ILJ_FULL_BUILD == $scope) {
			$ilj_linkindex_table = $wpdb->prefix . LinkindexTemp::ILJ_DATABASE_TABLE_LINKINDEX_TEMP;
		} elseif (self::ILJ_INDIVIDUAL_BUILD == $scope) {
			$ilj_linkindex_table = $wpdb->prefix . LinkindexIndividualTemp::ILJ_DATABASE_TABLE_LINKINDEX_INDIVIDUAL_TEMP;
		}
		$query = '';
		if (null != $exclude_id) {
			$ilj_linkindex_table     = $wpdb->prefix . Linkindex::ILJ_DATABASE_TABLE_LINKINDEX;
			$query                   = " AND (link_from != '" . $exclude_id . "' AND type_from = '" . $exclude_type . "')";
			$incoming_links_old      = $wpdb->get_var("SELECT count(link_to) FROM $ilj_linkindex_table WHERE (link_to = '" . $id . "' AND type_to = '" . $type . "') " . $query);
			$ilj_linkindex_table_new = $wpdb->prefix . LinkindexIndividualTemp::ILJ_DATABASE_TABLE_LINKINDEX_INDIVIDUAL_TEMP;

			$incoming_links_new = $wpdb->get_var("SELECT count(link_to) FROM $ilj_linkindex_table_new WHERE (link_from != 0 AND type_from != '') AND ((link_to = '" . $id . "' AND type_to = '" . $type . "'))");

			$incoming_links = (int) $incoming_links_old + (int) $incoming_links_new;
			return (int) $incoming_links;
		}
		$incoming_links = $wpdb->get_var("SELECT count(link_to) FROM $ilj_linkindex_table WHERE (link_from != 0 AND type_from != '') AND ((link_to = '" . $id . "' AND type_to = '" . $type . "') " . $query . ')');
		// phpcs:enable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return (int) $incoming_links;
	}

	/**
	 * Get Outgoing Links Count
	 *
	 * @param  int    $id    Post/Tax ID
	 * @param  string $type  Type
	 * @param  string $scope
	 * @return int
	 */
	public static function getOutgoingLinksCount($id, $type, $scope) {
		global $wpdb;

		if (self::ILJ_FULL_BUILD == $scope) {
			$ilj_linkindex_table = $wpdb->prefix . LinkindexTemp::ILJ_DATABASE_TABLE_LINKINDEX_TEMP;
		} elseif (self::ILJ_INDIVIDUAL_BUILD == $scope) {
			$ilj_linkindex_table = $wpdb->prefix . Linkindex::ILJ_DATABASE_TABLE_LINKINDEX;
		}

		$additional_query = '';

		if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			$additional_query = " OR type_from = '" . $type . "_meta' ";
		}

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Direct query required for fetching link count, and caching is not applicable.
		$outgoing = $wpdb->get_var("SELECT count(link_from) FROM $ilj_linkindex_table WHERE (link_to != 0 AND type_to != '') AND (link_from = '" . $id . "' AND (type_from = '" . $type . "' " . $additional_query . '))');
		return (int) $outgoing;
	}

	/**
	 * Get the already linked url count
	 *
	 * @param  int    $link_to_id
	 * @param  int    $id
	 * @param  string $type
	 * @param  string $scope
	 * @return int
	 */
	public static function getLinkedUrlsCount($link_to_id, $id, $type, $scope) {
		global $wpdb;
		if (self::ILJ_FULL_BUILD == $scope) {
			$ilj_linkindex_table = $wpdb->prefix . LinkindexTemp::ILJ_DATABASE_TABLE_LINKINDEX_TEMP;
		} elseif (self::ILJ_INDIVIDUAL_BUILD == $scope) {
			$ilj_linkindex_table = $wpdb->prefix . LinkindexIndividualTemp::ILJ_DATABASE_TABLE_LINKINDEX_INDIVIDUAL_TEMP;
		}

		$additional_query = '';

		if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			$additional_query = " OR type_from = '" . $type . "_meta' ";
		}

		$linked_url_value = array();

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Direct query required for fetching link count, and caching is not applicable.
		$linked_urls = $wpdb->get_var("SELECT count(link_to) FROM $ilj_linkindex_table WHERE (link_from = '" . $id . "' AND link_to = '" . $link_to_id . "' AND (type_from = '" . $type . "' " . $additional_query . '))');

		$linked_url_value[$link_to_id] = (int) $linked_urls;

		return $linked_urls;
	}

	/**
	 * Get Linked Anchors
	 *
	 * @param  int    $id    Post/Tax ID
	 * @param  string $type  Type
	 * @param  string $scope
	 * @return mixed
	 */
	public static function getLinkedAnchors($id, $type, $scope) {
		 global $wpdb;
		if (self::ILJ_FULL_BUILD == $scope) {
			$ilj_linkindex_table = $wpdb->prefix . LinkindexTemp::ILJ_DATABASE_TABLE_LINKINDEX_TEMP;
		} elseif (self::ILJ_INDIVIDUAL_BUILD == $scope) {
			$ilj_linkindex_table = $wpdb->prefix . LinkindexIndividualTemp::ILJ_DATABASE_TABLE_LINKINDEX_INDIVIDUAL_TEMP;
		}

		$additional_query = '';

		if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			$additional_query = " OR type_from = '" . $type . "_meta' ";
		}

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Direct query required for fetching post keyword, and caching is not applicable.
		$linked_anchors = $wpdb->get_results("SELECT anchor FROM $ilj_linkindex_table WHERE (link_to != 0 AND type_to != '' AND anchor != '') AND (link_from = '" . $id . "' AND (type_from = '" . $type . "' " . $additional_query . '))', ARRAY_A);

		$anchors = array();
		foreach ($linked_anchors as $value) {
			$anchors[] = $value['anchor'];
		}
		return $anchors;
	}

	/**
	 * Checks if the phrase is included in the blacklist of keywords
	 *
	 * @param  int    $link_from post/term ID
	 * @param  string $phrase    string to check for
	 * @param  string $type      could be term/post
	 * @return bool
	 */
	public static function checkIfBlacklistedKeyword($link_from, $phrase, $type) {

		if ('post' == $type || 'post_meta' == $type) {
			$keyword_blacklist = get_post_meta($link_from, Editor::ILJ_META_KEY_BLACKLISTDEFINITION, true);
		}
		if ('term' == $type || 'term_meta' == $type) {
			$keyword_blacklist = get_term_meta($link_from, Editor::ILJ_META_KEY_BLACKLISTDEFINITION, true);
		}

		if (!empty($keyword_blacklist) || false != $keyword_blacklist) {
			if (!\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
				$keyword_blacklist = array_slice($keyword_blacklist, 0, 2);
			}
			foreach ($keyword_blacklist as $keyword) {

				if (strtolower($phrase) == strtolower($keyword)) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * This function removes post/term metas that starts with _ or ilj_
	 *
	 * @param  array $allmeta Array of all meta fields
	 * @return array $custom_fields Array of custom metas
	 */
	public static function filter_custom_fields($allmeta) {

		$custom_fields = array();

		if ($allmeta) {
			foreach ($allmeta as $value) {
				if (substr($value['meta_key'], 0, 1) != '_' && substr($value['meta_key'], 0, 4) != 'ilj_') {
					$custom_fields[$value['meta_key']] = $value['meta_value'];
				}
			}
		}

		$custom_fields = array_map('Misc::maybe_unserialize', $custom_fields);
		return $custom_fields;
	}

	/**
	 * Get specific custom fields of post/term set in the ilj settings
	 *
	 * @param  string $type
	 * @return string
	 */
	public static function getCustomFieldsValue__premium_only($type) {
		$data   = array();
		$id_key = '';

		if ('term' == $type) {
			$data   = self::getTerms__premium_only();
			$id_key = 'term_id';
		} else {
			$data   = self::getPosts();
			$id_key = 'ID';
		}

		if ('term' == $type) {
			$allmeta = CoreOptions::getOption(\ILJ\Core\Options\CustomFieldsToLinkTerm::getKey());
		} else {
			$allmeta = CoreOptions::getOption(\ILJ\Core\Options\CustomFieldsToLinkPost::getKey());
		}

		if (!is_array($allmeta)) {
			return '';
		}
		$custom_fields = Custom_Fields::from_custom_field_names($allmeta);
		$object = array();
		if (!empty($data)) {
			foreach ($data as $item) {
				$result = array();
				if ('term' == $type) {
					$term_custom_fields = $custom_fields->expand_term_custom_fields(intval($item->{$id_key}));
					foreach ($term_custom_fields as $value) {
						$field_value = self::getMetaData($item->{$id_key}, 'term', $value);
						if ('' != $field_value || !empty($field_value) || null != $field_value) {
							$result[] = $field_value;
						}
					}
				} else {
					$post_custom_fields = $custom_fields->expand_post_custom_fields(intval($item->ID));
					foreach ($post_custom_fields as $value) {
						$field_value = self::getMetaData($item->{$id_key}, 'post', $value);
						if ('' != $field_value || !empty($field_value) || null != $field_value) {
							if (CustomMetaData::ILJ_MUFFIN_BUILDER_META_FIELD == $value) {
								$field_value = apply_filters(self::ILJ_FILTER_MUFFIN_BUILDER_FIELD, $field_value);
							}
							if (CustomMetaData::ILJ_OXYGEN_BUILDER_META_FIELD == $value) {
								$field_value = do_shortcode($field_value);
							}
							$result[] = $field_value;
						}
					}
				}
				if (!empty($result)) {
					$content = '';
					foreach ($result as $value) {
						if ('' != $value) {
							$content .= wpautop($value);
						}
					}

					$object[] = array(
						'ID'           => $item->{$id_key},
						'custom_field' => $content,
					);
				}
			}
		}
		return wp_json_encode($object);
	}

	 /**
	  * Get specific custom fields value per id
	  *
	  * @param  int    $id
	  * @param  string $type
	  * @return array
	  */
	public static function getCustomFieldsValuePerID__premium_only($id, $type) {
		$data   = array();
		$id_key = '';

		if ('term' == $type) {
			$data   = get_term($id);
			$id_key = 'term_id';
		} else {
			$data   = get_post($id);
			$id_key = 'ID';
		}

		if ('term' == $type) {
			$allmeta = CoreOptions::getOption(\ILJ\Core\Options\CustomFieldsToLinkTerm::getKey());
		} else {
			$allmeta = CoreOptions::getOption(\ILJ\Core\Options\CustomFieldsToLinkPost::getKey());
		}

		if (!is_array($allmeta)) {
			return array();
		}
		$object = array();
		if (!empty($data)) {
			$custom_fields = array();
			if ('term' == $type) {
				foreach ($allmeta as $value) {
					$field_value = self::getMetaData($data->{$id_key}, 'term', $value);
					if ('' != $field_value || !empty($field_value)) {
						$custom_fields[] = $field_value;
					}
				}
			} else {
				foreach ($allmeta as $value) {
					$field_value = self::getMetaData($data->{$id_key}, 'post', $value);
					if ('' != $field_value || !empty($field_value)) {
						// if ($value == "mfn-page-items") {
						// $field_value = apply_filters(self::ILJ_FILTER_MUFFIN_BUILDER_FIELD, $field_value);
						// }
						// if ($value == "ct_builder_shortcodes") {
						// $field_value = do_shortcode($field_value);
						// }
						$custom_fields[] = $field_value;
					}
				}
			}
			if (!empty($custom_fields)) {
				$content = '';
				foreach ($custom_fields as $value) {
					if ('' != $value) {
						$content .= wpautop($value);
					}
				}
				$object = array(
					'ID'           => $data->{$id_key},
					'custom_field' => $content,
				);
			}
		}

		return $object;
	}

	/**
	 * Get the metadata from database
	 *
	 * @param  int    $id
	 * @param  string $type
	 * @param  mixed  $key
	 * @param  bool   $single
	 * @return mixed
	 */
	public static function getMetaData($id, $type, $key = null, $single = true) {
		global $wpdb;

		if (!is_numeric($id)) {
			return;
		}

		$type_key = 'post_id';
		$table    = $wpdb->postmeta;

		if ('term' == $type) {
			$type_key = 'term_id';
			$table    = $wpdb->termmeta;
		}
		$query = " AND meta_key = '$key' ";
		if (null == $key) {
			$query = '';
		}

		$data = 'meta_value';
		if (!$single) {
			$data = '*';
		}

		$select = 'SELECT ' . $data . ' FROM ' . $table;

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Already prepared.
		$query = $wpdb->prepare($select . " WHERE $type_key = %d " . $query, $id);

		if ($single) {
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Direct query required for fetching post meta value, and caching is not applicable.
			$meta_data = $wpdb->get_var($query);
		} elseif (!$single) {
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Direct query required for fetching post meta value, and caching is not applicable.
			$meta_data = $wpdb->get_results($query, ARRAY_A);
		}

		return $meta_data;
	}

	/**
	 * Escape Array for WPDB Query
	 *
	 * @param  mixed $arr
	 * @return void
	 */
	public static function escape_array($arr) {
		global $wpdb;
		if (is_array($arr) && !empty($arr)) {
			$escaped = array();
			foreach ($arr as $v) {
				// Remove extra slashes
				$v = stripslashes($v);
				if (is_numeric($v)) {
					$escaped[] = $wpdb->prepare('%d', $v);
				} else {
					$escaped[] = $wpdb->prepare('%s', $v);
				}
			}
			return implode(',', $escaped);
		}
		return $arr;
	}
}
