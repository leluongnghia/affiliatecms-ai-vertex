<?php
namespace ILJ\Helper;

/**
 * Helper: CKey API integration
 *
 * @package ILJ\Helper
 */
class Ckey {

	/**
	 * Log diagnostic messages to a dedicated file
	 *
	 * @param string $message
	 */
	public static function writeLog($message) {
		error_log($message);
		$path = defined('ILJ_PATH') ? ILJ_PATH : dirname(__DIR__) . '/';
		$log_file = $path . 'ckey_debug.log';
		$log_entry = '[' . date('Y-m-d H:i:s') . '] ' . $message . PHP_EOL;
		@file_put_contents($log_file, $log_entry, FILE_APPEND);
	}

	/**
	 * Generate content using Ckey
	 *
	 * @param string $prompt
	 * @param array  $options
	 * @return string|\WP_Error
	 */
	public static function generateContent($prompt, $options = array()) {
		$api_key = \ILJ\Core\Options::getOption(\ILJ\Core\Options\CkeyKey::getKey());
		if (empty($api_key)) {
			return new \WP_Error('no_api_key', __('Ckey API key not configured', 'internal-links'));
		}

		$model = \ILJ\Core\Options::getOption(\ILJ\Core\Options\CkeyModel::getKey());
		if (empty($model)) {
			$model = 'haidinhphu1704/claude-opus-4.8-kiro';
		}
		
		$temperature = isset($options['temperature']) ? $options['temperature'] : 0.3;
		// Anthropic Claude Messages API requires max_tokens (Set to 6000 to prevent Ckey gateway timeouts)
		$max_tokens = isset($options['max_tokens']) ? max(6000, $options['max_tokens']) : 6000;

		$isAnthropicMessages = (strpos($model, '/') !== false && strpos($model, 'claude') !== false);

		if ($isAnthropicMessages) {
			$endpoint = 'https://api.xah.io/v1/messages';
			$headers = array(
				'Authorization'     => 'Bearer ' . $api_key,
				'Content-Type'      => 'application/json',
				'anthropic-version' => '2023-06-01',
			);
			$body = array(
				'model'       => $model,
				'max_tokens'  => $max_tokens,
				'messages'    => array(
					array(
						'role'    => 'user',
						'content' => $prompt,
					),
				),
				'temperature' => $temperature,
			);
			$log_format = 'Claude messages format';
		} else {
			$endpoint = 'https://api.xah.io/v1/chat/completions';
			$headers = array(
				'Authorization' => 'Bearer ' . $api_key,
				'Content-Type'  => 'application/json',
			);
			$body = array(
				'model'       => $model,
				'max_tokens'  => $max_tokens,
				'messages'    => array(
					array(
						'role'    => 'user',
						'content' => $prompt,
					),
				),
				'temperature' => $temperature,
			);
			$log_format = 'OpenAI completions format';
		}

		self::writeLog("Ckey request initiated ({$log_format}) to {$endpoint} with model: {$model}");

		$max_retries = 3;
		$retry_count = 0;
		$response = null;
		$status_code = 0;

		while ($retry_count <= $max_retries) {
			$response = wp_remote_post($endpoint, array(
				'headers' => $headers,
				'body'    => wp_json_encode($body),
				'timeout' => 1200, // 20 minutes for long-form content generation
			));

			if (is_wp_error($response)) {
				self::writeLog('Ckey request failed: ' . $response->get_error_message());
				return $response;
			}

			$status_code = wp_remote_retrieve_response_code($response);

			// Handle 429 Rate Limit and 5xx Server/Gateway Errors
			if (($status_code === 429 || ($status_code >= 500 && $status_code <= 504)) && $retry_count < $max_retries) {
				$retry_count++;
				$wait_time = ($status_code === 429) ? ($retry_count * 15) : 5;
				self::writeLog("Ckey API error ($status_code). Retrying in {$wait_time}s... (Attempt {$retry_count}/{$max_retries})");
				sleep($wait_time);
				continue;
			}

			break;
		}

		$response_body = wp_remote_retrieve_body($response);
		$data = json_decode($response_body, true);

		if ($status_code !== 200) {
			$error_detail = isset($data['error']['message']) ? $data['error']['message'] : "Unknown API Error (Status: $status_code)";
			self::writeLog("Ckey generation failed with model: $model. Msg: $error_detail");
			return new \WP_Error('ckey_error', sprintf(__('Ckey Error (%s): %s', 'internal-links'), $model, $error_detail));
		}

		$content = '';
		if (isset($data['content']) && is_array($data['content'])) {
			foreach ($data['content'] as $block) {
				if (isset($block['type']) && $block['type'] === 'text' && isset($block['text'])) {
					$content .= $block['text'];
				} elseif (!isset($block['type']) && isset($block['text'])) {
					$content .= $block['text'];
				}
			}
			$content = trim($content);
		} elseif (isset($data['choices'][0]['message']['content'])) {
			$content = trim($data['choices'][0]['message']['content']);
		}

		if (empty($content)) {
			$finish_reason = isset($data['stop_reason']) ? $data['stop_reason'] : 'unknown';
			self::writeLog("Ckey completely failed with model: $model. Returned empty response. Finish Reason: $finish_reason");
			return new \WP_Error('ckey_error', sprintf(__('Ckey Error (%s): API returned empty content. Stop Reason: %s', 'internal-links'), $model, $finish_reason));
		}

		self::writeLog("Ckey content generated successfully. Length: " . strlen($content));
		return $content;
	}

	/**
	 * Validate API key
	 *
	 * @param string $api_key
	 * @return bool|\WP_Error
	 */
	public static function validateApiKey($api_key) {
		if (empty($api_key)) {
			return new \WP_Error('no_api_key', __('Ckey API key not configured', 'internal-links'));
		}

		$response = wp_remote_get('https://api.xah.io/v1/models', array(
			'headers' => array(
				'Authorization' => 'Bearer ' . $api_key,
			),
			'timeout' => 15,
		));

		if (is_wp_error($response)) {
			return $response;
		}

		$status_code = wp_remote_retrieve_response_code($response);
		if ($status_code !== 200) {
			$body = wp_remote_retrieve_body($response);
			$data = json_decode($body, true);
			$error_detail = isset($data['error']['message']) ? $data['error']['message'] : $body;
			return new \WP_Error('invalid_api_key', sprintf(__('Invalid Ckey API key or configuration: %s', 'internal-links'), substr($error_detail, 0, 200)));
		}

		return true;
	}
}
