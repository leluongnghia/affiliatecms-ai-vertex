<?php
namespace ILJ\Helper;

use ILJ\Backend\Editor;
use ILJ\Core\LinkBuilder;
use ILJ\Core\Links\Text_To_Link_Converter_Factory;
use ILJ\Core\Options;
use ILJ\Posttypes\CustomLinks;
use ILJ\Helper\Misc;

/**
 * This is where custom meta data output is filtered
 *
 * @package ILJ\Helper
 * @since   2.0.0
 */
class CustomMetaData {

	/**
	 * LinkBuilder for postmeta
	 *
	 * @var LinkBuilder
	 */
	private $link_builder_postmeta;

	/**
	 * LinkBuilder for termmeta
	 *
	 * @var LinkBuilder
	 */
	private $link_builder_termmeta;

	const ILJ_MUFFIN_BUILDER_META_FIELD = 'mfn-page-items';
	const ILJ_OXYGEN_BUILDER_META_FIELD = 'ct_builder_shortcodes';

	/**
	 * Builds Custom Field links for custom fields
	 *
	 * @param  string $check
	 * @param  int    $id
	 * @param  string $meta_key
	 * @param  bool   $single
	 * @param  string $meta_type
	 * @return array
	 */
	public function build_custom_field_link__premium_only($check, $id, $meta_key, $single, $meta_type) {
		$blacklist_meta_fields = array(Editor::ILJ_META_KEY_LIMITLINKSPERPARAGRAPH, Editor::ILJ_META_KEY_LINKSPERPARAGRAPH, Editor::ILJ_META_KEY_BLACKLISTDEFINITION, CustomLinks::ILJ_FIELD_CUSTOM_LINKS_OPTION_NEW_WINDOW, CustomLinks::ILJ_FIELD_CUSTOM_LINKS_OPTION_NOFOLLOW, CustomLinks::ILJ_FIELD_CUSTOM_LINKS_URL);
		if (in_array($meta_key, $blacklist_meta_fields)) {
			return;
		}

		if ('' == $meta_key) {
			return;
		}

		if (self::ILJ_OXYGEN_BUILDER_META_FIELD == $meta_key) {
			remove_filter('get_post_metadata', array($this, 'build_custom_field_link__premium_only'), 10, 5);
			return;
		}

		if (self::ILJ_MUFFIN_BUILDER_META_FIELD == $meta_key) {
			return $this->link_mfn_builder_meta_field__premium_only($id, $meta_type, $meta_key);
		}

		$custom_fields_to_link_post = Options::getOption(\ILJ\Core\Options\CustomFieldsToLinkPost::getKey());
		$custom_fields_to_link_term = Options::getOption(\ILJ\Core\Options\CustomFieldsToLinkTerm::getKey());

		if ('post' == $meta_type) {
			if (!is_array($custom_fields_to_link_post)) {
				return;
			}
			if (!$this->can_field_be_linked($meta_key, $custom_fields_to_link_post)) {
				return;
			}

			remove_filter('get_post_metadata', array($this, 'build_custom_field_link__premium_only'), 10, 5);
			if (!isset($this->link_builder_postmeta)) {
				$this->link_builder_postmeta = Text_To_Link_Converter_Factory::create($id, 'post_meta');
			}
			$content = get_post_meta($id, $meta_key, true);
			add_filter('get_post_metadata', array($this, 'build_custom_field_link__premium_only'), 10, 5);
			$content2 = $this->link_builder_postmeta->link_content($content);
		}

		if ('term' == $meta_type) {
			if (!is_array($custom_fields_to_link_term)) {
				return;
			}
			if (!$this->can_field_be_linked($meta_key, $custom_fields_to_link_term)) {
				return;
			}

			remove_filter('get_term_metadata', array($this, 'build_custom_field_link__premium_only'), 10, 5);
			if (!isset($this->link_builder_termmeta)) {
				$this->link_builder_termmeta = Text_To_Link_Converter_Factory::create($id, 'term_meta');
			}
			$content = get_term_meta($id, $meta_key, true);
			add_filter('get_term_metadata', array($this, 'build_custom_field_link__premium_only'), 10, 5);
			$content2 = $this->link_builder_termmeta->link_content($content);
		}

		return array($content2);
	}

	/**
	 * Function to decode muffin builder field value and apply linkindex rules and return back to base 64_decode value
	 * Apply Links to muffin builder field
	 *
	 * @param  int    $id
	 * @param  string $meta_type
	 * @param  string $meta_key
	 * @return string | void
	 */
	public function link_mfn_builder_meta_field__premium_only($id, $meta_type, $meta_key) {

		$custom_fields_to_link_post = Options::getOption(\ILJ\Core\Options\CustomFieldsToLinkPost::getKey());

		if ('post' !== $meta_type || !is_array($custom_fields_to_link_post) || !in_array($meta_key, $custom_fields_to_link_post)) {
			return;
		}

		try {
			remove_filter('get_post_metadata', array($this, 'build_custom_field_link__premium_only'), 10, 5);
			$link_builder_postmeta = Text_To_Link_Converter_Factory::create($id, 'post_meta', null, 'json');
			$content_without_links = get_post_meta($id, $meta_key, true);
			// The content from muffin builder can be either base64 encoded string which needs to be unserialized
			// or an associative array ( differs based on version )
			if ($content_without_links && ! is_array($content_without_links)) {
				$content_without_links = is_serialized($content_without_links) ? Misc::unserialize($content_without_links) : Misc::unserialize(base64_decode($content_without_links));
			}
			$content_without_links = wp_json_encode($content_without_links);
			add_filter('get_post_metadata', array($this, 'build_custom_field_link__premium_only'), 10, 5);
			$linked_content = $link_builder_postmeta->link_content($content_without_links);
			return base64_encode(serialize(json_decode($linked_content, true)));
		} catch (\Throwable $e) {

			return;
		}
	}

	/**
	 * Determines if the custom field can be linked.
	 *
	 * @param string $meta_key
	 * @param array  $saved_custom_fields
	 *
	 * @return boolean
	 */
	private function can_field_be_linked($meta_key, $saved_custom_fields) {
		if (in_array($meta_key, $saved_custom_fields)) {
			return true;
		}
		// we can check if we have any regex rules inside the configured options.
		foreach ($saved_custom_fields as $regex_rule) {
			if (!Regex_Custom_Field::is_valid_rule($regex_rule)) {
				continue;
			}
			$rule = Regex_Custom_Field::from($regex_rule);
			if ($rule->meta_key_matches_rule($meta_key)) {
				return true;
			}

		}

		return false;
	}
}
