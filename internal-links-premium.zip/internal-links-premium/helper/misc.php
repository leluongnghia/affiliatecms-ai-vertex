<?php
namespace ILJ\Helper;

use function ILJ\ilj_try_include_file;

if (!class_exists('Brumann\Polyfill\DisallowedClassesSubstitutor')) ilj_try_include_file('vendor/brumann/polyfill-unserialize/src/DisallowedClassesSubstitutor.php', 'require_once');
if (!class_exists('Brumann\Polyfill\Unserialize')) ilj_try_include_file('vendor/brumann/polyfill-unserialize/src/Unserialize.php', 'require_once');

/**
 * Loader
 *
 * Class for miscellaneous methods.
 *
 * @package ILJ\Helper
 */
final class Misc {

	/**
	 * Unserializes data only if it was serialized.
	 *
	 * @param string $data Data that might be unserialized.
	 * @return mixed Unserialized data can be any type.
	 */
	public static function maybe_unserialize($data) {
		if (is_serialized($data)) { // Don't attempt to unserialize data that wasn't serialized going in.
			return self::unserialize(trim($data), false);
		}
		return $data;
	}

	/**
	 * Unserialize data while maintaining compatibility across PHP versions due to different number of arguments required by PHP's "unserialize" function
	 *
	 * @param string        $serialized_data Data to be unserialized, should be one that is already serialized
	 * @param boolean|array $allowed_classes Either an array of class names which should be accepted, false to accept no classes, or true to accept all classes
	 * @param integer       $max_depth       The maximum depth of structures permitted during unserialization, and is intended to prevent stack overflows
	 * @return mixed Unserialized data can be any of types (integer, float, boolean, string, array or object)
	 */
	public static function unserialize($serialized_data, $allowed_classes = false, $max_depth = 0) {
		if (version_compare(PHP_VERSION, '5.2', '<=')) {
			$result = unserialize($serialized_data); // For PHP 5.2 users, the search-replace feature has been removed, meaning that any input provided in this context will not undergo search-replace processing
		} else {
			$result = call_user_func(array('Brumann\Polyfill\Unserialize', 'unserialize'), $serialized_data, array('allowed_classes' => $allowed_classes, 'max_depth' => $max_depth));
		}
		return $result;
	}

	/**
	 * Replace SEO title placeholders from Rank Math, Yoast SEO, or basic fallback.
	 *
	 * @param string   $text
	 * @param \WP_Post $post
	 * @return string
	 */
	public static function replaceSeoPlaceholders($text, $post) {
		if (empty($text) || !$post) {
			return $text;
		}

		// Rank Math replacement
		if (class_exists('\RankMath\Helper')) {
			$text = \RankMath\Helper::replace_vars($text, $post);
		}

		// Yoast SEO replacement
		if (function_exists('wpseo_replace_vars')) {
			$text = wpseo_replace_vars($text, $post);
		}

		// Basic fallback replacements if plugins are not active or didn't replace them
		$replacements = array(
			'%year%'        => date('Y'),
			'%currentyear%' => date('Y'),
		);

		// Try to replace %keyword% or %Keyword% if found
		if (stripos($text, '%keyword%') !== false) {
			$focus_keyword = '';
			if (metadata_exists('post', $post->ID, 'rank_math_focus_keyword')) {
				$focus_keyword = get_post_meta($post->ID, 'rank_math_focus_keyword', true);
			} elseif (metadata_exists('post', $post->ID, '_yoast_wpseo_focuskw')) {
				$focus_keyword = get_post_meta($post->ID, '_yoast_wpseo_focuskw', true);
			}

			if (!empty($focus_keyword)) {
				// Focus keyword might be comma-separated, take the first one
				$keywords_array = explode(',', $focus_keyword);
				$first_keyword = trim(reset($keywords_array));
				if (!empty($first_keyword)) {
					$replacements['%keyword%'] = $first_keyword;
					$replacements['%Keyword%'] = ucwords($first_keyword);
				}
			}
		}

		// If %product_count% is still there, try to count items in the content
		if (stripos($text, '%product_count%') !== false) {
			$count = self::estimateProductCount($post->post_content);
			if ($count > 0) {
				$replacements['%product_count%'] = $count;
			} else {
				$replacements['%product_count%'] = '';
			}
		}

		$text = str_ireplace(array_keys($replacements), array_values($replacements), $text);

		return $text;
	}

	/**
	 * Estimate product count from post content as fallback
	 *
	 * @param string $content
	 * @return int
	 */
	private static function estimateProductCount($content) {
		$count = 0;
		if (preg_match_all('/<(h2|h3|h4)[^>]*>(.*?)<\/\1>/i', $content, $matches)) {
			foreach ($matches[2] as $heading) {
				$heading = trim(wp_strip_all_tags($heading));
				if (preg_match('/^\d+[\.\)\-]/', $heading)) {
					$count++;
				}
			}
		}
		if ($count === 0) {
			if (preg_match_all('/<li[^>]*>(.*?)<\/li>/i', $content, $matches)) {
				$count = count($matches[0]);
			}
		}
		return $count;
	}
}
