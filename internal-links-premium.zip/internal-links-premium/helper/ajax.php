<?php
namespace ILJ\Helper;

use ILJ\Backend\AdminMenu;
use ILJ\Backend\BatchInfo;
use ILJ\Backend\Editor;
use ILJ\Backend\Environment;
use ILJ\Backend\MenuPage\Tools;
use ILJ\Backend\User;
use ILJ\Cache\Transient_Cache;
use ILJ\Core\IndexBuilder;
use ILJ\Core\Options as CoreOptions;
use ILJ\Data\Content;
use ILJ\Database\Keywords;
use ILJ\Database\DatabaseCollation;
use ILJ\Database\Postmeta;
use ILJ\Enumeration\Content_Type;
use ILJ\Helper\IndexAsset;
use ILJ\Database\Linkindex;
use ILJ\Helper\BatchInfo as HelperBatchInfo;
use ILJ\Statistics\Link;
use ILJ\Type\KeywordList;

/**
 * Ajax toolset
 *
 * Methods for handling AJAX requests
 *
 * @package ILJ\Helper
 *
 * @since 1.0.0
 */
class Ajax {
	const ILJ_FILTER_AJAX_SEARCH_POSTS = 'ilj_ajax_search_posts';
	const ILJ_FILTER_AJAX_SEARCH_TERMS = 'ilj_ajax_search_terms';
	
	private static $cached_html = null;

	/**
	 * Ajax handler to save the keywords for post / term.
	 *
	 * @return void
	 */
	public static function save_keywords_for_content__premium_only() {
		if (!check_admin_referer('ilj_save_keywords_for_content') || !current_user_can('manage_options')) {
			return;
		}
		$id = isset($_REQUEST['id']) ? intval($_REQUEST['id']) : 0;
		$keywords = isset($_REQUEST['keywords']) && is_array($_REQUEST['keywords']) ? array_map('sanitize_text_field', wp_unslash($_REQUEST['keywords'])) : array();
		$content_type = false;
		$sub_type = null;
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Unslash and Sanitized in the below line.
		if (isset($_REQUEST['content_type']) && is_string($_REQUEST['content_type']) && Content_Type::is_valid($_REQUEST['content_type'])) {
			$content_type = sanitize_text_field(wp_unslash($_REQUEST['content_type']));
		}
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Unslash and Sanitized in the below line.
		if (isset($_REQUEST['sub_type']) && is_string($_REQUEST['sub_type']) && Content_Type::is_valid($_REQUEST['sub_type'])) {
			$sub_type = sanitize_text_field(wp_unslash($_REQUEST['sub_type']));
		}
		if ($id && $content_type) {
			Content::from_content_type_and_id($content_type, $sub_type, $id)->set_keywords(KeywordList::fromInput(join(",", $keywords)));
		}
		die();
	}

	/**
	 * Searches the posts for a given phrase
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function searchPostsAction() {
		if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'ilj-search-posts-action')) {
			die();
		}
		if (!current_user_can('manage_options')) {
			return;
		}
		if (!isset($_POST['search']) && !isset($_POST['per_page']) && !isset($_POST['page'])) {
			wp_die();
		}

		$search   = sanitize_text_field(wp_unslash($_POST['search']));
		$per_page = (int) $_POST['per_page'];
		$page     = (int) $_POST['page'];

		$args = array(
			's'              => $search,
			'posts_per_page' => $per_page,
			'paged'          => $page,
		);

		$query = new \WP_Query($args);

		$data = array();

		foreach ($query->posts as $post) {
			$data[] = array(
				'id'   => $post->ID,
				'text' => $post->post_title,
			);
		}

		/**
		 * Filters the output of ajax post search
		 *
		 * @since 1.1.6
		 *
		 * @param object $data The return data (found posts)
		 * @param array  $args The arguments for the post query
		 */
		$data = apply_filters(self::ILJ_FILTER_AJAX_SEARCH_POSTS, $data, $args);

		wp_send_json($data);
		wp_die();
	}

	/**
	 * Rebuilds the link index
	 *
	 * @since 2.0.0
	 *
	 * @return void
	 */
	public static function indexRebuildAction() {
		if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'ilj-dashboard')) {
			die();
		}
		if (!current_user_can('manage_options')) {
			return;
		}
		try {
			do_action(IndexBuilder::ILJ_INITIATE_BATCH_REBUILD);

			$response = array(
				'status'  => 'success',
				'message' => sprintf('<p class="message">' . __('Lập lịch xây dựng lại chỉ mục thành công.', 'internal-links') . '</p>'),
			);
		} catch (\Exception $e) {
			$response = array(
				'status'  => 'error',
				'message' => sprintf('<p class="message">' . __('Đã xảy ra lỗi khi bắt đầu xây dựng lại chỉ mục.', 'internal-links') . '</p>'),
			);
		}

		wp_send_json($response);
		wp_die();
	}

	/**
	 * Searches the terms for a given phrase
	 *
	 * @since 1.0.1
	 *
	 * @return void
	 */
	public static function searchTermsAction__premium_only() {
		if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'ilj-search-terms-action')) {
			wp_die();
		}
		if (!current_user_can('manage_options')) {
			return;
		}
		if (!isset($_POST['search']) && !isset($_POST['per_page']) && !isset($_POST['page'])) {
			wp_die();
		}

		$search   = sanitize_text_field(wp_unslash($_POST['search']));
		$per_page = (int) $_POST['per_page'];
		$page     = (int) $_POST['page'];

		$taxonomies = get_taxonomies(
			array(
				'public'   => true,
				'_builtin' => false,
			)
		);

		$taxonomies = array_merge($taxonomies, array('category', 'post_tag'));

		$args = array(
			'taxonomy'   => $taxonomies,
			'search'     => $search,
			'number'     => $per_page,
			'offset'     => $per_page * ($page - 1),
			'hide_empty' => false,
		);

		$query = new \WP_Term_Query($args);

		$data = array();

		if ($query->terms && !empty($query) && !is_wp_error($query)) {
			foreach ($query->terms as $term) {
				$taxonomy = get_taxonomy($term->taxonomy);
				$data[]   = array(
					'id'   => $term->term_id,
					'text' => $term->name.' ['.$taxonomy->label.']',
				);
			}
		}

		/**
		 * Filters the output of ajax terms search
		 *
		 * @since 1.1.6
		 *
		 * @param object $data The return data (found terms)
		 * @param array  $args The arguments for the term query
		 */
		$data = apply_filters(self::ILJ_FILTER_AJAX_SEARCH_TERMS, $data, $args);

		wp_send_json($data);
		wp_die();
	}

	/**
	 * Renders the statistics for the links
	 *
	 * @since 1.2.5
	 *
	 * @param int $start_count Determine what index to start counting
	 * @param int $chunk_size  The size of the batch to loop into
	 * @return String
	 */
	public static function render_links_statistic_action($start_count, $chunk_size) {
		$statistics = Statistic::getLinkStatistics();

		if (!count($statistics) && 0 == $start_count) {
			return;
		} elseif (!count($statistics) && 0 < $start_count) {
			return null;
		}

		for ($i = $start_count; $i < min($start_count + $chunk_size, count($statistics)); $i++) {
			$statistic = $statistics[$i];
			$asset_data = IndexAsset::getMeta($statistic->asset_id, $statistic->asset_type);

			if (!$asset_data) {
				continue;
			}

			$edit_link  = sprintf('<a href="%s" class="tip" title="' . __('Biên tập', 'internal-links') . '">%s</a>', $asset_data->url_edit, '<span class="dashicons dashicons-edit"></span>');
			$asset_link = sprintf('<a href="%s" class="tip" title="' . __('Mở', 'internal-links') . '" target="_blank" rel="noopener">%s</a>', $asset_data->url, '<span class="dashicons dashicons-external"></span>');

			$elements_to   = $statistic->elements_to ? '<a title="' . __('Hiển thị các liên kết đến', 'internal-links') . '" class="tip ilj-statistic-detail" data-id="' . $statistic->asset_id . '" data-type="' . $statistic->asset_type . '" data-direction="to">' . $statistic->elements_to . '</a>' : '-';
			$elements_from = $statistic->elements_from ? '<a title="' . __('Hiển thị các liên kết đi', 'internal-links') . '" class="tip ilj-statistic-detail" data-id="' . $statistic->asset_id . '" data-type="' . $statistic->asset_type . '" data-direction="from">' . $statistic->elements_from . '</a>' : '-';

			$type = IndexAsset::getDetailedType($statistic->asset_id, $statistic->asset_type);

			self::$cached_html .= '<tr>';
			self::$cached_html .= '<td class="asset-title">' . $asset_data->title . '</td>';
			self::$cached_html .= '<td>' . Statistic::getConfiguredKeywordsCountForAsset($statistic->asset_id, $statistic->asset_type) . '</td>';
			self::$cached_html .= '<td class="type" data-search="' .  $statistic->asset_type . ';' . $type . '"><span data-type="' . $statistic->asset_type . '">' . $type . '</span></td>';
			self::$cached_html .= '<td>' . $elements_to . '</td>';
			self::$cached_html .= '<td>' . $elements_from . '</td>';
			self::$cached_html .= '<td>' . $edit_link . ' ' . $asset_link . '</td>';
			self::$cached_html .= '</tr>';
		}
		echo wp_kses_post(self::$cached_html);
	}

	/**
	 * Renders the statistics for the anchor texts
	 *
	 * @since 1.2.5
	 *
	 * @param  array $request Data of the datatable form send to server for populating datagrid
	 * @return array
	 */
	public static function render_anchors_statistic($request) {
		$record_data = array();
		$statistics = Statistic::get_anchor_statistics($request);
		foreach ($statistics['data'] as $statistic) {
			$record_data[] = array(esc_html($statistic->anchor), intval(strlen($statistic->anchor)), intval(count(explode(' ', $statistic->anchor))), '<a title="' . __('Hiển thị mức sử dụng', 'internal-links') . '" class="tip ilj-statistic-detail" data-anchor="' . esc_attr($statistic->anchor) . '">' . esc_html($statistic->frequency) . '</a>');
		}
		$statistics['data'] = $record_data;
		return $statistics;
	}

	/**
	 * Retrieves link data for a specific asset by a given direction (in- or outgoing)
	 *
	 * @since 1.1.0
	 *
	 * @return void
	 */
	public static function renderLinkDetailStatisticAction() {
		if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'ilj-dashboard') || !current_user_can('manage_options')) {
			die();
		}
		if (!isset($_POST['id']) || !isset($_POST['type']) || !isset($_POST['direction'])) {
			wp_die();
		}

		$id        = (int) $_POST['id'];
		$type      = sanitize_text_field(wp_unslash($_POST['type']));
		$direction = sanitize_text_field(wp_unslash($_POST['direction']));

		$directive_links = Linkindex::getDirectiveLinks($id, $type, $direction);

		if (!count($directive_links)) {
			wp_die();
		}

		$direction_header = '';

		if ('from' == $direction) {
			$direction_header = __('Mục tiêu', 'internal-links');
		} elseif ('to' == $direction) {
			$direction_header = __('Nguồn', 'internal-links');
		}

		$data = '<table class="ilj-statistic-detail-table display"><thead><tr><th>' . $direction_header . '</th><th>' . __('Kiểu', 'internal-links') . '</th><th>' . __('Văn bản neo', 'internal-links') . '</th></tr></thead>';
		$data .= '<tbody>';

		$row_counter = 0;

		for ($i=0; $i < count($directive_links); $i++) {
			$directive_link = $directive_links[$i];

			if (!\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
				if ($i >= 3) {
					break;
				}
			}

			if (!property_exists($directive_link, 'link_' . $direction) || !property_exists($directive_link, 'type_' . $direction) || !property_exists($directive_link, 'anchor')) {
				continue;
			}

			if ('from' == $direction) {
				$reverse_direction = 'to';
			} elseif ('to' == $direction) {
				$reverse_direction = 'from';
			}

			$type = IndexAsset::getDetailedType($directive_link->{'link_' . $reverse_direction}, $directive_link->{'type_' . $reverse_direction});
			$asset_data = IndexAsset::getMeta($directive_link->{'link_' . $reverse_direction}, $directive_link->{'type_' . $reverse_direction});

			if (!$asset_data) {
				continue;
			}

			$data .= '<tr class="' . ((0 === $row_counter % 2) ? 'even' : 'odd') . '"><td><a href="' . $asset_data->url . '" rel="noopener" target="_blank">' . $asset_data->title . '</a></td><td class="type"><span data-type="' . $directive_link->{'type_' . $reverse_direction} . '">' . $type . '</span></td><td>' . $directive_link->anchor . '</td></tr>';

			$row_counter++;
		}

		$data .= '</tbody>';
		$data .= '</table>';

		if (!\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			if (count($directive_links) > 3) {
				$data .= '<div class="ilj-statistic-detail-hidden spacer">';
				$data .= '	<div class="more"><span class="dashicons dashicons-lock"></span> and ' . (count($directive_links) - 3) . ' more</div>';
				$data .= '  <div class="upgrade">';
				$data .= '      <p>'.__('Với phiên bản cơ bản miễn phí, bạn có thể xem 3 liên kết đầu tiên ở chế độ xem chi tiết.', 'internal-links').'</p>';
				$data .= '      <a href="' . get_admin_url(null, 'admin.php?page=' . AdminMenu::ILJ_MENUPAGE_SLUG . '-pricing') . '"><span class="dashicons dashicons-unlock"></span> ' . __('Nâng cấp lên Pro và xem tất cả', 'internal-links') . '</a>';
				$data .= '  </div>';
				$data .= '</div>';
			}
		}

		echo wp_kses_post($data);
		wp_die();
	}

	/**
	 * Renders link details for a specific anchor text
	 *
	 * @since  1.1.0
	 * @return void
	 */
	public static function renderAnchorDetailStatisticAction() {
		if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'ilj-dashboard') || !current_user_can('manage_options')) {
			die();
		}
		if (!isset($_POST['anchor'])) {
			wp_die();
		}

		$data = '';

		if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			$anchor = sanitize_text_field(wp_unslash((string) $_POST['anchor']));
			$anchor_links = Linkindex::getByAnchor__premium_only($anchor);

			if (!count($anchor_links)) {
				wp_die();
			}

			$data = '<table class="ilj-statistic-detail-table display"><thead><tr><th>' . __('Nguồn', 'internal-links') . '</th><th>' . __('Loại nguồn', 'internal-links') . '</th><th>' . __('Mục tiêu', 'internal-links') . '</th><th>' . __('Loại mục tiêu', 'internal-links') . '</th></tr></thead><tbody>';
			$row_counter = 0;

			foreach ($anchor_links as $link) {
				$asset_data_from = IndexAsset::getMeta($link->link_from, $link->type_from);
				$asset_data_to   = IndexAsset::getMeta($link->link_to, $link->type_to);

				if (!$asset_data_from || !$asset_data_to) {
					continue;
				}

				$type_from_detailed = IndexAsset::getDetailedType($link->link_from, $link->type_from);
				$type_to_detailed = IndexAsset::getDetailedType($link->link_to, $link->type_to);

				$data .= '<tr class="' . ((0 === $row_counter % 2) ? 'even' : 'odd') . '"><td><a href="' . $asset_data_from->url . '" target="_blank" rel="noopener">' . $asset_data_from->title . '</a></td><td class="type"><span data-type="' .  $link->type_from . '">' . $type_from_detailed . '</span></td><td><a href="' . $asset_data_to->url . '" target="_blank" rel="noopener">' . $asset_data_to->title . '</td><td class="type"><span data-type="' .  $link->type_to . '">' . $type_to_detailed . '</span></td></tr>';

				$row_counter++;
			}

			$data .= '</tbody></table>';
		}

		if (!\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			$data = '<div class="ilj-statistic-detail-hidden">';
			$data .= '  <div class="upgrade">';
			$data .= '      <p>'.__('Chế độ xem chi tiết cho văn bản liên kết là một phần của phiên bản Pro.', 'internal-links').'</p>';
			$data .= '      <a href="' . get_admin_url(null, 'admin.php?page=' . AdminMenu::ILJ_MENUPAGE_SLUG . '-pricing') . '"><span class="dashicons dashicons-unlock"></span> ' . __('Nâng cấp lên Pro và xem tất cả', 'internal-links') . '</a>';
			$data .= '  </div>';
			$data .= '</div>';
		}

		echo wp_kses_post($data);
		wp_die();
	}

	/**
	 * Hides the promo box in the sidebar
	 *
	 * @since  1.1.2
	 * @return void
	 */
	public static function hidePromo() {
		if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'ilj-general-nonce')) {
			die;
		}
		if (!current_user_can('manage_options')) {
			return;
		}
		User::update('hide_promo', true);
		wp_die();
	}

	/**
	 * Handles upload of import files
	 *
	 * @since  1.2.0
	 * @return void
	 */
	public static function uploadImport() {
		if (!isset($_POST['nonce']) || !isset($_POST['file_type'])) {
			wp_send_json_error(null, 400);
		}

		$nonce = sanitize_text_field(wp_unslash($_POST['nonce']));
		$file_type = sanitize_text_field(wp_unslash($_POST['file_type']));

		if (!in_array($file_type, array('settings', 'keywords'))) {
			wp_send_json_error(null, 400);
		}

		if (!wp_verify_nonce($nonce, 'ilj-tools') || !current_user_can('manage_options')) {
			wp_send_json_error(null, 400);
		}

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- It's File upload not user input.
		$uploaded_file = isset($_FILES['file_data']) ? $_FILES['file_data'] : array();

		$upload_overrides = array(
			'test_form' => false,
			'test_type' => false,
		);

		if ('keywords' == $file_type) {
			$uploaded_file['name'] = uniqid(wp_rand(), true) . '.csv';
		}

		$file_upload = wp_handle_upload($uploaded_file, $upload_overrides);

		if (!$file_upload || isset($file_upload['error'])) {
			wp_send_json_error(__('Máy chủ web của bạn không cho phép tải tập tin lên.', 'internal-links') . ' ' . __('Vui lòng khắc phục sự cố và thử lại.', 'internal-links'), 400);
		}

		switch ($file_type) {
			case 'settings':
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Local file.
			$file_content = file_get_contents($file_upload['file']);
			wp_delete_file($file_upload['file']);
			$file_json = Encoding::jsonToArray($file_content);

			if (false === $file_json) {
					wp_send_json_error(null, 400);
			}

			set_transient('ilj_upload_settings', $file_json, HOUR_IN_SECONDS * 12);
				break;
			case 'keywords':
			set_transient('ilj_upload_keywords', $file_upload, HOUR_IN_SECONDS * 12);
				break;
		}

		wp_send_json_success(null, 200);
	}

	/**
	 * Initiates the import of already uploaded and prepared files
	 *
	 * @since  1.2.0
	 * @return void
	 */
	public static function startImport() {
		if (!isset($_POST['nonce']) || !isset($_POST['file_type'])) {
			wp_send_json_error(null, 400);
		}

		$nonce = sanitize_text_field(wp_unslash($_POST['nonce']));
		$file_type = sanitize_text_field(wp_unslash($_POST['file_type']));

		if (!in_array($file_type, array('settings', 'keywords'))) {
			wp_send_json_error(null, 400);
		}

		if (!wp_verify_nonce($nonce, 'ilj-tools') || !current_user_can('manage_options')) {
			wp_send_json_error(null, 400);
		}

		$upload_transient = get_transient('ilj_upload_' . $file_type);

		if (!$upload_transient) {
			wp_send_json_error(__('Hết giờ.', 'internal-links') . ' ' . __('Vui lòng thử tải lên lại', 'internal-links'), 400);
		}

		switch ($file_type) {
			case 'settings':
			$import_count = CoreOptions::importOptions($upload_transient);
				break;
			case 'keywords':
			if (!isset($upload_transient['file']) || !file_exists($upload_transient['file'])) {
					wp_send_json_error(null, 400);
			}
			$import_count = Keyword::importKeywordsFromFile($upload_transient['file']);
			wp_delete_file($upload_transient['file']);
				break;
		}

		if (0 === $import_count) {
			wp_send_json_error(__('Không có gì để nhập hoặc không tìm thấy dữ liệu để nhập.', 'internal-links'), 400);
		}

		do_action(IndexBuilder::ILJ_INITIATE_BATCH_REBUILD);

		delete_transient('ilj_upload_' . $file_type);
		wp_send_json_success(null, 200);
	}

	/**
	 * Handles request for internal keyword import
	 *
	 * @since  1.2.0
	 * @return void
	 */
	public static function importKeywordIntern__premium_only() {
		if (!isset($_POST['nonce']) || !isset($_POST['type_import']) || !isset($_POST['type_selection']) || !isset($_POST['source_import'])) {
			wp_send_json_error(null, 400);
		}

		$nonce = sanitize_text_field(wp_unslash($_POST['nonce']));

		if (!wp_verify_nonce($nonce, 'ilj-tools') || !current_user_can('manage_options')) {
			wp_send_json_error(null, 400);
		}

		$type_import = sanitize_text_field(wp_unslash($_POST['type_import']));
		$type_selection = array_map('sanitize_text_field', (array) wp_unslash($_POST['type_selection']));
		$source_import  = array_map('sanitize_text_field', (array) wp_unslash($_POST['source_import']));

		if (empty($type_selection) || empty($source_import)) {
			wp_send_json_error(null, 400);
		}

		switch ($type_import) {
			case 'post':
			Import::internalPost__premium_only($type_selection, $source_import);
				break;
			case 'term':
			Import::internalTerm__premium_only($type_selection, $source_import);
				break;
		}

		do_action(IndexBuilder::ILJ_INITIATE_BATCH_REBUILD);
		wp_send_json_success(null, 200);
	}

	/**
	 * Renders the Status and info of the Batch Build
	 *
	 * @since 1.3.10
	 *
	 * @return void
	 */
	public static function renderBatchInfo() {
		if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'ilj-general-nonce')) {
			die();
		}
		if (!current_user_can('manage_options')) {
			return;
		}
		$batch_build_info = new HelperBatchInfo();
		$info = $batch_build_info->getBatchInfo();

		wp_send_json($info);
		wp_die();
	}

	/**
	 * Handles clear all transient ajax action
	 *
	 * @return void
	 */
	public static function clear_all_transient() {
		if (!check_admin_referer('ilj_clear_all_transient') || !current_user_can('manage_options')) {
			return;
		}
		Transient_Cache::delete_all();
		\ILJ\ilj_fs()->add_sticky_admin_message(__('Bộ nhớ đệm đã bị xóa.', 'internal-links'), 'ilj_clear_all_transient_notice');
		wp_safe_redirect(wp_get_referer());
		die();
	}

	/**
	 * Loads chunks of links statistics data to table
	 *
	 * @since 2.23.4
	 *
	 * @return array
	 */
	public static function load_link_statistics() {
		if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'ilj-dashboard') || !current_user_can('manage_options')) {
			die();
		}

		$table_columns = array('title', 'keywords_count', 'type', 'incoming_links', 'outgoing_links');
		$sort_by = 'title';
		if (isset($_REQUEST['order'][0]['column'])) {
			$sort_column_index = intval($_REQUEST['order'][0]['column']);
			if ($sort_column_index < count($table_columns)) {
				$sort_by = $table_columns[$sort_column_index];
			}
		}

		$sort_direction = 'ASC';
		if (isset($_REQUEST['order'][0]['dir']) && 'desc' === $_REQUEST['order'][0]['dir']) {
			$sort_direction = 'DESC';
		}

		$link_statistics = new Link(array(
			'sort_by' => $sort_by,
			'sort_direction' => $sort_direction,
			'limit' => isset($_REQUEST['length']) ? intval($_REQUEST['length']) : 10,
			'offset' => isset($_REQUEST['start']) ? intval($_REQUEST['start']) : 0,
			'search' => isset($_REQUEST['search']['value']) && is_string($_REQUEST['search']['value']) ? sanitize_text_field(wp_unslash($_REQUEST['search']['value'])) : '',
			'main_types' => isset($_REQUEST['main_types']) && !empty($_REQUEST['main_types']) && is_string($_REQUEST['main_types']) ? explode(',', sanitize_text_field(wp_unslash($_REQUEST['main_types']))) : array(),
			'sub_types' => isset($_REQUEST['sub_types']) && !empty($_REQUEST['sub_types']) && is_string($_REQUEST['sub_types']) ? explode(',', sanitize_text_field(wp_unslash($_REQUEST['sub_types']))) : array(),

		));


		$total = $link_statistics->get_total();


		/**
		 * `recordsTotal`, `recordsFiltered` are standard property names for pagination in data tables
		 *
		 * @see https://datatables.net/examples/data_sources/server_side
		 */
		echo wp_json_encode(array(
			'recordsTotal' => $total,
			'recordsFiltered' => $link_statistics->get_filtered_results_count(),
			'data' => $link_statistics->get_statistics(),
			'draw' => isset($_REQUEST['draw']) ? intval($_REQUEST['draw']) : 0
		));
		die();
	}

	/**
	 * Handles clear single transient ajax action
	 *
	 * @return void
	 */
	public static function clear_single_transient() {
		if (!check_admin_referer('ilj_clear_single_transient') || !current_user_can('manage_options')) {
			return;
		}
		$id   = isset($_REQUEST['ilj_transient_id']) ? sanitize_text_field(wp_unslash($_REQUEST['ilj_transient_id'])) : '';
		$type = isset($_REQUEST['ilj_transient_type']) ? sanitize_text_field(wp_unslash($_REQUEST['ilj_transient_type'])) : '';
		if (!$id || !in_array($type, array('post', 'term'), true)) {
			return;
		}
		Transient_Cache::delete_cache_for_content(intval($id), $type);
		/* Dont print notice because the ui using this flag will have inbuilt feedback instead of printing the notice */
		if (!isset($_REQUEST['ilj_skip_notice'])) {
			/* translators: %s: Post Type */
			$message = 'post' === $type ? sprintf(__('Bộ nhớ đệm cho %s đã bị xóa.', 'internal-links'), get_post_type($id)) : __('Bộ nhớ đệm cho thuật ngữ này đã bị xóa.', 'internal-links');
			\ILJ\ilj_fs()->add_sticky_admin_message($message, 'ilj_clear_single_transient_notice');
			wp_safe_redirect(wp_get_referer());
		}
		die();
	}

	/**
	 * Loads chunks of anchor statistics data to table
	 *
	 * @since 2.23.4
	 *
	 * @return void
	 */
	public static function load_anchor_statistics_chunk_callback() {
		if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'ilj-dashboard')) {
			die();
		}

		if (!current_user_can('manage_options')) {
			return;
		}
		$request = $_POST;
		$html_chunk = Ajax::render_anchors_statistic($request);
		echo wp_json_encode($html_chunk);
		die();
	}

	/**
	 * Cancels the index rebuild schedules
	 *
	 * @since 2.23.5
	 *
	 * @return void
	 */
	public static function cancel_all_schedules() {
		if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'ilj-cancel-all-schedule-action')) {
			die();
		}
		if (!current_user_can('manage_options')) {
			return;
		}
		Cleanup::clean_scheduled_actions();
		HelperBatchInfo::reset_batch_info();

		wp_send_json_success(null, 200);
		wp_die();
	}
	
	/**
	 * Check added keyword if there's a duplicate
	 *
	 * @return void
	 */
	public static function check_duplicate_keyword__premium_only() {

		if (!current_user_can('edit_posts')) {
			wp_die(esc_html__('Người dùng trái phép', 'internal-links'), 403);
		}

		if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'ilj-editor-action')) {
			wp_die(esc_html__('Xác minh không thành công', 'internal-links'), 403);
		}

		$keyword = isset($_POST['keyword']) ? sanitize_text_field(wp_unslash($_POST['keyword'])) : '';
		$id = isset($_POST['item-id']) ? sanitize_text_field(wp_unslash($_POST['item-id'])) : null;
		$item_type = isset($_POST['item-type']) ? sanitize_text_field(wp_unslash($_POST['item-type'])) : null;
		$item_sub_type = isset($_POST['item-sub-type']) ? sanitize_text_field(wp_unslash($_POST['item-sub-type'])) : null;

		$value = Keywords::check_if_keyword_has_duplicate__premium_only($keyword, $id, $item_type, $item_sub_type);

		if ("" != $value) {
			echo wp_kses_post($value);
			wp_die();
		}

		echo false;
		wp_die();
	}

	/**
	 * Renders the keyword details for duplicate keywords
	 *
	 * @return void
	 */
	public static function render_keyword_duplicate_details__premium_only() {

		if (!current_user_can('edit_posts')) {
			wp_die(esc_html__('Người dùng trái phép', 'internal-links'), 403);
		}

		if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'ilj-editor-action')) {
			wp_die(esc_html__('Xác minh không thành công', 'internal-links'), 403);
		}

		if (!isset($_POST['keyword'])) {
			wp_die();
		}

		$data = '';
		$keyword = sanitize_text_field(wp_unslash($_POST['keyword']));
		$id = sanitize_text_field(wp_unslash($_POST['item-id']));
		$main_type = sanitize_text_field(wp_unslash($_POST['item-type']));
		$keyword_duplicates = Keywords::get_keyword_duplicates__premium_only($keyword, $id, $main_type);

		if (!is_array($keyword_duplicates) || count($keyword_duplicates) === 0) {
			wp_die();
		}

		$data = '<table class="ilj-keyword-duplicate-details-table display">
					<thead>
						<tr>
							<th>' . esc_html__('Nguồn', 'internal-links') . '</th>
							<th>' . esc_html__('Loại nguồn', 'internal-links') . '</th>'.
						'</tr>
					</thead>
					<tbody>';

		$exclude_self = false;
		if (isset($_POST['item-id']) && null != $_POST['item-id'] && isset($_POST['item-type']) && null != $_POST['item-type']) {
			$exclude_self = true;
			$item_id = sanitize_text_field(wp_unslash($_POST['item-id']));
			$item_type = sanitize_text_field(wp_unslash($_POST['item-type']));
		}

		foreach ($keyword_duplicates as $asset) {
			if ($exclude_self) {
				if ($asset->id == $item_id && strtolower($asset->data_type) == strtolower($item_type)) {
					continue;
				}
			}
			$permalink = esc_url(get_permalink($asset->id));
			$title = esc_html($asset->title);
			$main_type = ("ilj_customlinks" === $asset->data_type) ? "custom" : esc_html($asset->main_type);
			$data_type = esc_html($asset->data_type);
			
			$data .= "<tr>";
			$data .= "<td><a href='" . $permalink . "' rel='noopener noreferrer' target='_blank'>" . $title . "</a></td>";
			$data .= "<td class='type'><span data-type='" . $main_type . "'>" . $data_type . "</span></td>";
			$data .= "</tr>";
		}

		$data .= '</tbody></table>';

		echo wp_kses_post($data);
		wp_die();
	}

	/**
	 * Fix database collation issues
	 *
	 * @since 2.24.4
	 *
	 * @return void
	 */
	public static function fix_database_collation() {
		if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'ilj-fix-database-collation-action')) {
			die();
		}
		if (!current_user_can('manage_options')) {
			return;
		}
		DatabaseCollation::modify_collation();

		wp_send_json_success(null, 200);
		wp_die();
	}

	/**
	 * Generate keywords using OpenAI
	 *
	 * @return void
	 */
	public static function generateAiKeywords() {
		if (!current_user_can('edit_posts')) {
			wp_send_json_error(__('Người dùng trái phép', 'internal-links'), 403);
			wp_die();
		}

		if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'ilj-editor-action')) {
			wp_send_json_error(__('Xác minh không thành công', 'internal-links'), 403);
			wp_die();
		}

		$prompt_temp  = \ILJ\Core\Options::getOption(\ILJ\Core\Options\OpenAIPrompt::getKey());
		$max_keywords = \ILJ\Core\Options::getOption(\ILJ\Core\Options\OpenAIMaxKeywords::getKey());

		if (empty($prompt_temp)) {
			$prompt_temp = \ILJ\Core\Options\OpenAIPrompt::getDefault();
		}
		if (empty($max_keywords)) {
			$max_keywords = \ILJ\Core\Options\OpenAIMaxKeywords::getDefault();
		}

		$title   = isset($_POST['title']) ? sanitize_text_field(wp_unslash($_POST['title'])) : '';
		$content = isset($_POST['content']) ? wp_kses_post(wp_unslash($_POST['content'])) : '';

		// Strip tags and trim content to reasonable size to prevent token waste
		$content = wp_strip_all_tags($content);
		if (strlen($content) > 6000) {
			$content = substr($content, 0, 6000) . '...';
		}

		if (empty($title) && empty($content)) {
			wp_send_json_error(__('Post title and content are both empty.', 'internal-links'), 400);
			wp_die();
		}

		$prompt = str_replace(
			array('{title}', '{content}'),
			array($title, $content),
			$prompt_temp
		);

		// Append rule to enforce max keywords limit
		$prompt .= "\n\nPlease generate a maximum of " . intval($max_keywords) . " keywords/phrases.";

		$ai_source = \ILJ\Core\Options::getOption(\ILJ\Core\Options\AiSource::getKey());
		if (empty($ai_source)) {
			$ai_source = 'gemini_api';
		}

		if ('vertex_ai_agent' === $ai_source) {
			$vertex_result = \ILJ\Helper\VertexAI::queryAgent($prompt);
			if (is_wp_error($vertex_result)) {
				wp_send_json_error($vertex_result->get_error_message());
				wp_die();
			}
			$result_text = $vertex_result;
			$response_code = 200;
			$response_body = wp_json_encode(array('candidates' => array(array('content' => array('parts' => array(array('text' => $result_text)))))));
		} elseif ('vertex_ai_api' === $ai_source) {
			$vertex_result = \ILJ\Helper\VertexAI::queryModel($prompt);
			if (is_wp_error($vertex_result)) {
				wp_send_json_error($vertex_result->get_error_message());
				wp_die();
			}
			$result_text = $vertex_result;
			$response_code = 200;
			$response_body = wp_json_encode(array('candidates' => array(array('content' => array('parts' => array(array('text' => $result_text)))))));
		} elseif ('ckey' === $ai_source) {
			$ckey_result = \ILJ\Helper\Ckey::generateContent($prompt);
			if (is_wp_error($ckey_result)) {
				wp_send_json_error($ckey_result->get_error_message());
				wp_die();
			}
			$result_text = $ckey_result;
			$response_code = 200;
			$response_body = wp_json_encode(array('choices' => array(array('message' => array('content' => $result_text)))));
		} elseif ('cliproxy' === $ai_source) {
			$cliproxy_result = \ILJ\Helper\Cliproxy::generateContent($prompt);
			if (is_wp_error($cliproxy_result)) {
				wp_send_json_error($cliproxy_result->get_error_message());
				wp_die();
			}
			$result_text = $cliproxy_result;
			$response_code = 200;
			$response_body = wp_json_encode(array('choices' => array(array('message' => array('content' => $result_text)))));
		} else {
			$api_key = \ILJ\Core\Options::getOption(\ILJ\Core\Options\GeminiKey::getKey());
			$model   = \ILJ\Core\Options::getOption(\ILJ\Core\Options\GeminiModel::getKey());
			if (empty($model)) {
				$model = \ILJ\Core\Options\GeminiModel::getDefault();
			}

			if (empty($api_key)) {
				wp_send_json_error(__('Gemini API Key is missing. Please configure it in Internal Links -> Settings -> AI Settings.', 'internal-links'), 400);
				wp_die();
			}

			$url = sprintf('https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent?key=%s', $model, $api_key);
			$body = array(
				'contents' => array(
					array(
						'parts' => array(
							array(
								'text' => $prompt
							)
						)
					)
				),
				'generationConfig' => array(
					'temperature' => 0.3,
					'responseMimeType' => 'application/json',
					'responseSchema' => array(
						'type' => 'ARRAY',
						'items' => array(
							'type' => 'STRING'
						)
					)
				)
			);

			$response = wp_remote_post($url, array(
				'timeout' => 30,
				'headers' => array(
					'Content-Type' => 'application/json',
				),
				'body'    => wp_json_encode($body)
			));

			if (is_wp_error($response)) {
				wp_send_json_error(sprintf(__('API Request failed: %s', 'internal-links'), $response->get_error_message()));
				wp_die();
			}

			$response_code = wp_remote_retrieve_response_code($response);
			$response_body = wp_remote_retrieve_body($response);

			// Log prompt and response for debugging
			error_log('=== ILJ AI Debug (Single) ===');
			error_log('Prompt: ' . $prompt);
			error_log('Response Body: ' . $response_body);

			if ($response_code !== 200) {
				$error_data = json_decode($response_body, true);
				$error_msg = isset($error_data['error']['message']) ? $error_data['error']['message'] : __('Unknown API error', 'internal-links');
				wp_send_json_error(sprintf(__('Gemini API Error (Code %d): %s', 'internal-links'), $response_code, $error_msg));
				wp_die();
			}

			$data        = json_decode($response_body, true);
			$result_text = isset($data['candidates'][0]['content']['parts'][0]['text']) ? trim($data['candidates'][0]['content']['parts'][0]['text']) : '';
		}

		if (empty($result_text)) {
			wp_send_json_error(__('AI returned empty response.', 'internal-links'));
			wp_die();
		}

		// Extract and sanitize keywords using helper
		$clean_keywords = self::cleanAndExtractKeywords($result_text);
		$keywords_str = implode(',', $clean_keywords);

		if (empty($keywords_str)) {
			wp_send_json_error(__('AI returned no usable keywords. Please try again or adjust the prompt.', 'internal-links'));
			wp_die();
		}

		wp_send_json_success(array('keywords' => $keywords_str));
		wp_die();
	}

	/**
	 * Get list of posts for AI bulk generation
	 *
	 * @return void
	 */
	public static function aiBulkGetPosts() {
		if (!current_user_can('manage_options')) {
			wp_send_json_error(__('Người dùng trái phép', 'internal-links'), 403);
			wp_die();
		}

		if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'ilj-tools')) {
			wp_send_json_error(__('Xác minh không thành công', 'internal-links'), 403);
			wp_die();
		}

		global $wpdb;
		$post_types = isset($_POST['post_types']) ? array_map('sanitize_text_field', (array) $_POST['post_types']) : array();
		$mode       = isset($_POST['mode']) ? sanitize_text_field(wp_unslash($_POST['mode'])) : 'no_keywords';

		if (empty($post_types)) {
			wp_send_json_error(__('Please select at least one post type.', 'internal-links'), 400);
			wp_die();
		}

		$post_types_list = "'" . implode("','", $post_types) . "'";
		$meta_key = \ILJ\Database\Postmeta::ILJ_META_KEY_LINKDEFINITION;

		$ai_processed_key = '_ilj_ai_bulk_processed';

		if ('no_keywords' === $mode) {
			$query = "
				SELECT ID, post_title 
				FROM $wpdb->posts 
				WHERE post_type IN ($post_types_list) 
				AND post_status = 'publish' 
				AND ID NOT IN (
					SELECT post_id 
					FROM $wpdb->postmeta 
					WHERE meta_key = '$meta_key' 
					AND meta_value != '' 
					AND meta_value != 'a:0:{}'
				)
				ORDER BY ID DESC
			";
		} elseif ('skip_processed' === $mode) {
			// Skip posts that were already processed by AI Bulk in a previous run
			$query = "
				SELECT ID, post_title 
				FROM $wpdb->posts 
				WHERE post_type IN ($post_types_list) 
				AND post_status = 'publish' 
				AND ID NOT IN (
					SELECT post_id 
					FROM $wpdb->postmeta 
					WHERE meta_key = '$ai_processed_key'
				)
				ORDER BY ID DESC
			";
		} else {
			$query = "
				SELECT ID, post_title 
				FROM $wpdb->posts 
				WHERE post_type IN ($post_types_list) 
				AND post_status = 'publish'
				ORDER BY ID DESC
			";
		}

		$posts = $wpdb->get_results($query);

		wp_send_json_success(array('posts' => $posts));
		wp_die();
	}

	/**
	 * Process AI keyword generation for a single post in bulk
	 *
	 * @return void
	 */
	/**
	 * Internal worker to process AI keyword generation for a post.
	 * Returns array on success or WP_Error on failure.
	 *
	 * @param int    $post_id
	 * @param string $mode
	 * @return array|\WP_Error
	 */
	public static function processPostAiKeywords($post_id, $mode) {
		$post = get_post($post_id);
		if (!$post || 'publish' !== $post->post_status) {
			return new \WP_Error('post_invalid', __('Post not found or is not published.', 'internal-links'));
		}

		if ('no_keywords' === $mode) {
			$existing = get_post_meta($post_id, \ILJ\Database\Postmeta::ILJ_META_KEY_LINKDEFINITION, true);
			if (is_array($existing) && !empty($existing)) {
				return array('skipped' => true, 'keywords' => implode(',', $existing));
			}
		}

		$prompt_temp  = \ILJ\Core\Options::getOption(\ILJ\Core\Options\OpenAIPrompt::getKey());
		$max_keywords = \ILJ\Core\Options::getOption(\ILJ\Core\Options\OpenAIMaxKeywords::getKey());

		if (empty($prompt_temp)) {
			$prompt_temp = \ILJ\Core\Options\OpenAIPrompt::getDefault();
		}
		if (empty($max_keywords)) {
			$max_keywords = \ILJ\Core\Options\OpenAIMaxKeywords::getDefault();
		}

		$title   = \ILJ\Helper\Misc::replaceSeoPlaceholders($post->post_title, $post);
		$content = wp_strip_all_tags($post->post_content);

		// Limit content to 6k characters
		if (strlen($content) > 6000) {
			$content = substr($content, 0, 6000) . '...';
		}

		$prompt = str_replace(
			array('{title}', '{content}'),
			array($title, $content),
			$prompt_temp
		);

		$prompt .= "\n\nPlease generate a maximum of " . intval($max_keywords) . " keywords/phrases.";

		$ai_source = \ILJ\Core\Options::getOption(\ILJ\Core\Options\AiSource::getKey());
		if (empty($ai_source)) {
			$ai_source = 'gemini_api';
		}

		if ('vertex_ai_agent' === $ai_source) {
			$vertex_result = \ILJ\Helper\VertexAI::queryAgent($prompt, $post_id);
			if (is_wp_error($vertex_result)) {
				return $vertex_result;
			}
			$result_text = $vertex_result;
			$response_code = 200;
			$response_body = wp_json_encode(array('candidates' => array(array('content' => array('parts' => array(array('text' => $result_text)))))));
		} elseif ('vertex_ai_api' === $ai_source) {
			$vertex_result = \ILJ\Helper\VertexAI::queryModel($prompt, $post_id);
			if (is_wp_error($vertex_result)) {
				return $vertex_result;
			}
			$result_text = $vertex_result;
			$response_code = 200;
			$response_body = wp_json_encode(array('candidates' => array(array('content' => array('parts' => array(array('text' => $result_text)))))));
		} elseif ('ckey' === $ai_source) {
			$ckey_result = \ILJ\Helper\Ckey::generateContent($prompt);
			if (is_wp_error($ckey_result)) {
				return $ckey_result;
			}
			$result_text = $ckey_result;
			$response_code = 200;
			$response_body = wp_json_encode(array('choices' => array(array('message' => array('content' => $result_text)))));
		} elseif ('cliproxy' === $ai_source) {
			$cliproxy_result = \ILJ\Helper\Cliproxy::generateContent($prompt);
			if (is_wp_error($cliproxy_result)) {
				return $cliproxy_result;
			}
			$result_text = $cliproxy_result;
			$response_code = 200;
			$response_body = wp_json_encode(array('choices' => array(array('message' => array('content' => $result_text)))));
		} else {
			$api_key = \ILJ\Core\Options::getOption(\ILJ\Core\Options\GeminiKey::getKey());
			$model   = \ILJ\Core\Options::getOption(\ILJ\Core\Options\GeminiModel::getKey());
			if (empty($model)) {
				$model = \ILJ\Core\Options\GeminiModel::getDefault();
			}

			$model_map = array(
				'gemma-4-26b' => 'gemma-4-26b-a4b-it',
				'gemma-4-9b'  => 'gemma-4-9b-it',
				'gemma-2-27b' => 'gemma-2-27b-it',
				'gemma-2-9b'  => 'gemma-2-9b-it',
				'gemma-2-2b'  => 'gemma-2-2b-it'
			);
			if (isset($model_map[$model])) {
				$model = $model_map[$model];
			}

			if (empty($api_key)) {
				return new \WP_Error('api_key_missing', __('Gemini API Key is missing.', 'internal-links'));
			}

			$url = sprintf('https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent?key=%s', $model, $api_key);
			$body = array(
				'contents' => array(
					array(
						'parts' => array(
							array(
								'text' => $prompt
							)
						)
					)
				),
				'generationConfig' => array(
					'temperature' => 0.3,
					'responseMimeType' => 'application/json',
					'responseSchema' => array(
						'type' => 'ARRAY',
						'items' => array(
							'type' => 'STRING'
						)
					)
				)
			);

			$response = wp_remote_post($url, array(
				'timeout' => 30,
				'headers' => array(
					'Content-Type' => 'application/json',
				),
				'body'    => wp_json_encode($body)
			));

			if (is_wp_error($response)) {
				return new \WP_Error('api_request_failed', sprintf(__('Gemini Request failed: %s', 'internal-links'), $response->get_error_message()));
			}

			$response_code = wp_remote_retrieve_response_code($response);
			$response_body = wp_remote_retrieve_body($response);

			// Log prompt and response for debugging
			error_log('=== ILJ AI Debug (Bulk Worker) ===');
			error_log('Prompt: ' . $prompt);
			error_log('Response Body: ' . $response_body);

			if ($response_code !== 200) {
				$error_data = json_decode($response_body, true);
				$error_msg = isset($error_data['error']['message']) ? $error_data['error']['message'] : __('Unknown API error', 'internal-links');
				return new \WP_Error('api_error', sprintf(__('Gemini API Error (Code %d): %s', 'internal-links'), $response_code, $error_msg));
			}

			$data = json_decode($response_body, true);
			$result_text = isset($data['candidates'][0]['content']['parts'][0]['text']) ? trim($data['candidates'][0]['content']['parts'][0]['text']) : '';
		}

		if (empty($result_text)) {
			return new \WP_Error('empty_response', __('AI returned empty response.', 'internal-links'));
		}

		// Extract and sanitize keywords using helper
		$clean_keywords = self::cleanAndExtractKeywords($result_text);
		$keywords_str = implode(',', $clean_keywords);

		if (empty($keywords_str)) {
			return new \WP_Error('no_keywords', __('AI returned no usable keywords. Please try again or adjust the prompt.', 'internal-links'));
		}

		$keyword_list = \ILJ\Type\KeywordList::fromInput($keywords_str);
		
		if ('no_keywords' === $mode) {
			$existing_keywords = \ILJ\Type\KeywordList::fromMeta($post_id, 'post');
			$existing_keywords->merge($keyword_list);
			update_post_meta($post_id, \ILJ\Database\Postmeta::ILJ_META_KEY_LINKDEFINITION, $existing_keywords->getKeywords());
			$final_keywords = $existing_keywords->getKeywords();
		} else {
			update_post_meta($post_id, \ILJ\Database\Postmeta::ILJ_META_KEY_LINKDEFINITION, $keyword_list->getKeywords());
			$final_keywords = $keyword_list->getKeywords();
		}

		// Automatically update Rank Math focus keyword
		$existing_focus = get_post_meta($post_id, 'rank_math_focus_keyword', true);
		$overwrite_focus = \ILJ\Core\Options::getOption(\ILJ\Core\Options\AiOverwriteFocusKeywords::getKey());
		if ('no_keywords' === $mode && !empty($existing_focus) && !$overwrite_focus) {
			$arr1 = array_map('trim', explode(',', strtolower($existing_focus)));
			$arr2 = array_map('trim', explode(',', strtolower($keywords_str)));
			$merged = array_unique(array_filter(array_merge($arr1, $arr2)));
			update_post_meta($post_id, 'rank_math_focus_keyword', implode(', ', $merged));
		} else {
			$arr = array_map('trim', explode(',', strtolower($keywords_str)));
			$formatted_focus = implode(', ', array_unique(array_filter($arr)));
			update_post_meta($post_id, 'rank_math_focus_keyword', $formatted_focus);
		}

		// Mark this post as AI-bulk-processed so it can be skipped in future runs
		update_post_meta($post_id, '_ilj_ai_bulk_processed', current_time('mysql'));

		// Rebuild stats
		\ILJ\Helper\Statistic::count_all_configured_keywords();

		return array('keywords' => implode(',', $final_keywords));
	}

	/**
	 * Process AI keyword generation for a single post in bulk (AJAX entry point)
	 *
	 * @return void
	 */
	public static function aiBulkProcessPost() {
		if (!current_user_can('manage_options')) {
			wp_send_json_error(__('Người dùng trái phép', 'internal-links'), 403);
			wp_die();
		}

		if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'ilj-tools')) {
			wp_send_json_error(__('Xác minh không thành công', 'internal-links'), 403);
			wp_die();
		}

		$post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
		$mode    = isset($_POST['mode']) ? sanitize_text_field(wp_unslash($_POST['mode'])) : 'no_keywords';

		if (!$post_id) {
			wp_send_json_error(__('Invalid post ID.', 'internal-links'), 400);
			wp_die();
		}

		$result = self::processPostAiKeywords($post_id, $mode);
		if (is_wp_error($result)) {
			wp_send_json_error($result->get_error_message());
			wp_die();
		}

		wp_send_json_success($result);
		wp_die();
	}

	/**
	 * Start the background AI Bulk execution
	 *
	 * @return void
	 */
	public static function aiBulkBgStart() {
		if (!current_user_can('manage_options')) {
			wp_send_json_error(__('Người dùng trái phép', 'internal-links'), 403);
			wp_die();
		}
		if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'ilj-tools')) {
			wp_send_json_error(__('Xác minh không thành công', 'internal-links'), 403);
			wp_die();
		}

		$status = get_option('ilj_ai_bulk_bg_status', 'idle');
		$queue  = get_option('ilj_ai_bulk_bg_posts_queue', array());
		if ('paused' === $status && !empty($queue)) {
			$delay = isset($_POST['delay']) ? intval($_POST['delay']) : 7;
			update_option('ilj_ai_bulk_bg_status', 'running');
			update_option('ilj_ai_bulk_bg_delay', $delay);
			self::addBgLog(__('Background bulk generation resumed.', 'internal-links'), 'info');
			wp_clear_scheduled_hook('ilj_ai_bulk_cron_worker');
			wp_schedule_single_event(time(), 'ilj_ai_bulk_cron_worker');
			wp_send_json_success(array(
				'total'   => intval(get_option('ilj_ai_bulk_bg_total_count', 0)),
				'resumed' => true
			));
			wp_die();
		}

		$post_types = isset($_POST['post_types']) ? array_map('sanitize_text_field', (array)$_POST['post_types']) : array();
		$mode       = isset($_POST['mode']) ? sanitize_text_field(wp_unslash($_POST['mode'])) : 'no_keywords';
		$delay      = isset($_POST['delay']) ? intval($_POST['delay']) : 7;

		if (empty($post_types)) {
			wp_send_json_error(__('Please select at least one post type.', 'internal-links'));
			wp_die();
		}

		// Fetch posts to queue
		$args = array(
			'post_type'      => $post_types,
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'no_found_rows'  => true,
		);

		// If no_keywords, filter out posts that already have keywords defined
		if ('no_keywords' === $mode) {
			$args['meta_query'] = array(
				array(
					'key'     => \ILJ\Database\Postmeta::ILJ_META_KEY_LINKDEFINITION,
					'compare' => 'NOT EXISTS',
				)
			);
		} elseif ('skip_processed' === $mode) {
			$args['meta_query'] = array(
				array(
					'key'     => '_ilj_ai_bulk_processed',
					'compare' => 'NOT EXISTS',
				)
			);
		}

		$posts_query = new \WP_Query($args);
		$post_ids = $posts_query->posts;

		if (empty($post_ids)) {
			wp_send_json_error(__('No posts found to process matching the filters.', 'internal-links'));
			wp_die();
		}

		// Initialize Background State
		global $wpdb;
		$wpdb->query("DELETE FROM $wpdb->options WHERE option_name LIKE 'ilj_ai_bulk_bg_retry_%'");

		update_option('ilj_ai_bulk_bg_status', 'running');
		update_option('ilj_ai_bulk_bg_posts_queue', $post_ids);
		update_option('ilj_ai_bulk_bg_total_count', count($post_ids));
		update_option('ilj_ai_bulk_bg_processed_count', 0);
		update_option('ilj_ai_bulk_bg_failed_count', 0);
		update_option('ilj_ai_bulk_bg_mode', $mode);
		update_option('ilj_ai_bulk_bg_delay', $delay);
		update_option('ilj_ai_bulk_bg_post_types', $post_types);
		update_option('ilj_ai_bulk_bg_logs', array());

		self::addBgLog(__('Background bulk generation started.', 'internal-links'), 'info');

		// Clear scheduled event and queue first immediate event
		wp_clear_scheduled_hook('ilj_ai_bulk_cron_worker');
		wp_schedule_single_event(time(), 'ilj_ai_bulk_cron_worker');

		wp_send_json_success(array(
			'total' => count($post_ids),
		));
		wp_die();
	}

	/**
	 * Get status of the background AI Bulk execution
	 *
	 * @return void
	 */
	public static function aiBulkBgStatus() {
		if (!current_user_can('manage_options')) {
			wp_send_json_error(__('Người dùng trái phép', 'internal-links'), 403);
			wp_die();
		}
		if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'ilj-tools')) {
			wp_send_json_error(__('Xác minh không thành công', 'internal-links'), 403);
			wp_die();
		}

		$status     = get_option('ilj_ai_bulk_bg_status', 'idle');
		$total      = intval(get_option('ilj_ai_bulk_bg_total_count', 0));
		$processed  = intval(get_option('ilj_ai_bulk_bg_processed_count', 0));
		$failed     = intval(get_option('ilj_ai_bulk_bg_failed_count', 0));
		$queue      = get_option('ilj_ai_bulk_bg_posts_queue', array());
		$logs       = get_option('ilj_ai_bulk_bg_logs', array());
		$mode       = get_option('ilj_ai_bulk_bg_mode', 'no_keywords');
		$delay      = intval(get_option('ilj_ai_bulk_bg_delay', 7));
		$post_types = get_option('ilj_ai_bulk_bg_post_types', array());

		wp_send_json_success(array(
			'status'     => $status,
			'total'      => $total,
			'processed'  => $processed,
			'failed'     => $failed,
			'remaining'  => count($queue),
			'logs'       => $logs,
			'mode'       => $mode,
			'delay'      => $delay,
			'post_types' => $post_types,
		));
		wp_die();
	}

	/**
	 * Pause/stop the background AI Bulk execution
	 *
	 * @return void
	 */
	public static function aiBulkBgStop() {
		if (!current_user_can('manage_options')) {
			wp_send_json_error(__('Người dùng trái phép', 'internal-links'), 403);
			wp_die();
		}
		if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'ilj-tools')) {
			wp_send_json_error(__('Xác minh không thành công', 'internal-links'), 403);
			wp_die();
		}

		update_option('ilj_ai_bulk_bg_status', 'paused');
		wp_clear_scheduled_hook('ilj_ai_bulk_cron_worker');
		self::addBgLog(__('Background bulk generation paused by user.', 'internal-links'), 'warn');

		wp_send_json_success();
		wp_die();
	}

	/**
	 * Cancel and clear the background AI Bulk execution completely
	 *
	 * @return void
	 */
	public static function aiBulkBgClear() {
		if (!current_user_can('manage_options')) {
			wp_send_json_error(__('Người dùng trái phép', 'internal-links'), 403);
			wp_die();
		}
		if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'ilj-tools')) {
			wp_send_json_error(__('Xác minh không thành công', 'internal-links'), 403);
			wp_die();
		}

		update_option('ilj_ai_bulk_bg_status', 'idle');
		update_option('ilj_ai_bulk_bg_posts_queue', array());
		update_option('ilj_ai_bulk_bg_total_count', 0);
		update_option('ilj_ai_bulk_bg_processed_count', 0);
		update_option('ilj_ai_bulk_bg_failed_count', 0);
		global $wpdb;
		$wpdb->query("DELETE FROM $wpdb->options WHERE option_name LIKE 'ilj_ai_bulk_bg_retry_%'");
		wp_clear_scheduled_hook('ilj_ai_bulk_cron_worker');
		self::addBgLog(__('Background bulk generation canceled and reset by user.', 'internal-links'), 'warn');

		wp_send_json_success();
		wp_die();
	}

	/**
	 * Upload and save Vertex AI credentials JSON via AJAX
	 *
	 * @return void
	 */
	public static function uploadVertexJson() {
		if (!current_user_can('manage_options')) {
			wp_send_json_error(__('Người dùng trái phép', 'internal-links'), 403);
			wp_die();
		}
		if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'ilj-general-nonce')) {
			wp_send_json_error(__('Xác minh không thành công', 'internal-links'), 403);
			wp_die();
		}

		$filename = isset($_POST['filename']) ? sanitize_file_name($_POST['filename']) : 'vertex_credentials.json';
		$content  = isset($_POST['content']) ? wp_unslash($_POST['content']) : '';

		// Verify it is a valid JSON
		$json_data = json_decode($content, true);
		if (empty($json_data)) {
			wp_send_json_error(__('Invalid JSON content.', 'internal-links'));
			wp_die();
		}

		// Save the file to the WordPress uploads directory (safest and always writable)
		$wp_upload_dir = wp_upload_dir();
		$target_dir = $wp_upload_dir['basedir'] . '/ilj-credentials';
		if (!file_exists($target_dir)) {
			wp_mkdir_p($target_dir);
		}

		$target_path = $target_dir . '/' . $filename;
		if (false === file_put_contents($target_path, $content)) {
			wp_send_json_error(__('Failed to write file to disk. Check directory permissions.', 'internal-links'));
			wp_die();
		}

		wp_send_json_success(array(
			'path' => $target_path
		));
		wp_die();
	}

	/**
	 * Background cron worker to process a single post and schedule next
	 *
	 * @return void
	 */
	public static function aiBulkCronWorker() {
		$status = get_option('ilj_ai_bulk_bg_status', 'idle');
		if ('running' !== $status) {
			return;
		}

		$queue = get_option('ilj_ai_bulk_bg_posts_queue', array());
		if (empty($queue)) {
			update_option('ilj_ai_bulk_bg_status', 'completed');
			self::addBgLog(__('All posts processed in the background!', 'internal-links'), 'info');
			global $wpdb;
			$wpdb->query("DELETE FROM $wpdb->options WHERE option_name LIKE 'ilj_ai_bulk_bg_retry_%'");
			return;
		}

		// Shift the first post ID from queue
		$post_id = array_shift($queue);
		update_option('ilj_ai_bulk_bg_posts_queue', $queue);

		$mode  = get_option('ilj_ai_bulk_bg_mode', 'no_keywords');
		$delay = intval(get_option('ilj_ai_bulk_bg_delay', 7));

		$post = get_post($post_id);
		if (!$post) {
			// Skip and run next post
			wp_schedule_single_event(time() + $delay, 'ilj_ai_bulk_cron_worker');
			return;
		}

		self::addBgLog(sprintf(__('Processing "%s" in background...', 'internal-links'), $post->post_title), 'info');

		$result = self::processPostAiKeywords($post_id, $mode);

		$next_delay = $delay;

		if (is_wp_error($result)) {
			$error_msg = $result->get_error_message();
			$lower_error_msg = strtolower($error_msg);

			// Check for rate limit or quota exhaust
			$is_rate_limit = (strpos($error_msg, '429') !== false || strpos($error_msg, 'RESOURCE_EXHAUSTED') !== false || strpos($lower_error_msg, 'rate limit') !== false || strpos($lower_error_msg, 'quota') !== false);
			
			// Check for other transient network/timeout issues
			$is_network_timeout = (
				strpos($lower_error_msg, 'timed out') !== false || 
				strpos($lower_error_msg, 'timeout') !== false || 
				strpos($lower_error_msg, 'curl error 28') !== false || 
				strpos($lower_error_msg, 'curl error 6') !== false || 
				strpos($lower_error_msg, 'curl error 7') !== false || 
				strpos($lower_error_msg, '502') !== false || 
				strpos($lower_error_msg, '503') !== false || 
				strpos($lower_error_msg, '504') !== false
			);

			if ($is_rate_limit) {
				$consecutive = intval(get_option('ilj_ai_bulk_bg_consecutive_429', 0)) + 1;
				update_option('ilj_ai_bulk_bg_consecutive_429', $consecutive);

				if ($consecutive >= 5) {
					// Likely hit RPD (Requests Per Day) limit. Auto-pause the process.
					update_option('ilj_ai_bulk_bg_status', 'paused');
					update_option('ilj_ai_bulk_bg_consecutive_429', 0);
					self::addBgLog(__('Daily quota (RPD) or severe rate limit exhausted. Background process paused automatically to prevent loop.', 'internal-links'), 'error');
					// Put back to front of queue
					array_unshift($queue, $post_id);
					update_option('ilj_ai_bulk_bg_posts_queue', $queue);
					return;
				} else {
					self::addBgLog(sprintf(__('Rate limit hit for "%s". Retrying in 25 seconds... (Attempt %d/5)', 'internal-links'), $post->post_title, $consecutive), 'warn');
					// Put back to front of queue
					array_unshift($queue, $post_id);
					update_option('ilj_ai_bulk_bg_posts_queue', $queue);
					$next_delay = 25;
				}
			} elseif ($is_network_timeout) {
				$retry_option_key = 'ilj_ai_bulk_bg_retry_' . $post_id;
				$retries = intval(get_option($retry_option_key, 0)) + 1;
				
				if ($retries <= 3) {
					update_option($retry_option_key, $retries);
					self::addBgLog(sprintf(__('Temporary connection/timeout error for "%s" (%s). Retrying in 20 seconds... (Attempt %d/3)', 'internal-links'), $post->post_title, $error_msg, $retries), 'warn');
					// Put back to front of queue
					array_unshift($queue, $post_id);
					update_option('ilj_ai_bulk_bg_posts_queue', $queue);
					$next_delay = 20;
				} else {
					delete_option($retry_option_key);
					update_option('ilj_ai_bulk_bg_consecutive_429', 0);
					self::addBgLog(sprintf(__('Failed for "%s" after 3 retry attempts: %s', 'internal-links'), $post->post_title, $error_msg), 'error');
					$failed = intval(get_option('ilj_ai_bulk_bg_failed_count', 0)) + 1;
					update_option('ilj_ai_bulk_bg_failed_count', $failed);
				}
			} else {
				update_option('ilj_ai_bulk_bg_consecutive_429', 0);
				self::addBgLog(sprintf(__('Failed for "%s": %s', 'internal-links'), $post->post_title, $error_msg), 'error');
				$failed = intval(get_option('ilj_ai_bulk_bg_failed_count', 0)) + 1;
				update_option('ilj_ai_bulk_bg_failed_count', $failed);
			}
		} else {
			update_option('ilj_ai_bulk_bg_consecutive_429', 0);
			// Clean up retry option on success
			delete_option('ilj_ai_bulk_bg_retry_' . $post_id);
			if (!empty($result['skipped'])) {
				self::addBgLog(sprintf(__('Skipped "%s" (already has keywords).', 'internal-links'), $post->post_title), 'warn');
			} else {
				self::addBgLog(sprintf(__('Generated for "%s": %s', 'internal-links'), $post->post_title, $result['keywords']), 'success');
				$processed = intval(get_option('ilj_ai_bulk_bg_processed_count', 0)) + 1;
				update_option('ilj_ai_bulk_bg_processed_count', $processed);
			}
		}

		// Schedule next post
		wp_schedule_single_event(time() + $next_delay, 'ilj_ai_bulk_cron_worker');
	}

	/**
	 * Append a log entry to the background AI Bulk execution log
	 *
	 * @param string $message
	 * @param string $type
	 * @return void
	 */
	private static function addBgLog($message, $type = 'info') {
		$logs = get_option('ilj_ai_bulk_bg_logs', array());
		if (!is_array($logs)) {
			$logs = array();
		}
		$logs[] = array(
			'time'    => current_time('H:i:s'),
			'message' => $message,
			'type'    => $type
		);
		if (count($logs) > 100) {
			$logs = array_slice($logs, -100);
		}
		update_option('ilj_ai_bulk_bg_logs', $logs);
	}

	/**
	 * Return list of posts processed by AI Bulk for the report page
	 *
	 * @return void
	 */
	public static function aiBulkReport() {
		if (!current_user_can('manage_options')) {
			wp_send_json_error('Unauthorized', 403);
			wp_die();
		}
		if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'ilj-tools')) {
			wp_send_json_error('Nonce verification failed', 403);
			wp_die();
		}

		$query = new \WP_Query(array(
			'post_type'      => 'any',
			'post_status'    => 'publish',
			'meta_key'       => '_ilj_ai_bulk_processed',
			'posts_per_page' => -1,
			'no_found_rows'  => true,
			'orderby'        => 'meta_value',
			'order'          => 'DESC',
		));

		$posts = array();
		foreach ($query->posts as $post) {
			$processed_at = get_post_meta($post->ID, '_ilj_ai_bulk_processed', true);
			$raw_keywords = get_post_meta($post->ID, \ILJ\Database\Postmeta::ILJ_META_KEY_LINKDEFINITION, true);
			$keywords_str = '';
			if (is_array($raw_keywords)) {
				$keywords_str = implode(', ', $raw_keywords);
			}
			$posts[] = array(
				'ID'           => $post->ID,
				'post_title'   => $post->post_title,
				'post_type'    => get_post_type_object($post->post_type) ? get_post_type_object($post->post_type)->labels->singular_name : $post->post_type,
				'processed_at' => $processed_at,
				'keywords'     => $keywords_str,
				'edit_url'     => get_edit_post_link($post->ID, 'raw'),
			);
		}

		wp_send_json_success(array('posts' => $posts));
		wp_die();
	}

	/**
	 * Remove the AI-bulk-processed flag from a single post
	 *
	 * @return void
	 */
	public static function aiBulkResetPost() {
		if (!current_user_can('manage_options')) {
			wp_send_json_error('Unauthorized', 403);
			wp_die();
		}
		if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'ilj-tools')) {
			wp_send_json_error('Nonce verification failed', 403);
			wp_die();
		}
		$post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
		if (!$post_id) {
			wp_send_json_error('Invalid post ID', 400);
			wp_die();
		}
		delete_post_meta($post_id, '_ilj_ai_bulk_processed');
		wp_send_json_success();
		wp_die();
	}

	/**
	 * Remove the AI-bulk-processed flag from ALL posts
	 *
	 * @return void
	 */
	public static function aiBulkResetAll() {
		if (!current_user_can('manage_options')) {
			wp_send_json_error('Unauthorized', 403);
			wp_die();
		}
		if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'ilj-tools')) {
			wp_send_json_error('Nonce verification failed', 403);
			wp_die();
		}

		delete_post_meta_by_key('_ilj_ai_bulk_processed');
		wp_send_json_success();
		wp_die();
	}

	/**
	 * Smart keyword extraction and sanitization from AI response
	 *
	 * @param string $result_text Raw response text from AI
	 * @return array List of cleaned keywords
	 */
	private static function cleanAndExtractKeywords($result_text) {
		$keywords = array();

		// 1. Try to find a JSON array pattern [ ... ] inside the response text
		if (preg_match('/\[\s*.*?\s*\]/s', $result_text, $matches)) {
			$potential_json = trim($matches[0]);
			// Strip code fences if they got caught inside the match
			$potential_json = preg_replace('/```[a-z]*\s*/i', '', $potential_json);
			$potential_json = preg_replace('/```/', '', $potential_json);
			$potential_json = trim($potential_json);

			$json_parsed = json_decode($potential_json, true);
			if (is_array($json_parsed)) {
				foreach ($json_parsed as $item) {
					if (is_string($item) && !empty(trim($item))) {
						$keywords[] = trim($item);
					}
				}
			}
		}

		// 2. Fallback: split by comma if no JSON array found or JSON parsed was empty
		if (empty($keywords)) {
			$raw_keywords = array_map('trim', explode(',', $result_text));
			foreach ($raw_keywords as $kw) {
				// Strip parenthetical notes: "keyword (explanation)"
				$kw = preg_replace('/\s*\(.*?\)\s*/', '', $kw);
				// Strip text after colon (e.g. "label: keyword")
				if (strpos($kw, ':') !== false) {
					$parts = explode(':', $kw);
					$kw = trim(end($parts));
				}
				// Strip leading numbers/bullets: "1. keyword", "- keyword"
				$kw = preg_replace('/^[\d\.\-\*\•]+\s*/', '', $kw);
				$keywords[] = $kw;
			}
		}

		// 3. Clean and filter the extracted keywords
		$clean_keywords = array();
		$blocklist = array(
			'explanation', 'markdown', 'code block', 'codeblock', 'commentary', 'instruction', 'rule', 'constraint',
			'task', 'extract', 'seo', 'keyword', 'phrase', 'format', 'output', 'post title', 'post content',
			'post', 'title', 'content', 'duplicate', 'language', 'maximum', 'generate', 'text', 'input',
			'example', 'valid', 'json', 'array', 'string', 'punctuation', 'focus', 'appear in', 'other articles',
			'same site', 'same language', 'linking', 'words per'
		);

		foreach ($keywords as $kw) {
			// Lowercase for checking/cleaning
			$kw_lower = strtolower($kw);

			// Check blocklist
			$blocked = false;
			foreach ($blocklist as $blocked_word) {
				if (strpos($kw_lower, $blocked_word) !== false) {
					$blocked = true;
					break;
				}
			}
			if ($blocked) {
				continue;
			}

			// Aggressive cleanup: strip leading/trailing quotes, brackets, braces, pipes, stars, hyphens, colons, slashes, dots, commas
			$kw = trim($kw, "[]{}'\"`|*-•:.,;()\\/ ");
			$kw_lower = strtolower($kw);

			// Check word count (must be between 1 and 5 words)
			$word_count = empty($kw_lower) ? 0 : count(preg_split('/\s+/u', trim($kw_lower)));
			if (empty($kw) || $word_count < 1 || $word_count > 5 || strpos($kw_lower, '.') !== false) {
				continue;
			}

			$clean_keywords[] = $kw_lower;
		}

		return array_unique(array_filter($clean_keywords));
	}
}
