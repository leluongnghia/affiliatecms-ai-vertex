<?php

namespace ILJ\Database;

use ILJ\Backend\Editor;
use ILJ\Helper\Encoding;
use ILJ\Helper\Statistic;

/**
 * Database wrapper for the keyword meta
 *
 * @package ILJ\Database
 * @since   2.1.2
 */
class Keywords {

	const ILJ_KEYWORD_META_KEY = "ilj_linkdefinition";

	/**
	 * Handles all functions to reset keywords and ILJ meta data
	 *
	 * @return void
	 */
	public static function reset_all_keywords() {

		self::reset_meta_value("postmeta");

		if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			self::reset_meta_value("termmeta");
		}
	}

	/**
	 * Handles resetting of other ILJ meta data
	 *
	 * @param  mixed $meta_table
	 * @return void
	 */
	public static function reset_meta_value($meta_table) {

		$ilj_meta_keys = array(
			self::ILJ_KEYWORD_META_KEY,
			Editor::ILJ_META_KEY_LIMITINCOMINGLINKS,
			Editor::ILJ_META_KEY_MAXINCOMINGLINKS,
			Editor::ILJ_META_KEY_BLACKLISTDEFINITION,
			Editor::ILJ_META_KEY_LIMITLINKSPERPARAGRAPH,
			Editor::ILJ_META_KEY_LINKSPERPARAGRAPH,
			Editor::ILJ_META_KEY_LIMITOUTGOINGLINKS,
			Editor::ILJ_META_KEY_MAXOUTGOINGLINKS,
		);

		global $wpdb;
		$table = $wpdb->prefix . $meta_table;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- We need to use a direct query here for performance reasons because we can't use a $wpdb->delete() because there is an IN condition in the query's WHERE clause.
		$wpdb->query("DELETE FROM $table WHERE meta_key IN ('". implode("','", $ilj_meta_keys)."')");

		Statistic::count_all_configured_keywords();
	}

	/**
	 * This function checks if the keyword added has a duplicate
	 *
	 * @param  String $keyword  Keyword value that is used to find for duplicates in other posts
	 * @param  int 	  $id	    Post/Term ID to exclude from checking
	 * @param  String $type     Can be post/term/custom to exclude from checking
	 * @param  String $sub_type The subtype of the item
	 * @return string
	 */
	public static function check_if_keyword_has_duplicate__premium_only($keyword, $id = null, $type = null, $sub_type = null) {
		global $wpdb;
		$message = "";
		// Translators: %1$s is the keyword and %2$d is the number of duplicates.
		$duplicate_message_singular = __('Từ khóa %1$s có %2$d trùng lặp.', 'internal-links');
		// Translators: %1$s is the keyword and %2$d is the number of duplicates.
		$duplicate_message_plural = __('Từ khóa %1$s có %2$d trùng lặp.', 'internal-links');
		$count = 0;

		$meta_key = self::ILJ_KEYWORD_META_KEY;
		
		$raw_keyword = sanitize_text_field($keyword);

		$translated_keyword = Encoding::translate_pseudo_to_regex_escaped__premium_only($raw_keyword);
		if (Encoding::is_gap_style_regex($translated_keyword)) {
			// for gaps
			$translated = Encoding::escape_mysql_regex_specials($translated_keyword);
		} else {
			// non gaps
			$translated = Encoding::format_keyword_to_pipe_structure($translated_keyword);
		}
		$translated = Encoding::escape_selected_regex_chars($translated);
		$query_post_meta = $wpdb->prepare(
			'SELECT COUNT(*) FROM '.$wpdb->postmeta.' WHERE meta_key = %s AND meta_value REGEXP %s AND NOT (post_id = %d AND %s = "post")',
			$meta_key,
			'"' . $translated . '"',
			intval($id),
			$type
		);

		$results_post = intval($wpdb->get_var($query_post_meta)); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- Already prepared, and We need to use direct query here.
		$count += $results_post;

		$query_term_meta = $wpdb->prepare(
			'SELECT COUNT(*) FROM '.$wpdb->termmeta.' WHERE meta_key = %s AND meta_value REGEXP %s AND NOT (term_id = %d AND %s = "term")',
			$meta_key,
			'"' . $translated . '"',
			intval($id),
			$type
		);

		$results_term = $wpdb->get_var($query_term_meta); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- Already prepared, and We need to use direct query here.
		$count += $results_term;

		if ($count > 0) {
			if ($count > 1) {
				$message = sprintf(esc_html($duplicate_message_plural), '<strong>' . esc_html($keyword) . '</strong>', $count);
			} else {
				$message = sprintf(esc_html($duplicate_message_singular), '<strong>' . esc_html($keyword) . '</strong>', $count);
			}

			$see_more_link = '<br><a title="' . esc_attr__('Hiển thị chi tiết trùng lặp', 'internal-links') . '" ' .
			'data-keyword="' . esc_attr($keyword) . '" ' .
			'data-duplicate-count="' . esc_attr($count) . '" ' .
			'data-ilj-item-id="' . esc_attr($id) . '" '.
			'data-ilj-item-type="' . esc_attr($type) . '" '.
			'data-ilj-item-sub-type="' . esc_attr($sub_type) . '" '.
			'class="tip ilj-duplicate-details">' . esc_html__('Xem thêm', 'internal-links') . '</a>';

			$dismiss_notice = '<span class="ilj-dismiss-notice" title="' . esc_attr__('Miễn nhiệm', 'internal-links') . '">&times;</span>';

			$message .= $dismiss_notice . $see_more_link;
			
		} else {
			return "";
		}

		return $message;
	}

	/**
	 * Fetch the keyword duplicates from posts/custom/terms for more details
	 *
	 * @param  String $keyword   Keyword value that is used to find for duplicates in other posts
	 * @param  int    $id        Post/Term ID to exclude from checking
	 * @param  String $main_type The main type of the item (post/term)
	 * @return array
	 */
	public static function get_keyword_duplicates__premium_only($keyword, $id, $main_type) {
		global $wpdb;
		$meta_key = self::ILJ_KEYWORD_META_KEY;
		$results = array();

		$raw_keyword = sanitize_text_field($keyword);
		$translated_keyword = Encoding::translate_pseudo_to_regex_escaped__premium_only($raw_keyword);
		if (Encoding::is_gap_style_regex($translated_keyword)) {
			// for gaps
			$translated = Encoding::escape_mysql_regex_specials($translated_keyword);
		} else {
			// non gaps
			$translated = Encoding::format_keyword_to_pipe_structure($translated_keyword);
		}

		$translated = Encoding::escape_selected_regex_chars($translated);

		$query_post_meta = $wpdb->prepare(
			"SELECT p.ID as id, p.post_title as title, p.post_type as data_type, 'post' as main_type FROM {$wpdb->postmeta} pm INNER JOIN {$wpdb->posts} p ON pm.post_id = p.ID  WHERE pm.meta_key = %s AND pm.meta_value REGEXP %s AND NOT ('post' = %s AND pm.post_id = %d)",
			$meta_key,
			'"' . $translated . '"',
			$main_type,
			intval($id)
		);

		$results_post = $wpdb->get_results($query_post_meta); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- Already prepared, and We need to use direct query here.
		$results = $results_post;

		$query_term_meta = $wpdb->prepare(
			"SELECT tt.term_id as id, tt.name as title, tt2.taxonomy as data_type, 'term' as main_type FROM {$wpdb->termmeta} tm INNER JOIN {$wpdb->terms} tt ON tm.term_id = tt.term_id INNER JOIN {$wpdb->term_taxonomy} tt2 ON tt.term_id = tt2.term_id WHERE tm.meta_key = %s AND tm.meta_value REGEXP %s AND NOT ('term' = %s AND tt.term_id = %d)",
			$meta_key,
			'"' . $translated . '"',
			$main_type,
			intval($id)
		);
		$results_term = $wpdb->get_results($query_term_meta); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- Already prepared, and We need to use direct query here.
		$results = array_merge($results_post, $results_term);

		return $results;

	}
}
