<?php

namespace ILJ\Database;

use ILJ\Core\Options;
use ILJ\Helper\BatchBuilding;
use ILJ\Helper\Blacklist;

/**
 * Termmeta wrapper for the inlink postmeta
 *
 * @package ILJ\Database
 * @since   1.0.1
 */
class Termmeta {

	const ILJ_META_KEY_LINKDEFINITION = 'ilj_linkdefinition';

	/**
	 * Returns all Linkdefinitions from termmeta table
	 *
	 * @since  1.0.1
	 * @param  string $field Fetch single field value
	 * @return array
	 */
	public static function getAllLinkDefinitions($field = null) {
		global $wpdb;
		$meta_key = self::ILJ_META_KEY_LINKDEFINITION;
		$taxonomy = Options::getOption(\ILJ\Core\Options\TaxonomyWhitelist::getKey());
		if (is_array($taxonomy)) {
			$taxonomy_list = "'" . implode("','", $taxonomy) . "'";

			$fetch_field = '*';

			if (null != $field) {
				$fetch_field = $field;
			}

			$query = "
				SELECT termmeta.".$fetch_field."
				FROM $wpdb->termmeta termmeta
				LEFT JOIN ($wpdb->terms t
				INNER JOIN $wpdb->term_taxonomy AS tt  ON t.term_id = tt.term_id)
				ON t.term_id = termmeta.term_id
				WHERE termmeta.meta_key = '$meta_key'
				AND tt.taxonomy IN ($taxonomy_list) 
			";
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- Direct query necessary and caching is not applicable for dynamic data.
			return $wpdb->get_results($query);
		}
		return array();
	}

	/**
	 * Returns all Linkdefinitions by ID
	 *
	 * @param  int $id
	 * @return array
	 */
	public static function getLinkDefinitionsById($id) {
		global $wpdb;
		$meta_key = self::ILJ_META_KEY_LINKDEFINITION;
		$taxonomy = Options::getOption(\ILJ\Core\Options\TaxonomyWhitelist::getKey());
		if (is_array($taxonomy)) {
			$taxonomy_list = "'" . implode("','", $taxonomy) . "'";

			$query = "
				SELECT termmeta.*
				FROM $wpdb->termmeta termmeta
				LEFT JOIN ($wpdb->terms t
				INNER JOIN $wpdb->term_taxonomy AS tt  ON t.term_id = tt.term_id)
				ON t.term_id = termmeta.term_id
				WHERE termmeta.meta_key = '$meta_key'
				AND tt.taxonomy IN ($taxonomy_list) AND t.term_id = $id
			";

			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Direct query necessary and caching is not applicable for dynamic data.
			return $wpdb->get_results($query);
		}
		return array();
	}

	/**
	 * Removes all link definitions from termmeta table
	 *
	 * @since  1.1.3
	 * @return int
	 */
	public static function removeAllLinkDefinitions() {
		global $wpdb;
		$meta_key = self::ILJ_META_KEY_LINKDEFINITION;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Direct database deletion is necessary, and caching is not applicable.
		return $wpdb->delete($wpdb->termmeta, array('meta_key' => $meta_key));
	}

	/**
	 * GET Term Keyword definitions
	 *
	 * @return mixed
	 */
	public static function getLinkDefinitionCount__premium_only() {
		 global $wpdb;
		$meta_key = self::ILJ_META_KEY_LINKDEFINITION;
		$taxonomy = Options::getOption(\ILJ\Core\Options\TaxonomyWhitelist::getKey());
		if (is_array($taxonomy)) {
			$taxonomy_list = "'" . implode("','", $taxonomy) . "'";

			$query = "
				SELECT COUNT(termmeta.meta_id)
				FROM $wpdb->termmeta termmeta
				LEFT JOIN ($wpdb->terms t
				INNER JOIN $wpdb->term_taxonomy AS tt  ON t.term_id = tt.term_id)
				ON t.term_id = termmeta.term_id
				WHERE termmeta.meta_key = '$meta_key'
				AND tt.taxonomy IN ($taxonomy_list) 
			";
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Direct query necessary and caching is not applicable for dynamic data.
			return $wpdb->get_var($query);
		}
		return 0;
	}

	/**
	 * Get Term Keyword Definitions by batch
	 *
	 * @param  mixed $offset
	 * @return mixed
	 */
	public static function getAllLinkDefinitionsByBatch($offset) {
		global $wpdb;
		$meta_key       = self::ILJ_META_KEY_LINKDEFINITION;
		$taxonomy       = Options::getOption(\ILJ\Core\Options\TaxonomyWhitelist::getKey());
		$batch_building = new BatchBuilding();
		$limit          = $batch_building->get_fetch_batch_keyword_size();

		if (is_array($taxonomy)) {
			$taxonomy_list = "'" . implode("','", $taxonomy) . "'";

			$query = "
				SELECT termmeta.*
				FROM $wpdb->termmeta termmeta
				LEFT JOIN ($wpdb->terms t
				INNER JOIN $wpdb->term_taxonomy AS tt  ON t.term_id = tt.term_id)
				ON t.term_id = termmeta.term_id
				WHERE termmeta.meta_key = '$meta_key'
				AND tt.taxonomy IN ($taxonomy_list) LIMIT $offset , $limit 
			";
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Direct query necessary and caching is not applicable for dynamic data.
			return $wpdb->get_results($query);
		}
		return array();
	}
}
