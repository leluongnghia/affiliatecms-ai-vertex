<?php
namespace ILJ\Backend\MenuPage\Keywords_Editor;

use ILJ\Core\Options;

/**
 * The Table Context
 *
 * This class provides the context to the table {@link Table} from the page request parameters..
 *
 * @package ILJ\Backend\Menupage\Keywords_Editor
 *
 * @since 2.23.5
 */
class Context {

	/**
	 * An array of args.
	 *
	 * @var array
	 */
	private $args;

	/**
	 * Constructor for {@link Context}
	 *
	 * @param array $args An associative array of option params.
	 */
	public function __construct($args) {
		$whitelisted_post_types = Options::getOption(Options\Whitelist::getKey());
		$whitelisted_taxonomies = Options::getOption(Options\TaxonomyWhitelist::getKey());
		$defaults = array(
			'items_per_page' => 20,
			'page_number' => 0,
			'current_view' => 'post',
			'search_query' => '',
			'page_slug' => '',
			'sorting_enabled' => false,
			'sort_order' => 'ASC',
			// We should ignore auto draft post status.
			'post_status' => array_diff(get_post_stati(), array('auto-draft')),
			'post_type' => is_array($whitelisted_post_types) ? $whitelisted_post_types : array(),
			'taxonomy' => is_array($whitelisted_taxonomies) ? $whitelisted_taxonomies : array(),
		);

		$this->args = wp_parse_args($args, $defaults);
	}



	/**
	 * Create context from request params.
	 *
	 * @return Context
	 */
	public static function from_request_params() {

		$args = array();

		if (self::is_keyword_editor_form_submit() && (!isset($_REQUEST['_wpnonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_REQUEST['_wpnonce'])), 'bulk-'.get_current_screen()->id))) {
			wp_die(esc_html__("Xin lỗi, Bạn không được phép thực hiện hành động này.", 'internal-links'));
		}

		/*
		 * We dont want to perform pagination when search query is enabled.
		 */
		if (isset($_REQUEST['paged']) && is_numeric($_REQUEST['paged'])) {
			$args['page_number'] = intval($_REQUEST['paged']);
		}

		if (isset($_REQUEST['current_view']) && is_string($_REQUEST['current_view'])) {
			$args['current_view'] = sanitize_text_field(wp_unslash($_REQUEST['current_view']));
		}

		if (isset($_REQUEST['s']) && is_string($_REQUEST['s'])) {
			$args['search_query'] = sanitize_text_field(wp_unslash($_REQUEST['s']));
		}

		if (isset($_REQUEST['page']) && is_string($_REQUEST['page'])) {
			$args['page_slug'] = sanitize_text_field(wp_unslash($_REQUEST['page']));
		}

		if (isset($_REQUEST['order']) && in_array($_REQUEST['order'], array('asc', 'desc'), true)) {
			$args['sort_order'] = strtoupper(sanitize_text_field(wp_unslash($_REQUEST['order'])));
			$args['sorting_enabled'] = true;
		}

		if (isset($_REQUEST['post_status_filter']) && !empty($_REQUEST['post_status_filter']) && is_string($_REQUEST['post_status_filter'])) {
			$args['post_status'] = array(sanitize_text_field(wp_unslash($_REQUEST['post_status_filter'])));
		}

		if (isset($_REQUEST['post_type_filter']) && !empty($_REQUEST['post_type_filter']) && is_string($_REQUEST['post_type_filter'])) {
			$args['post_type'] = array(sanitize_text_field(wp_unslash($_REQUEST['post_type_filter'])));
		}

		if (isset($_REQUEST['taxonomy_filter']) && !empty($_REQUEST['taxonomy_filter']) && is_string($_REQUEST['taxonomy_filter'])) {
			$args['taxonomy'] = array(sanitize_text_field(wp_unslash($_REQUEST['taxonomy_filter'])));
		}

		return new Context($args);
	}

	/**
	 * Check Whether the keyword editor filter or search or page filter.
	 *
	 * @return bool True if the keyword editor form submitted, otherwise false.
	 */
	private static function is_keyword_editor_form_submit() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Nonce verification is handled in the caller method. Here we just check the filter type.
		return ((!empty($_REQUEST['filter']) && 'Filter' == $_REQUEST['filter']) || !empty($_REQUEST['s']));
	}

	public function get_post_status() {
		return $this->args['post_status'];
	}

	/**
	 * Return the list of filtered post types.
	 *
	 * @return array
	 */
	public function get_post_type() {
		return $this->args['post_type'];
	}

	/**
	 * Return the list of filtered taxonomy.
	 *
	 * @return array
	 */
	public function get_taxonomy() {
		return $this->args['taxonomy'];
	}

	/**
	 * Return the sql escaped post status string which can be used inside IN() clause.
	 *
	 * @return string
	 */
	public function get_sql_escaped_post_status() {
		return sprintf("'%s'", implode("','", array_map('esc_sql', $this->get_post_status())));
	}

	/**
	 * Return the sql escaped post type string which can be used inside IN() clause.
	 *
	 * @return string
	 */
	public function get_sql_escaped_post_type() {
		return sprintf("'%s'", implode("','", array_map('esc_sql', $this->get_post_type())));
	}


	/**
	 * Return the offset number.
	 *
	 * @return int
	 */
	public function get_page_number() {
		return $this->args['page_number'];
	}

	/**
	 * Return the current page, it can be any one of the values 'post', 'term', 'custom-links'.
	 *
	 * @return string
	 */
	public function get_current_view() {
		return $this->args['current_view'];
	}

	/**
	 * Getter for the search query.
	 *
	 * @return string
	 */
	public function get_search_query() {
		return $this->args['search_query'];
	}

	/**
	 * Getter for the page slug.
	 *
	 * @return string
	 */
	public function get_page_slug() {
		return $this->args['page_slug'];
	}

	/**
	 * Getter for the order by.
	 *
	 * @return string
	 */
	public function get_sort_order() {
		return $this->args['sort_order'];
	}

	/**
	 * Return items per page.
	 *
	 * @return int
	 */
	public function get_items_per_page() {
		return $this->args['items_per_page'];
	}

	public function get_sorting_enabled() {
		return $this->args['sorting_enabled'];
	}
}
