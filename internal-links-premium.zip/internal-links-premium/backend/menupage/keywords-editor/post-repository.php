<?php

namespace ILJ\Backend\MenuPage\Keywords_Editor;

use ILJ\Data\Content;
use ILJ\Posttypes\CustomLinks;

/**
 * The Post Repository class
 *
 * This Post Repository class is used for searching, getting count of all posts in `publish` status except few CPTS.
 *
 * @package ILJ\Backend\Menupage\Keywords_Editor
 *
 * @since 2.23.5
 */
final class Post_Repository extends Repository {
	/**
	 * Return the total number of items by applying search query.
	 *
	 * @return int
	 */
	public function get_count_for_search_query() {
		global $wpdb;
		if (empty($this->context->get_post_type())) {
			return 0;
		}
		$search_query = $this->context->get_search_query();
		if (!$search_query) {
			return $this->get_count();
		}
		$escaped_search_query = '%' . $wpdb->esc_like($search_query) .'%';
		return intval(
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- We need to use a direct query here.
			$wpdb->get_var(
				$wpdb->prepare(
					// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Require to get desired result.
					"SELECT COUNT(1) FROM {$wpdb->posts} WHERE post_status IN ({$this->context->get_sql_escaped_post_status()}) AND post_type IN ({$this->context->get_sql_escaped_post_type()}) AND (post_title LIKE %s OR post_content LIKE %s OR post_excerpt LIKE %s)",
					$escaped_search_query,
					$escaped_search_query,
					$escaped_search_query
				)
			)
		);
	}

	/**
	 * Return the total number of items.
	 *
	 * @return int
	 */
	public function get_count() {
		global $wpdb;
		if (empty($this->context->get_post_type())) {
			return 0;
		}
		return intval(
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- We need to use a direct query here.
			$wpdb->get_var("SELECT COUNT(1) FROM {$wpdb->posts} WHERE post_status IN ({$this->context->get_sql_escaped_post_status()}) AND post_type IN ({$this->context->get_sql_escaped_post_type()})")
		);
	}

	/**
	 * Get the items filtered by context.
	 *
	 * @return array<Content>
	 */
	public function get_items() {
		if (empty($this->context->get_post_type())) {
			return array();
		}
		$args = array(
			'numberposts' => $this->context->get_items_per_page(),
			'paged' => $this->context->get_page_number(),
			's' => $this->context->get_search_query(),
			'fields' => 'ids',
			'post_type' => $this->context->get_post_type(),
			'post_status' => $this->context->get_post_status()
		);

		if ($this->context->get_sorting_enabled()) {
			$args = array_merge($args, array('orderby' => 'title', 'order' => $this->context->get_sort_order()));
		}

		$posts = get_posts($args);

		return array_map(array(Content::class, 'from_post_id'), $posts);
	}
}
