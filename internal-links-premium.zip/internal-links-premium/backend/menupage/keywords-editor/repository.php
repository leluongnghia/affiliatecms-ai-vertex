<?php

namespace ILJ\Backend\MenuPage\Keywords_Editor;

use ILJ\Data\Content;

/**
 * The Repository Interface
 *
 * This interface sets a common set of functions which will be used for rendering the {@link \WP_List_Table}
 *
 * @package ILJ\Backend\Menupage\Keywords_Editor
 *
 * @since 2.23.5
 */
abstract class Repository {

	/**
	 * The context which consists of validated filters and other params.
	 *
	 * @var Context
	 */
	protected $context;

	/**
	 * Constructor for {@link Repository}
	 *
	 * @param Context $context The context which consists of validated filters and other params.
	 */
	public function __construct($context) {
		$this->context = $context;
	}

	/**
	 * Return the total number of items.
	 *
	 * @return int
	 */
	abstract public function get_count();

	/**
	 * Return the total number of items by applying search query.
	 *
	 * @return int
	 */
	abstract public function get_count_for_search_query();

	/**
	 * Get the items filtered by context.
	 *
	 * @return array<Content>
	 */
	abstract public function get_items();
}
