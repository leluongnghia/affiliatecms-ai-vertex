<?php

namespace ILJ\Backend\MenuPage\Keywords_Editor;

use ILJ\Data\Content;
use ILJ\Posttypes\CustomLinks;

final class Link_Repository extends Repository {
	/**
	 * Return the total number of items by applying search query.
	 *
	 * @return int
	 */
	public function get_count_for_search_query() {
		global $wpdb;
		$search_query = $this->context->get_search_query();
		if (!$search_query) {
			return $this->get_count();
		}
		return intval(
			$wpdb->get_var( // phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- We need to use a direct query here.
				$wpdb->prepare("SELECT COUNT(1) FROM {$wpdb->posts} WHERE post_type = %s AND (post_title LIKE %s OR post_content LIKE %s OR post_excerpt LIKE %s)",
					CustomLinks::ILJ_POSTTYPE_CUSTOM_LINKS_SLUG,
					'%' . $wpdb->esc_like($search_query) . '%',
					'%' . $wpdb->esc_like($search_query) . '%',
					'%' . $wpdb->esc_like($search_query) . '%'
				)
			)
		);
	}

	/**
	 * Return the total number of items.
	 *
	 * @return int
	 */
	public function get_count() {
		global $wpdb;
		return intval($wpdb->get_var($wpdb->prepare("SELECT COUNT(1) FROM {$wpdb->posts} WHERE post_type = %s ", CustomLinks::ILJ_POSTTYPE_CUSTOM_LINKS_SLUG)));
	}

	/**
	 * Get the items filtered by context.
	 *
	 * @return array<Content>
	 */
	public function get_items() {
		$args = array(
			'numberposts' => $this->context->get_items_per_page(),
			'paged' => $this->context->get_page_number(),
			's' => $this->context->get_search_query(),
			'fields' => 'ids',
			'post_type' => CustomLinks::ILJ_POSTTYPE_CUSTOM_LINKS_SLUG,
			'post_status' => $this->context->get_post_status()
		);
		if ($this->context->get_sorting_enabled()) {
			$args = array_merge($args, array('orderby' => 'title', 'order' => $this->context->get_sort_order()));
		}
		$link_cpt_posts = get_posts($args);
		return array_map(array(Content::class, 'from_post_id'), $link_cpt_posts);
	}
}
