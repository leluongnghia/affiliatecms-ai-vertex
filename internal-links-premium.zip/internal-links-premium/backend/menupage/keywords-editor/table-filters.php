<?php
namespace ILJ\Backend\MenuPage\Keywords_Editor;

use ILJ\Core\Options;

/**
 * The Table Filters
 *
 * This class is used for rendering the table navigation for {@link \WP_List_Table}
 *
 * @package ILJ\Backend\Menupage\Keywords_Editor
 *
 * @since 2.23.5
 */
final class Table_Filters {

	/**
	 * The table context.
	 *
	 * @var Context
	 */
	private $table_context;

	/**
	 * The table context.
	 *
	 * @param Context $table_context
	 */
	public function __construct($table_context) {
		$this->table_context = $table_context;
	}

	/**
	 * Render the filters based on view.
	 *
	 * @return void
	 */
	public function render() {
		$current_view = $this->table_context->get_current_view();
		if (!in_array($current_view, array('post', 'term'))) {
			return;
		}
		if ('post' === $current_view) {
			$this->render_post_filters();
		} elseif ('term' === $current_view) {
			$this->render_term_filters();
		}
		submit_button(__('Lọc', 'internal-links'), '', 'filter', false);
	}

	/**
	 * Render the post filters.
	 *
	 * @return void
	 */
	private function render_post_filters() {
		$whitelisted_post_statuses = get_post_stati();
		$whitelisted_post_types = Options::getOption(Options\Whitelist::getKey());
		if (isset($_REQUEST['_wpnonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_REQUEST['_wpnonce'])), 'bulk-'.get_current_screen()->id)) {
			$current_post_status = isset($_REQUEST['post_status_filter']) && is_string($_REQUEST['post_status_filter']) ? sanitize_text_field(wp_unslash($_REQUEST['post_status_filter'])) : 'all';
			$current_post_type   = isset($_REQUEST['post_type_filter']) && is_string($_REQUEST['post_type_filter']) ? sanitize_text_field(wp_unslash($_REQUEST['post_type_filter'])) : '';
		} else {
			$current_post_status = 'all';
			$current_post_type   = '';
		}
		?>

		<select name="post_status_filter">
			<option value="" <?php selected('', $current_post_status); ?>><?php esc_html_e('Tất cả trạng thái bài đăng', 'internal-links');?></option>
			<?php foreach ($whitelisted_post_statuses as $post_status) { ?>
				<option value="<?php echo esc_attr($post_status); ?>" <?php selected($post_status, $current_post_status); ?>><?php echo esc_html(ucfirst($post_status)); ?></option>
			<?php } ?>
		</select>

		<select name="post_type_filter">
			<option value="" <?php selected('', $current_post_type); ?>><?php esc_html_e('Tất cả các loại bài đăng được đưa vào danh sách trắng', 'internal-links');?></option>
			<?php
				if (is_array($whitelisted_post_types)) {
					foreach ($whitelisted_post_types as $post_type) {
						?>
						<option value="<?php echo esc_attr($post_type); ?>" <?php selected($post_type, $current_post_type); ?>><?php echo esc_html(ucfirst($post_type)); ?></option>
			<?php
					}
				}
			?>
		</select>
		<?php
	}

	/**
	 * Render the term filters.
	 *
	 * @return void
	 */
	private function render_term_filters() {
		$whitelisted_taxonomies = Options::getOption(Options\TaxonomyWhitelist::getKey());
		if (isset($_REQUEST['_wpnonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_REQUEST['_wpnonce'])), 'bulk-'.get_current_screen()->id)) {
			$current_taxonomy = isset($_REQUEST['taxonomy_filter']) && is_string($_REQUEST['taxonomy_filter']) ? sanitize_text_field(wp_unslash($_REQUEST['taxonomy_filter'])) : '';
		} else {
			$current_taxonomy = '';
		}
		?>
		<select name="taxonomy_filter">
			<option value="" <?php selected('', $current_taxonomy); ?>><?php esc_html_e('Tất cả các phân loại được liệt kê trong danh sách trắng', 'internal-links');?></option>
			<?php
				if (is_array($whitelisted_taxonomies)) {
					foreach ($whitelisted_taxonomies as $whitelisted_taxonomy) {
						$taxonomy = get_taxonomy($whitelisted_taxonomy);
						if (!$taxonomy instanceof \WP_Taxonomy) {
							continue;
						}
					?>
						<option value="<?php echo esc_attr($whitelisted_taxonomy); ?>" <?php selected($whitelisted_taxonomy, $current_taxonomy); ?>><?php echo esc_html($taxonomy->label); ?></option>
			<?php
					}
				}
			?>
		</select>
		<?php
	}
}