<?php
namespace ILJ\Backend\MenuPage\Keywords_Editor;

use ILJ\Data\Content;
use ILJ\Helper\Encoding;
use ILJ\Posttypes\CustomLinks;

if (!class_exists('WP_List_Table')) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}


/**
 * The Keywords editor menu page
 *
 * Responsible for displaying the keywords editor table.
 *
 * @package ILJ\Backend\Menupage\Keywords_Editor
 *
 * @since 2.23.5
 */
final class Table extends \WP_List_Table {

	/**
	 * This class represents a collection of valid posts
	 *
	 * @var Post_Repository
	 */
	private $post_repository;

	/**
	 * This class represents a collection of valid terms
	 *
	 * @var Term_Repository
	 */
	private $term_repository;

	/**
	 * This class represents the custom post type {@link CustomLinks::ILJ_POSTTYPE_CUSTOM_LINKS_SLUG}
	 *
	 * @var Link_Repository
	 */
	private $link_repository;

	/**
	 * The table context which will be collected from request params.
	 *
	 * @var Context
	 */
	private $table_context;

	/**
	 * Constructor for table.
	 *
	 * @param Context         $table_context   The table context which will be constructed from request params.
	 * @param Post_Repository $post_repository This class represents a collection of valid posts
	 * @param Term_Repository $term_repository This class represents a collection of valid terms
	 * @param Link_Repository $link_repository This class represents the custom post type {@link CustomLinks::ILJ_POSTTYPE_CUSTOM_LINKS_SLUG}
	 */
	public function __construct($table_context, $post_repository, $term_repository, $link_repository) {
		parent::__construct(array());
		$this->post_repository = $post_repository;
		$this->term_repository = $term_repository;
		$this->link_repository = $link_repository;
		$this->table_context = $table_context;
		$this->_column_headers = array(
			$this->get_columns(),
			array(),
			$this->get_sortable_columns(),
		);
	}

	/**
	 * Get the repository class from the provided {@link $content_type}
	 *
	 * @param string $content_type Any one of the values ('post', 'term', 'custom-links')
	 *
	 * @return Link_Repository|Post_Repository|Term_Repository
	 */
	private function get_repository($content_type) {
		switch ($content_type) {
			case 'term':
				return $this->term_repository;
			case 'custom-links':
				return $this->link_repository;
			default:
				return $this->post_repository;
		}
	}



	/**
	 * {@inheritDoc}
	 */
	public function prepare_items() {

		$per_page = 20;
		$repository = $this->get_repository($this->table_context->get_current_view());
		$this->items = $repository->get_items();
		$total_items = $repository->get_count_for_search_query();
		$this->set_pagination_args(array(
			'total_items' => $total_items,
			'per_page' => $per_page,
			'total_pages' => ceil($total_items / $per_page),
		));
	}



	/**
	 * {@inheritDoc}
	 */
	public function get_columns() {
		$columns  = array(
			'title' => __('Tiêu đề', 'internal-links'),
		);
		$current_view = $this->table_context->get_current_view();
		if ('post' === $current_view) {
			$columns['entity_type'] = __('Loại bài đăng', 'internal-links');
		} elseif ('term' === $current_view) {
			$columns['entity_type'] = __('Phân loại', 'internal-links');
		}

		$columns['keywords'] = __('Từ khóa', 'internal-links');
		return $columns;
	}

	/**
	 * This method is used by WP_List_Table to render the value for the column
	 *
	 * @param Content $item        The item instance
	 * @param string  $column_name The column name
	 *
	 * @return void
	 */
	public function column_default($item, $column_name) {
		if ('keywords' === $column_name) {
			$keywords = $item->get_keywords();
			$save_url = wp_nonce_url(admin_url("admin-ajax.php?action=ilj_save_keywords_for_content&id={$item->get_id()}&content_type={$item->get_type()}&sub_type={$item->get_entity_type()}"), "ilj_save_keywords_for_content");
			?>
				<select class="ilj-keywords-editor-select-box" multiple="multiple" data-ilj-save-url="<?php echo esc_attr($save_url); ?>" data-ilj-item-id="<?php echo esc_attr($item->get_id()); ?>" data-ilj-item-type="<?php echo esc_attr($item->get_type()); ?>" data-item-sub-type="<?php echo esc_attr($item->get_entity_type(true)); ?>">
					<?php foreach ($keywords as $keyword) {?>
						<?php
							$keyword = Encoding::reverse_transformed_pattern($keyword);
						?>
						<option selected="selected" value="<?php echo esc_attr($keyword); ?>"><?php echo esc_html($keyword); ?></option>
					<?php } ?>
				</select>
				<span class="spinner ilj-spinner"></span>
				<div class="ilj-duplicate-notice"></div>
			<?php
		} elseif ('title' === $column_name) {
			?>
			<strong><a target="_blank" href="<?php echo esc_attr($item->get_edit_link());?>"><?php echo esc_html($item->get_title()); ?></a></strong>
			<?php
		} elseif ('entity_type' === $column_name) {
			echo esc_html(ucfirst($item->get_entity_type()));
		}
	}


	/**
	 * {@inheritDoc}
	 */
	protected function get_views() {
		$page_slug = $this->table_context->get_page_slug();
		$current_view = $this->table_context->get_current_view();
		return array(
			'post' => sprintf(
				'<a href="?%s" %s>' . __('bài viết', 'internal-links') . '</a>(%d)',
				build_query(array('current_view' => 'post', 'page' => $page_slug)),
				'post' === $current_view ? 'class="current"' : '',
				$this->post_repository->get_count()
			),
			'term' => sprintf(
				'<a href="?%s" %s>' . __('Điều khoản', 'internal-links'). '</a>(%d)',
				build_query(array('current_view' => 'term', 'page' => $page_slug)),
				'term' === $current_view ? 'class="current"' : '',
				$this->term_repository->get_count()
			),
			'custom-links' => sprintf(
				'<a href="?%s" %s>'. __('Liên kết tùy chỉnh', 'internal-links'). '</a>(%d)',
				build_query(array('current_view' => 'custom-links', 'page' => $page_slug)),
				'custom-links' === $current_view ? 'class="current"' : '',
				$this->link_repository->get_count()
			),
		);
	}

	/**
	 * Build table from table context.
	 *
	 * @param Context $context The table context.
	 *
	 * @return Table
	 */
	public static function from_context($context) {
		return new Table($context, new Post_Repository($context), new Term_Repository($context), new Link_Repository($context));
	}

	/**
	 * Displays extra controls between bulk actions and pagination.
	 *
	 * @param string $which
	 *
	 * @since 3.1.0
	 */
	protected function extra_tablenav($which) {
		if ('top' !== $which) {
			return;
		}
		$filters = new Table_Filters($this->table_context);
		$filters->render();
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_sortable_columns() {
		return array('title' => array('title', false, __('Tiêu đề', 'internal-links'), __('Bảng sắp xếp theo Tiêu đề.', 'internal-links')));
	}
}
