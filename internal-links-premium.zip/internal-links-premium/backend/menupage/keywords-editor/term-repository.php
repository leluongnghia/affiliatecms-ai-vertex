<?php

namespace ILJ\Backend\MenuPage\Keywords_Editor;

use ILJ\Data\Content;

final class Term_Repository extends Repository {
	/**
	 * Return the total number of items.
	 *
	 * @return int
	 */
	public function get_count() {
		if (empty($this->context->get_taxonomy())) {
			return 0;
		}
		return intval(wp_count_terms(array('taxonomy' => $this->context->get_taxonomy())));
	}

	/**
	 * Return the total number of items by applying search query.
	 *
	 * @return int
	 */
	public function get_count_for_search_query() {
		if (empty($this->context->get_taxonomy())) {
			return 0;
		}
		return intval(wp_count_terms(array('taxonomy' => $this->context->get_taxonomy(), 'name__like' => $this->context->get_search_query())));
	}

	/**
	 * Get the items filtered by context.
	 *
	 * @return array<Content>
	 */
	public function get_items() {
		if (empty($this->context->get_taxonomy())) {
			return array();
		}
		$offset = 0;
		if ($this->context->get_page_number()) {
			$offset = ($this->context->get_page_number() - 1) * $this->context->get_items_per_page();
		}
		$args = array(
			'number' => $this->context->get_items_per_page(),
			'offset' => $offset,
			'fields' => 'ids',
			'taxonomy' => $this->context->get_taxonomy(),
			'hide_empty' => false,
			'name__like' => $this->context->get_search_query(),
			'hierarchical' => false,
		);

		if ($this->context->get_sorting_enabled()) {
			$args = array_merge($args, array(
				'orderby' => 'name',
				'order' => $this->context->get_sort_order()
			));
		}

		$term_ids = get_terms($args);
		return array_map(array(Content::class, 'from_term_id'), $term_ids);
	}
}
