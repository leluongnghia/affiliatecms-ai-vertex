<?php
namespace ILJ\Backend\MenuPage\Tour;

use ILJ\Backend\MenuPage\Tour\Step;

/**
 * Step: Editor
 *
 * Gives insights about creating keywords for an asset
 *
 * @package ILJ\Backend\Tour
 * @since   1.1.0
 */
class Editor extends Step {

	/**
	 * renderContent
	 *
	 * @return void
	 */
	public function renderContent() {
		?>
		<h1><?php esc_html_e('Bắt đầu với việc thiết lập từ khóa cho bài viết và trang của bạn', 'internal-links'); ?></h1>
		<?php
		$data_container = array(
			array(
				'title'       => __('Tìm Trình chỉnh sửa từ khóa', 'internal-links'),

				'description' => '<p>' .
				__('<strong>Trình chỉnh sửa từ khóa</strong> là trái tim của Công cụ ép liên kết nội bộ.', 'internal-links') . ' ' . __('Với sự trợ giúp của nó, bạn có thể <strong>định cấu hình từ khóa</strong> cho bài đăng của mình, sau này sẽ tạo thành văn bản liên kết cho mỗi bài đăng.', 'internal-links') .
				'</p><p>' .
				__('Bạn có thể tìm thấy Trình chỉnh sửa từ khóa bất cứ lúc nào bạn chỉnh sửa nội dung (dù là trang hay bài đăng). Nó nằm trên <strong>thanh bên phải</strong> trong cửa sổ soạn thảo.', 'internal-links') .
				'</p><p>' .
				__('Trong video, chúng tôi sẽ hướng dẫn bạn cách truy cập Trình chỉnh sửa từ khóa của bài đăng hoặc trang.', 'internal-links') .
				'</p>',

				'video'       => '-y4HTOYNBP0',
			),
			array(
				'title'       => __('Thêm từ khóa vào nội dung của bạn', 'internal-links'),

				'description' => '<p>' .
				__('Với sự trợ giúp của Trình chỉnh sửa từ khóa, bạn có thể <strong>gán từ khóa cho một bài đăng</strong>, sau đó nó sẽ sử dụng từ khóa này cho các liên kết nội bộ.', 'internal-links') .
				'</p><p>' .
				__('Thêm từ khóa bạn muốn vào trường nhập thích hợp và xác nhận bằng phím Enter (hoặc bằng cách nhấp vào nút).', 'internal-links') .
				'</p><p>' .
				__('Bạn có thể thêm từng từ khóa mong muốn hoặc bằng cách phân tách chúng bằng dấu phẩy.', 'internal-links') .
				'</p><p>' .
				__('Video hiển thị ví dụ về cách gán từ khóa cho bài đăng.', 'internal-links') .
				'</p>',

				'video'       => 'rc9EqywuwCI',
			),
			array(
				'title'       => __('Tạo liên kết thông minh với tính năng tạo khoảng cách', 'internal-links'),

				'description' => '<p>' .
				__('Với sự trợ giúp của tính năng khoảng cách thông minh, bạn có thể <strong>đa dạng hóa văn bản liên kết của mình</strong> tốt hơn nữa.', 'internal-links') . ' ' . __('Bạn có thể có được hồ sơ liên kết tự nhiên hơn và <strong>bao gồm phạm vi rộng hơn</strong> các liên kết có thể có.', 'internal-links') .
				'</p><p>' .
				__('Đó là bởi vì bạn không còn chỉ liên kết đến các từ khóa hoặc cụm từ được xác định rõ ràng nữa.', 'internal-links') . ' ' . __('Tính năng này cho phép xác định các từ cố định trong một cụm từ và <strong>tự do tạo các biến thể</strong> trong khoảng cách giữa chúng.', 'internal-links') .
				'</p><p>' .
				__('Tính năng khoảng cách có thể được kích hoạt bằng cách nhấp vào liên kết trong Trình chỉnh sửa từ khóa (bên dưới trường nhập).', 'internal-links') . '</p><p>' .
				__('Bạn có 3 lựa chọn để xác định khoảng trống.', 'internal-links') . ' ' . __('Giả sử giá trị khoảng cách được định cấu hình là 3, nó hoạt động theo những cách sau, tùy thuộc vào loại khoảng cách:', 'internal-links') .
				'</p><ul><li>' .
				__('<strong>Loại "Tối thiểu"</strong>: Một cụm từ được liên kết nếu có từ một đến ba từ giữa các từ liền kề.', 'internal-links') . '</li><li>' .
				__('<strong>Loại "Chính xác"</strong>: Một cụm từ được liên kết nếu có đúng 3 từ giữa các từ liền kề.', 'internal-links') . '</li><li>' .
				__('<strong>Loại "Tối đa"</strong>: Một cụm từ được liên kết nếu có ít nhất 3 từ trở lên giữa các từ liền kề.', 'internal-links') .
				'</li></ul><p>' .
				__('Các từ liền kề là không đổi và được bao gồm trong liên kết.', 'internal-links') . ' ' . __('Các từ khóa khoảng cách có thể thay đổi.', 'internal-links') .
				'</p><p>' .
				__('Trong video, bạn có thể xem ví dụ về cách định cấu hình các khoảng trống.', 'internal-links'),

				'video'       => '66eCwCiwGbM',
			),
		);

		foreach ($data_container as $data) {
			$this->renderFeatureRow($data);
		}
	}
}
