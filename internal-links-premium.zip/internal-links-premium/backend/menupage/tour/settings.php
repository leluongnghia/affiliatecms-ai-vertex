<?php
namespace ILJ\Backend\MenuPage\Tour;

use ILJ\Backend\MenuPage\Tour\Step;

/**
 * Step: Settings
 *
 * Gives a short introduction to possible settings
 *
 * @package ILJ\Backend\Tour
 * @since   1.1.0
 */
class Settings extends Step {

	/**
	 * renderContent
	 *
	 * @return void
	 */
	public function renderContent() {
		?>
		<h1><?php esc_html_e('Giới thiệu ngắn gọn về các cài đặt quan trọng nhất', 'internal-links'); ?></h1>
		<?php
		$data_container = array(
			array(
				'title'       => __('Danh sách đen: Loại trừ bất kỳ nội dung nào khỏi liên kết', 'internal-links'),

				'description' => '<p>' .
				__('Để <strong>ngăn chặn liên kết không mong muốn</strong>, bạn có thể tận dụng tính năng danh sách đen.', 'internal-links') . ' ' . __('Tính năng này loại trừ nội dung cụ thể khỏi việc xây dựng liên kết và cung cấp cho bạn toàn quyền kiểm soát hành vi liên kết mọi lúc.', 'internal-links') .
				'</p><p>' .
				__('Bạn có thể tìm thấy danh sách đen trong cài đặt Máy ép trái cây liên kết nội bộ trong tab "Nội dung".', 'internal-links') .
				'</p><p>' .
				__('Trường đầu vào hoạt động giống như tìm kiếm từ khóa.', 'internal-links') . ' ' . __('Để <strong>loại trừ một hoặc nhiều bài đăng khỏi liên kết</strong>, hãy làm theo quy trình sau:', 'internal-links') .
				'</p><ol><li>' .
				__('Tìm bài đăng (hoặc trang) mong muốn.', 'internal-links') .
				'</li><li>' .
				__('Thêm nó bằng cách nhấp vào danh sách đen.', 'internal-links') .
				'</li><li>' .
				__('Cứu', 'internal-links') .
				'</li></ol><p>' .
				__('Do đó, bài viết này sẽ không còn hiển thị các liên kết nội bộ được tạo tự động nữa.', 'internal-links') .
				'</p><p>' .
				__('Trong video, bạn có thể xem cách định cấu hình danh sách đen và cài đặt này có tác dụng gì đối với liên kết.', 'internal-links') .
				'</p>',

				'video'       => 'QR92w3wpbN4',
			),
			array(
				'title'       => __('Danh sách trắng: Xác định loại nội dung phải luôn được liên kết', 'internal-links'),

				'description' => '<p>' .
				__('Với danh sách trắng, bạn có thể <strong>bao gồm các loại bài đăng và trang</strong> mà bạn luôn muốn <strong>được liên kết</strong>. Điều này cho phép bạn loại trừ các loại bài đăng hoàn chỉnh khỏi liên kết ngoài danh sách đen.', 'internal-links') .
				'</p><p>' .
				__('Bạn có thể tìm thấy danh sách trắng trong cài đặt Máy ép trái cây liên kết nội bộ trong tab “Nội dung”.', 'internal-links') .  ' ' . __('Cài đặt danh sách trắng nằm ngay dưới cài đặt danh sách đen.', 'internal-links') .
				'</p><p>' .
				__('Trường nhập cho danh sách trắng sẽ mở ra một danh sách với tất cả các loại trang và bài đăng có sẵn.', 'internal-links') .  ' ' . __('Chọn tất cả các loại mà bạn muốn cho phép liên kết.', 'internal-links') .  ' ' . __('Sau khi lưu, cài đặt sẽ được kích hoạt.', 'internal-links') .
				'</p><p>' .
				__('Trong video, bạn có thể thấy cấu hình mô hình của danh sách trắng và ảnh hưởng của nó đến hành vi liên kết.', 'internal-links') .
				'</p>',

				'video'       => 'cVgFPXW9WjU',
			),
			array(
				'title'       => __('Xác định thứ tự các từ khóa được cấu hình để liên kết', 'internal-links'),
				'description' => '<p>' .
				__('Định cấu hình thứ tự mà bạn muốn sử dụng các từ khóa đã định cấu hình để liên kết.', 'internal-links') .  ' ' . __('Điều này mang lại cho bạn nhiều ảnh hưởng hơn nữa đến việc <strong>các cụm từ dài hơn hay ngắn hơn</strong> được liên kết.', 'internal-links') .
				'</p><p>' .
				__('Bạn có thể tìm thấy cài đặt thứ tự trong Máy ép trái cây liên kết nội bộ trong tab "Nội dung", ngay bên dưới danh sách trắng.', 'internal-links') .
				'</p><p>' .
				__('Có tổng cộng 3 cài đặt khác nhau có sẵn:', 'internal-links') .
				'</p><ol><li>' .
				__('<strong>Liên kết từ khóa được định cấu hình đầu tiên trước</strong>: Từ khóa được sử dụng theo thứ tự bạn đã nhập chúng vào Trình chỉnh sửa từ khóa.', 'internal-links') .
				'</li><li>' .
				__('<strong>Số từ cao nhất được đặt trước</strong>: Các cụm từ có số từ cao nhất sẽ được ưu tiên liên kết.', 'internal-links') .
				'</li><li>' .
				__('<strong>Số từ thấp nhất trước tiên</strong>: Ưu tiên các cụm từ có số từ thấp nhất để liên kết.', 'internal-links') .
				'</li></ol><p>' .
				__('Trong video, bạn có thể thấy các cài đặt riêng lẻ tác động như thế nào đến hành vi liên kết.', 'internal-links') .
				'</p>',

				'video'       => 'UVk0XaovXDE',
			),
		);

		foreach ($data_container as $data) {
			$this->renderFeatureRow($data);
		}
	}
}
