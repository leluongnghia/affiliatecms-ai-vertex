<?php
namespace ILJ\Backend\MenuPage\Tour;

use ILJ\Backend\MenuPage\Tour\Step;

/**
 * Step: Links
 *
 * Shows the result and output of generated links
 *
 * @package ILJ\Backend\Tour
 * @since   1.1.0
 */
class Links extends Step {

	/**
	 * renderContent
	 *
	 * @return void
	 */
	public function renderContent() {
		?>
		<h1><?php esc_html_e('Tìm hiểu cách tác động đến hành vi liên kết', 'internal-links'); ?></h1>
		<?php
		$data_container = array(
			array(
				'title'       => __('Tự động tạo đầu ra liên kết', 'internal-links'),

				'description' => '<p>' .
				__('Ngay khi bạn lưu từ khóa cho nội dung của mình, các liên kết nội bộ sẽ được kích hoạt.', 'internal-links') .
				'</p><p>' .
				__('Plugin này hoạt động với <strong>chỉ mục riêng</strong> dành cho các liên kết nội bộ.', 'internal-links') . ' ' . __('Nó <strong>tự động cập nhật</strong> sau khi bạn chỉnh sửa nội dung hoặc từ khóa.', 'internal-links') . ' ' . __('Điều này sẽ không ảnh hưởng đến <strong>thời gian tải nhanh</strong> của trang web của bạn.', 'internal-links') . ' ' . __('Khía cạnh này làm cho Internal Link Juicer <strong>khác biệt với các plugin khác</strong> có chức năng tương tự.', 'internal-links') .
				'</p><p>' .
				__('Video hiển thị ví dụ về hai bài đăng khác nhau được liên kết.', 'internal-links') .
				'</p>',

				'video'       => 'lVh1EzALiJs',
			),
			array(
				'title'       => __('Dễ dàng tùy chỉnh đầu ra bằng cách sử dụng các mẫu', 'internal-links'),

				'description' => '<p>' .
				__('Với sự trợ giúp của tính năng mẫu, bạn có thể <strong>thay đổi và cá nhân hóa đầu ra</strong> của các liên kết nội bộ.', 'internal-links') .
				'</p><p>' .
				__('Bạn có thể tìm thấy cài đặt mẫu liên kết trong cài đặt plugin trong tab "Liên kết".', 'internal-links') .
				'</p><p>' .
				__('Ở đó bạn có thể cập nhật đầu ra của một liên kết bằng mã HTML của riêng bạn.', 'internal-links') . ' ' . __('Các thẻ mẫu <code>{{url}</code> và <code>{{anchor}</code> hiện có sẵn.', 'internal-links') . ' ' . __('Trong nội dung của bạn, những phần giữ chỗ này sau đó sẽ được thay thế bằng các tham số tương ứng (đích liên kết và văn bản liên kết).', 'internal-links') .
				'</p><p>' .
				__('Video này cho bạn thấy một ví dụ về cách che giấu các liên kết được xây dựng bằng JavaScript.', 'internal-links') .
				'</p>',

				'video'       => '-qoxE49bVBw',
			),
			array(
				'title'       => __('Kiểm soát tần số liên kết riêng theo nhu cầu của bạn', 'internal-links'),
				'description' => '<p>' . __('Với tính năng này, bạn có thể chủ động kiểm soát tần số liên kết.', 'internal-links') . ' ' . __('Bạn có thể giới hạn số lượng liên kết tối đa được tạo hoặc cho phép nhiều liên kết của cùng một URL đích từ cùng một nội dung.', 'internal-links') . '</p><p>' . __('Bạn có thể tìm thấy các cài đặt này trong cài đặt Máy ép trái cây liên kết nội bộ trong tab "Nội dung".', 'internal-links') . '</p><p>' . __('Nhìn chung, bạn có sẵn các tùy chọn sau, bao gồm tất cả các trường hợp sử dụng:', 'internal-links') . '</p><ul><li>' . __('Đặt “<strong>số lượng liên kết tối đa cho mỗi bài đăng</strong>” trong một nội dung.', 'internal-links') . ' ' . __('Với giá trị "0", bạn liên kết tất cả các từ khóa có thể.', 'internal-links') . '</li><li>' . __('Đặt “<strong>tần suất tối đa cho mỗi bài đăng</strong>” về mức độ một bài đăng có thể liên kết đến một URL đích duy nhất.', 'internal-links') . ' ' . __('Ở đây, giá trị "0" cũng cho phép liên kết các URL đích tối đa, ngay cả khi chúng giống hệt nhau.', 'internal-links') . '</li><li>' . __('Chọn hộp “<strong>liên kết thường xuyên nhất có thể</strong>”.', 'internal-links') . ' ' . __('Nếu bạn kích hoạt cài đặt này, sẽ không có sự xem xét nào về số lượng liên kết tối đa hoặc tần suất tối đa của các URL mục tiêu giống hệt nhau.', 'internal-links') . ' ' . __('Bất cứ nơi nào có thể có liên kết, cài đặt này sẽ tạo liên kết.', 'internal-links') . '</li></ul><p>' . __('Hãy xem video và bạn sẽ thấy tính năng này được thể hiện một cách sâu sắc.', 'internal-links') . '</p>',
				'video'       => 'rZfMjA8IhVg',
			),
		);

		foreach ($data_container as $data) {
			$this->renderFeatureRow($data);
		}
	}
}
