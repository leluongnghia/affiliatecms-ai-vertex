<?php
namespace ILJ\Backend\MenuPage\Tour;

use ILJ\Backend\MenuPage\Tour\Step;

/**
 * Step: Intro
 *
 * Gives a brief description of the tour
 *
 * @package ILJ\Backend\Tour
 * @since   1.1.0
 */
class Intro extends Step {
	
	/**
	 * renderContent
	 *
	 * @return void
	 */
	public function renderContent() {
		?>
		<div class="intro">
			<div class="banner">
				<img src="<?php echo esc_url(ILJ_URL . '/admin/img/character-onboarding.png'); ?>" />
			</div>
			<div class="content">
				<h2><?php esc_html_e('Bắt đầu chuyến tham quan thông qua plugin', 'internal-links'); ?></h2>
				<p>
					<?php esc_html_e('Chúng tôi sẽ giới thiệu cho bạn các chức năng quan trọng nhất của Máy ép trái cây liên kết nội bộ sau vài phút.', 'internal-links'); ?>
					<?php esc_html_e('Với điều đó, bạn có thể bắt đầu ngay lập tức và tận dụng tối đa các liên kết nội bộ của mình.', 'internal-links'); ?>
				</p>
			</div>
		</div>
		<?php
	}
}
