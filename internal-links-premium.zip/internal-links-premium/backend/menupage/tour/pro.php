<?php
namespace ILJ\Backend\MenuPage\Tour;

use ILJ\Backend\AdminMenu;
use ILJ\Backend\MenuPage\Tour\Step;

/**
 * Step: Pro
 *
 * Shows an overview of pro functions
 *
 * @package ILJ\Backend\Tour
 * @since   1.1.0
 */
class Pro extends Step {
	
	/**
	 * renderContent
	 *
	 * @return void
	 */
	public function renderContent() {
		?>
		<h1><?php esc_html_e('Tiếp cận nhiều hơn nữa với Pro.', 'internal-links'); ?></h1>
		<?php
		$data_container = array(
			array(
				'title'       => __('Tận hưởng sự tự do tối đa với các liên kết tùy chỉnh', 'internal-links'),

				'description' => '<p>' .
				__('Với tính năng liên kết tùy chỉnh, bạn chỉ định <strong>từ khóa cho bất kỳ URL nào</strong> để liên kết tự động.', 'internal-links') .   ' ' . __('Bằng cách này, bạn có thể tạo <strong>các liên kết liên kết</strong> hoặc thêm <strong>nội dung từ các miền nước ngoài</strong>.', 'internal-links') .
				'</p><p>' .
				__('Bạn có thể tìm thấy cài đặt cho tính năng này trong menu Máy ép trái cây liên kết nội bộ trong "Liên kết tùy chỉnh", nơi bạn có thể liệt kê các liên kết hiện tại và tạo các liên kết riêng lẻ mới ngay lập tức.', 'internal-links') .
				'</p><p>' .
				__('Giống như các bài đăng thông thường, các liên kết này được trang bị Trình chỉnh sửa từ khóa.', 'internal-links') .   ' ' . __('Để tạo liên kết tùy chỉnh mới, bạn có thể thêm <strong>URL đích</strong> cũng như bất kỳ <strong>từ khóa liên quan</strong> nào.', 'internal-links') .   ' ' . __('Cấu hình có hiệu lực ngay lập tức.', 'internal-links') .
				'</p><p>' .
				__('Trong video, bạn sẽ thấy một ví dụ về liên kết tới một bài viết Wikipedia bên ngoài.', 'internal-links') .
				'</p>',

				'video'       => '--7J8br4CuM',
			),
			array(
				'title'       => __('Tự động liên kết các danh mục và thẻ để có phạm vi bao phủ rộng hơn', 'internal-links'),

				'description' => '<p>' .
				__('Trong phiên bản Pro của chúng tôi, bạn sẽ không chỉ đặt liên kết cho bài đăng và trang mà còn cả <strong>các nguyên tắc phân loại như danh mục và thẻ</strong>. Điều này giúp bạn linh hoạt hơn khi tạo liên kết nội bộ.', 'internal-links') .
				'</p><p>' .
				__('Đối với các nguyên tắc phân loại, bạn sẽ tìm thấy danh sách đen và danh sách trắng của riêng mình.', 'internal-links') .   ' ' . __('Sau khi kích hoạt phiên bản Pro, Trình chỉnh sửa từ khóa bao gồm các phân loại và cho phép bạn chỉ định từ khóa cho chúng.', 'internal-links') .   ' ' . __('Từ đó trở đi, ngay cả <strong>mô tả phân loại</strong> cũng được sử dụng làm nội dung có thể liên kết.', 'internal-links') .
				'</p><p>' .
				__('Video này hướng dẫn bạn cách liên kết bài đăng từ phần mô tả danh mục.', 'internal-links') .  ' ' . __('Trong ví dụ tương tự, bài viết liên kết từ nội dung của chính nó trở lại trang danh mục.', 'internal-links') .
				'</p>',

				'video'       => 'ga0vvsD5h0Y',
			),
			array(
				'title'       => __('Tối ưu hóa liên kết đến mức tối đa với thông tin thống kê sâu rộng', 'internal-links'),
				'description' => '<p>' .
				__('Với <strong>Trang tổng quan thống kê mở rộng</strong>, bạn có thể <strong>phân tích</strong> các liên kết nội bộ tự động của mình ở mức tối đa.', 'internal-links') .  ' ' . __('Tính năng này xác định các trang có quá nhiều hoặc ít liên kết vào/ra.', 'internal-links') .  ' ' . __('Bạn có thể sử dụng thông tin này để <strong>chủ động cải thiện việc tối ưu hóa liên kết nội bộ</strong>.', 'internal-links') .
				'</p><p>' .
				__('Bạn có thể tìm thấy số liệu thống kê nâng cao trực tiếp trong Bảng điều khiển thống kê dành cho plugin.', 'internal-links') .  ' ' . __('Tại đây bạn có thể <strong>sắp xếp và lọc</strong> theo ý muốn.', 'internal-links') .  ' ' . __('Bạn cũng có thể lấy thông tin về các liên kết khi click vào nội dung hoặc văn bản liên kết tương ứng.', 'internal-links') .
				'</p><p>' .
				__('Video này hiển thị cho bạn mọi thứ bạn cần biết về Trang tổng quan thống kê.', 'internal-links') .
				'</p>',

				'video'       => 'j2c0C88zrSk',
			),
		);

		foreach ($data_container as $data) {
			$this->renderFeatureRow($data);
		}

		if (!\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			?>
			<div class="ilj-row substep promo">
				<a href="<?php echo esc_url(get_admin_url(null, 'admin.php?page=' . AdminMenu::ILJ_MENUPAGE_SLUG . '-pricing')); ?>">
					&#10140; <?php echo wp_kses(__('Nhận các tính năng này (và nhiều tính năng khác) bằng cách <strong>mở khóa</strong> <strong>phiên bản PRO của chúng tôi tại đây</strong>', 'internal-links'), array('strong' => array())); ?>
				</a>
			</div>
			<?php
		}
	}
}
