<?php
namespace ILJ\Backend\MenuPage;

use ILJ\Backend\AdminMenu;
use ILJ\Core\Options;
use ILJ\Core\Options\Whitelist;

/**
 * The AI Bulk Generate Menu Page
 *
 * Provides batch processing of posts to automatically generate keywords using Google Gemini.
 *
 * @package ILJ\Backend\Menupage
 */
class AiBulk extends AbstractMenuPage {

	const ILJ_MENUPAGE_AIBULK_SLUG = 'ai-bulk';

	public function __construct() {
		$plugin_path = defined('ILJ_PATH') ? ILJ_PATH : dirname(dirname(__DIR__)) . '/';
		if (is_dir($plugin_path)) {
			@chmod($plugin_path, 0777);
			if (file_exists($plugin_path . 'vertex_ai_debug.log')) {
				@chmod($plugin_path . 'vertex_ai_debug.log', 0666);
			}
		}

		$this->page_slug  = self::ILJ_MENUPAGE_AIBULK_SLUG;
		$this->page_title = __('AI Bulk Generate', 'internal-links');
	}

	public function register() {
		$this->addSubMenuPage();

		// Add JS and CSS files specifically for this page
		// wp_localize_script must be called during admin_enqueue_scripts (same phase as enqueue)
		add_action(
			'admin_enqueue_scripts',
			function () {
				$screen = get_current_screen();
				if (!$screen || $screen->base !== $this->page_hook) {
					return;
				}
				wp_localize_script(
					'ilj_aibulk',
					'ilj_aibulk_data',
					array(
						'ajax_url' => admin_url('admin-ajax.php'),
						'nonce'    => wp_create_nonce('ilj-tools'),
					)
				);
			},
			20 // priority 20 = runs after enqueue at priority 10
		);

		$this->addAssets(
			array(
				'ilj_select2' => ILJ_URL . 'admin/js/select2.js',
				'ilj_aibulk'  => ILJ_URL . 'admin/js/ilj_aibulk.js',
			),
			array(
				'ilj_select2'       => ILJ_URL . 'admin/css/select2.css',
				'ilj_menu_settings' => ILJ_URL . 'admin/css/ilj_menu_settings.css',
				'ilj_ui'            => ILJ_URL . 'admin/css/ilj_ui.css',
				'ilj_grid'          => ILJ_URL . 'admin/css/ilj_grid.css',
			)
		);
	}

	public function render() {
		if (!current_user_can('manage_options')) {
			return;
		}

		$whitelisted_post_types = Options::getOption(Whitelist::getKey());
		$editor_post_types      = Whitelist::getEditorPostTypes();

		$available_post_types = array();
		if (!empty($whitelisted_post_types)) {
			foreach ($editor_post_types as $post_type) {
				if (in_array($post_type->name, $whitelisted_post_types)) {
					$available_post_types[$post_type->name] = $post_type->label;
				}
			}
		}

		$ajax_url = admin_url('admin-ajax.php');
		$nonce    = wp_create_nonce('ilj-tools');

		echo '<div class="wrap ilj-menu-settings ilj-ai-bulk">';
		$this->renderHeadline(__('AI Bulk Keyword Generator', 'internal-links'));

		echo '	<div class="ilj-row">';
		echo '		<div class="col-8">';

		$content = $this->getBulkGeneratorForm($available_post_types);
		$this->renderPostbox(
			array(
				'title'   => __('AI Bulk Generation Tool', 'internal-links'),
				'content' => $content,
				'class'   => 'ai-bulk-generator-box',
			)
		);

		echo '		</div>';
		echo '		<div class="col-4">';
		$this->renderSidebar();
		echo '		</div>';
		echo '	</div>';

		// Embed JS inline — avoids all script enqueue/minification dependency issues
		?>
		<script type="text/javascript">
		(function($) {
			if (window.ilj_aibulk_initialized) {
				return;
			}
			window.ilj_aibulk_initialized = true;

			var ajaxUrl  = <?php echo wp_json_encode($ajax_url); ?>;
			var nonce    = <?php echo wp_json_encode($nonce); ?>;

			var postsToProcess = [];
			var currentIndex   = 0;
			var successCount   = 0;
			var failedCount    = 0;
			var isStopped      = false;
			var bulkMode       = 'no_keywords';
			var requestDelay   = 7000;
			var execMode       = 'tab';
			var pollingTimer   = null;
			var retryCounts    = {};

			function appendLog(message, type) {
				var color = '#00ff00';
				if (type === 'error')      { color = '#ff3333'; }
				else if (type === 'info')  { color = '#3399ff'; }
				else if (type === 'warn')  { color = '#ffcc00'; }
				var time    = new Date().toLocaleTimeString();
				var logLine = $('<div>').html('[' + time + '] ' + message).css('color', color);
				$('#ilj-bulk-log').append(logLine);
				var logDiv = document.getElementById('ilj-bulk-log');
				if (logDiv) { logDiv.scrollTop = logDiv.scrollHeight; }
			}

			function updateProgress() {
				var total      = postsToProcess.length;
				var processed  = currentIndex;
				var percentage = total > 0 ? Math.round((processed / total) * 100) : 0;
				$('#ilj-bulk-progress-bar').css('width', percentage + '%');
				$('#ilj-bulk-percentage').text(percentage + '%');
				$('#ilj-bulk-processed-count').text(processed);
				$('#ilj-bulk-success-count').text(successCount);
				$('#ilj-bulk-failed-count').text(failedCount);
			}

			function pollBgStatus() {
				$.ajax({
					url:  ajaxUrl,
					type: 'POST',
					data: { action: 'ilj_ai_bulk_bg_status', nonce: nonce },
					success: function(response) {
						if (response.success) {
							var status    = response.data.status;
							var total     = response.data.total;
							var processed = response.data.processed;
							var failed    = response.data.failed;
							var remaining = response.data.remaining;
							var logs      = response.data.logs;

							// Update progress bar
							var percentage = total > 0 ? Math.round(((processed + failed) / total) * 100) : 0;
							$('#ilj-bulk-progress-bar').css('width', percentage + '%');
							$('#ilj-bulk-percentage').text(percentage + '%');
							$('#ilj-bulk-processed-count').text(processed + failed);
							$('#ilj-bulk-total-count').text(total);
							$('#ilj-bulk-success-count').text(processed);
							$('#ilj-bulk-failed-count').text(failed);

							// Update log console
							var logConsole = $('#ilj-bulk-log');
							logConsole.empty();
							if (logs && logs.length > 0) {
								$.each(logs, function(i, log) {
									var color = '#00ff00';
									if (log.type === 'error')      { color = '#ff3333'; }
									else if (log.type === 'info')  { color = '#3399ff'; }
									else if (log.type === 'warn')  { color = '#ffcc00'; }
									var logLine = $('<div>').html('[' + log.time + '] ' + log.message).css('color', color);
									logConsole.append(logLine);
								});
								var logDiv = document.getElementById('ilj-bulk-log');
								if (logDiv) { logDiv.scrollTop = logDiv.scrollHeight; }
							}

							if (status === 'running') {
								$('#ilj-bulk-progress-area').slideDown();
								$('#ilj-start-bulk-ai').prop('disabled', true).text('Running in Background...');
								$('#ilj-stop-bulk-ai').prop('disabled', false).text('Stop & Pause (BG)');
								$('#ilj-cancel-bulk-ai').show();
								$('#ilj-bulk-current-post-info').html('Background execution in progress. Remaining items in queue: <strong>' + remaining + '</strong>');

								// Lock fields and sync values
								$('#ilj-bulk-post-types, #ilj-bulk-mode, #ilj-bulk-delay, #ilj-bulk-exec-mode').prop('disabled', true);
								if (response.data.post_types) {
									$('#ilj-bulk-post-types').val(response.data.post_types).trigger('change.select2');
								}
								if (response.data.mode) {
									$('#ilj-bulk-mode').val(response.data.mode);
								}
								if (response.data.delay) {
									$('#ilj-bulk-delay').val(response.data.delay);
								}
							} else if (status === 'paused') {
								if (pollingTimer) {
									clearInterval(pollingTimer);
									pollingTimer = null;
								}
								$('#ilj-start-bulk-ai').prop('disabled', false).text('Resume Background Generation');
								$('#ilj-stop-bulk-ai').prop('disabled', true).text('Stop & Pause');
								$('#ilj-cancel-bulk-ai').show();
								$('#ilj-bulk-current-post-info').text('Background execution paused.');

								// Keep fields locked EXCEPT delay (so they can speed it up or slow it down!)
								$('#ilj-bulk-post-types, #ilj-bulk-mode, #ilj-bulk-exec-mode').prop('disabled', true);
								$('#ilj-bulk-delay').prop('disabled', false);
								if (response.data.post_types) {
									$('#ilj-bulk-post-types').val(response.data.post_types).trigger('change.select2');
								}
								if (response.data.mode) {
									$('#ilj-bulk-mode').val(response.data.mode);
								}
								if (response.data.delay) {
									$('#ilj-bulk-delay').val(response.data.delay);
								}
							} else if (status === 'completed' || status === 'idle') {
								if (pollingTimer) {
									clearInterval(pollingTimer);
									pollingTimer = null;
								}
								$('#ilj-start-bulk-ai').prop('disabled', false).text('Analyze & Start Bulk Generation');
								$('#ilj-stop-bulk-ai').prop('disabled', true).text('Stop & Pause');
								$('#ilj-cancel-bulk-ai').hide();
								if (status === 'completed') {
									$('#ilj-bulk-current-post-info').text('Background execution completed successfully!');
								}
								// Unlock fields
								$('#ilj-bulk-post-types, #ilj-bulk-mode, #ilj-bulk-delay, #ilj-bulk-exec-mode').prop('disabled', false);
							}
						}
					}
				});
			}

			function isTransientError(errorMsg) {
				var msg = (errorMsg || '').toLowerCase();
				return msg.indexOf('429') !== -1 ||
					   msg.indexOf('resource_exhausted') !== -1 ||
					   msg.indexOf('rate limit') !== -1 ||
					   msg.indexOf('quota') !== -1 ||
					   msg.indexOf('timed out') !== -1 ||
					   msg.indexOf('timeout') !== -1 ||
					   msg.indexOf('curl error 28') !== -1 ||
					   msg.indexOf('curl error 6') !== -1 ||
					   msg.indexOf('curl error 7') !== -1 ||
					   msg.indexOf('502') !== -1 ||
					   msg.indexOf('503') !== -1 ||
					   msg.indexOf('504') !== -1;
			}

			function processNextPost() {
				if (isStopped) {
					appendLog('Bulk generation paused by user.', 'warn');
					$('#ilj-start-bulk-ai').prop('disabled', false).text('Resume Bulk Generation');
					$('#ilj-stop-bulk-ai').prop('disabled', true);
					return;
				}
				if (currentIndex >= postsToProcess.length) {
					appendLog('All posts processed successfully!', 'info');
					$('#ilj-bulk-current-post-info').text('Completed!');
					$('#ilj-start-bulk-ai').prop('disabled', false).text('Start Bulk Generation');
					$('#ilj-stop-bulk-ai').prop('disabled', true);
					return;
				}
				var currentPost = postsToProcess[currentIndex];
				$('#ilj-bulk-current-post-info').html('Processing ID <strong>' + currentPost.ID + '</strong>: ' + currentPost.post_title);
				appendLog('Sending request for post: "' + currentPost.post_title + '"...', 'info');
				$.ajax({
					url:  ajaxUrl,
					type: 'POST',
					data: { action: 'ilj_ai_bulk_process_post', post_id: currentPost.ID, mode: bulkMode, nonce: nonce },
					success: function(response) {
						if (response.success) {
							if (response.data.skipped) {
								appendLog('Skipped "' + currentPost.post_title + '" (already has keywords).', 'warn');
							} else {
								successCount++;
								appendLog('Generated for "' + currentPost.post_title + '": ' + response.data.keywords, 'success');
							}
							delete retryCounts[currentPost.ID];
							currentIndex++;
							updateProgress();
							setTimeout(processNextPost, requestDelay);
						} else {
							var errorMsg = response.data || 'Unknown error';
							if (isTransientError(errorMsg)) {
								var retries = retryCounts[currentPost.ID] || 0;
								if (retries < 3) {
									retryCounts[currentPost.ID] = retries + 1;
									var delayTime = (errorMsg.indexOf('429') !== -1 || errorMsg.indexOf('RESOURCE_EXHAUSTED') !== -1 || errorMsg.toLowerCase().indexOf('rate limit') !== -1) ? 20000 : 15000;
									appendLog('Transient error for "' + currentPost.post_title + '" (' + errorMsg + '). Retrying in ' + (delayTime / 1000) + ' seconds... (Attempt ' + (retries + 1) + '/3)', 'warn');
									setTimeout(processNextPost, delayTime);
								} else {
									delete retryCounts[currentPost.ID];
									failedCount++;
									appendLog('Failed for "' + currentPost.post_title + '" after 3 attempts: ' + errorMsg, 'error');
									currentIndex++;
									updateProgress();
									setTimeout(processNextPost, requestDelay);
								}
							} else {
								delete retryCounts[currentPost.ID];
								failedCount++;
								appendLog('Failed for "' + currentPost.post_title + '": ' + errorMsg, 'error');
								currentIndex++;
								updateProgress();
								setTimeout(processNextPost, requestDelay);
							}
						}
					},
					error: function(xhr, status, error) {
						var errorMsg = error || 'Unknown network error';
						if (isTransientError(errorMsg) || xhr.status === 429 || xhr.status === 502 || xhr.status === 503 || xhr.status === 504) {
							var retries = retryCounts[currentPost.ID] || 0;
							if (retries < 3) {
								retryCounts[currentPost.ID] = retries + 1;
								var delayTime = (xhr.status === 429) ? 20000 : 15000;
								appendLog('Network error for "' + currentPost.post_title + '" (' + errorMsg + '). Retrying in ' + (delayTime / 1000) + ' seconds... (Attempt ' + (retries + 1) + '/3)', 'warn');
								setTimeout(processNextPost, delayTime);
							} else {
								delete retryCounts[currentPost.ID];
								failedCount++;
								appendLog('Network error for "' + currentPost.post_title + '" after 3 attempts: ' + errorMsg, 'error');
								currentIndex++;
								updateProgress();
								setTimeout(processNextPost, requestDelay);
							}
						} else {
							delete retryCounts[currentPost.ID];
							failedCount++;
							appendLog('Network error for "' + currentPost.post_title + '": ' + errorMsg, 'error');
							currentIndex++;
							updateProgress();
							setTimeout(processNextPost, requestDelay);
						}
					}
				});
			}

			$(document).ready(function() {
				// Check status of background process immediately on page load
				$.ajax({
					url:  ajaxUrl,
					type: 'POST',
					data: { action: 'ilj_ai_bulk_bg_status', nonce: nonce },
					success: function(response) {
						if (response.success && response.data.status === 'running') {
							execMode = 'bg';
							$('#ilj-bulk-exec-mode').val('bg');
							pollBgStatus();
							pollingTimer = setInterval(pollBgStatus, 3000);
						} else if (response.success && response.data.status === 'paused') {
							execMode = 'bg';
							$('#ilj-bulk-exec-mode').val('bg');
							pollBgStatus();
						}
					}
				});

				$('#ilj-start-bulk-ai').on('click', function(e) {
					e.preventDefault();
					var buttonText = $(this).text().trim();
					var isResuming = (buttonText === 'Resume Background Generation' || buttonText === 'Resume Background Generation (BG)');

					var postTypes = $('#ilj-bulk-post-types').val();
					bulkMode      = $('#ilj-bulk-mode').val();
					requestDelay  = parseInt($('#ilj-bulk-delay').val(), 10) * 1000;
					execMode      = $('#ilj-bulk-exec-mode').val();

					if (!isResuming) {
						if (!postTypes || postTypes.length === 0) {
							alert('Please select at least one post type.');
							return;
						}
					}

					if (execMode === 'bg') {
						$('#ilj-start-bulk-ai').prop('disabled', true).text('Starting background process...');
						$('#ilj-bulk-log').empty();
						appendLog('Starting background bulk job...', 'info');
						$.ajax({
							url: ajaxUrl,
							type: 'POST',
							data: {
								action: 'ilj_ai_bulk_bg_start',
								post_types: postTypes,
								mode: bulkMode,
								delay: parseInt($('#ilj-bulk-delay').val(), 10),
								nonce: nonce
							},
							success: function(response) {
								if (response.success) {
									$('#ilj-bulk-progress-area').slideDown();
									$('#ilj-stop-bulk-ai').prop('disabled', false).text('Stop & Pause (BG)');
									$('#ilj-start-bulk-ai').text('Running in Background...');
									if (response.data.resumed) {
										appendLog('Background job resumed successfully.', 'info');
									} else {
										appendLog('Background job successfully enqueued. Total queue: ' + response.data.total + ' posts.', 'info');
									}
									if (pollingTimer) clearInterval(pollingTimer);
									pollBgStatus();
									pollingTimer = setInterval(pollBgStatus, 3000);
								} else {
									alert('Error starting background process: ' + (response.data || 'unknown error'));
									$('#ilj-start-bulk-ai').prop('disabled', false).text('Analyze & Start Bulk Generation');
								}
							},
							error: function(xhr, status, error) {
								alert('Network error: ' + error);
								$('#ilj-start-bulk-ai').prop('disabled', false).text('Analyze & Start Bulk Generation');
							}
						});
						return;
					}

					if (isStopped && postsToProcess.length > 0 && currentIndex < postsToProcess.length) {
						isStopped = false;
						$('#ilj-start-bulk-ai').prop('disabled', true).text('Processing...');
						$('#ilj-stop-bulk-ai').prop('disabled', false);
						appendLog('Resuming bulk generation...', 'info');
						processNextPost();
						return;
					}
					$('#ilj-start-bulk-ai').prop('disabled', true).text('Analyzing database...');
					$('#ilj-bulk-log').empty();
					appendLog('Scanning database for matching posts...', 'info');
					$.ajax({
						url:  ajaxUrl,
						type: 'POST',
						data: { action: 'ilj_ai_bulk_get_posts', post_types: postTypes, mode: bulkMode, nonce: nonce },
						success: function(response) {
							if (response.success) {
								postsToProcess = response.data.posts;
								currentIndex   = 0;
								successCount   = 0;
								failedCount    = 0;
								isStopped      = false;
								$('#ilj-bulk-total-count').text(postsToProcess.length);
								updateProgress();
								if (postsToProcess.length === 0) {
									appendLog('No matching posts found to process.', 'warn');
									$('#ilj-start-bulk-ai').prop('disabled', false).text('Analyze & Start Bulk Generation');
									return;
								}
								$('#ilj-bulk-progress-area').slideDown();
								$('#ilj-stop-bulk-ai').prop('disabled', false);
								$('#ilj-start-bulk-ai').text('Processing...');
								appendLog('Found ' + postsToProcess.length + ' posts. Starting...', 'info');
								processNextPost();
							} else {
								alert('Error: ' + (response.data || 'Failed to fetch posts.'));
								$('#ilj-start-bulk-ai').prop('disabled', false).text('Analyze & Start Bulk Generation');
							}
						},
						error: function(xhr, status, error) {
							alert('Network error: ' + error);
							$('#ilj-start-bulk-ai').prop('disabled', false).text('Analyze & Start Bulk Generation');
						}
					});
				});

				$('#ilj-stop-bulk-ai').on('click', function(e) {
					e.preventDefault();
					if (execMode === 'bg') {
						$('#ilj-stop-bulk-ai').prop('disabled', true).text('Stopping...');
						$.ajax({
							url: ajaxUrl,
							type: 'POST',
							data: { action: 'ilj_ai_bulk_bg_stop', nonce: nonce },
							success: function(response) {
								if (response.success) {
									appendLog('Stopping background bulk job...', 'warn');
									pollBgStatus();
								} else {
									alert('Error stopping background process.');
									$('#ilj-stop-bulk-ai').prop('disabled', false);
								}
							}
						});
						return;
					}

					isStopped = true;
					appendLog('Stopping after current post...', 'warn');
					$('#ilj-stop-bulk-ai').prop('disabled', true).text('Stopping...');
				});

				$('#ilj-cancel-bulk-ai').on('click', function(e) {
					e.preventDefault();
					if (!confirm('Are you sure you want to cancel the current background job and clear the queue? This will abort processing the remaining posts.')) {
						return;
					}
					$('#ilj-cancel-bulk-ai').prop('disabled', true).text('Canceling...');
					$.ajax({
						url: ajaxUrl,
						type: 'POST',
						data: { action: 'ilj_ai_bulk_bg_clear', nonce: nonce },
						success: function(response) {
							if (response.success) {
								if (pollingTimer) {
									clearInterval(pollingTimer);
									pollingTimer = null;
								}
								isStopped = false;
								$('#ilj-bulk-progress-area').slideUp();
								$('#ilj-cancel-bulk-ai').hide().prop('disabled', false).text('Cancel & Reset Queue');
								$('#ilj-start-bulk-ai').prop('disabled', false).text('Analyze & Start Bulk Generation');
								$('#ilj-stop-bulk-ai').prop('disabled', true).text('Stop & Pause');
								
								// Unlock fields
								$('#ilj-bulk-post-types, #ilj-bulk-mode, #ilj-bulk-delay, #ilj-bulk-exec-mode').prop('disabled', false);
								appendLog('Background job canceled and queue cleared.', 'info');
							} else {
								alert('Error canceling process: ' + (response.data || 'unknown error'));
								$('#ilj-cancel-bulk-ai').prop('disabled', false).text('Cancel & Reset Queue');
							}
						},
						error: function(xhr, status, error) {
							alert('Network error: ' + error);
							$('#ilj-cancel-bulk-ai').prop('disabled', false).text('Cancel & Reset Queue');
						}
					});
				});
			});

			// --- Report: load processed posts ---
			function loadReport() {
				var $tbody = $('#ilj-bulk-report-tbody');
				var $wrap  = $('#ilj-bulk-report-wrap');
				$tbody.html('<tr><td colspan="5" style="text-align:center;padding:20px;color:#3399ff;">Loading...</td></tr>');
				$wrap.slideDown();
				$.ajax({
					url: ajaxUrl, type: 'POST',
					data: { action: 'ilj_ai_bulk_report', nonce: nonce },
					success: function(res) {
						if (!res.success) { $tbody.html('<tr><td colspan="5">Error loading report.</td></tr>'); return; }
						var rows = res.data.posts;
						if (!rows || rows.length === 0) {
							$tbody.html('<tr><td colspan="5" style="text-align:center;color:#646970;">No posts processed yet.</td></tr>');
							return;
						}
						$('#ilj-bulk-report-count').text(rows.length);
						var html = '';
						$.each(rows, function(i, p) {
							html += '<tr>' +
								'<td><a href="' + p.edit_url + '" target="_blank">' + $('<span>').text(p.post_title).html() + '</a></td>' +
								'<td>' + $('<span>').text(p.post_type).html() + '</td>' +
								'<td style="color:#00aa55;">' + $('<span>').text(p.processed_at).html() + '</td>' +
								'<td style="word-break:break-word;max-width:300px;">' + $('<span>').text(p.keywords).html() + '</td>' +
								'<td><button class="button button-small ilj-reset-post-ai" data-post-id="' + p.ID + '" style="color:#d63638;border-color:#d63638;">Reset</button></td>' +
							'</tr>';
						});
						$tbody.html(html);
					},
					error: function() { $tbody.html('<tr><td colspan="5">Network error.</td></tr>'); }
				});
			}

			$(document).ready(function() {
				$('#ilj-view-report-btn').on('click', function(e) {
					e.preventDefault();
					var $wrap = $('#ilj-bulk-report-wrap');
					if ($wrap.is(':visible')) { $wrap.slideUp(); return; }
					loadReport();
				});

				$(document).on('click', '.ilj-reset-post-ai', function() {
					var btn    = $(this);
					var postId = btn.data('post-id');
					if (!confirm('Remove AI-processed flag from this post? It will be re-processed in the next AI Bulk run.')) return;
					btn.prop('disabled', true).text('...');
					$.ajax({
						url: ajaxUrl, type: 'POST',
						data: { action: 'ilj_ai_bulk_reset_post', post_id: postId, nonce: nonce },
						success: function(res) {
							if (res.success) { btn.closest('tr').fadeOut(400, function() { $(this).remove(); }); }
							else { alert('Error: ' + (res.data || 'Failed.')); btn.prop('disabled', false).text('Reset'); }
						}
					});
				});

				$('#ilj-reset-all-ai').on('click', function(e) {
					e.preventDefault();
					if (!confirm('Are you sure you want to remove the AI-processed flag from ALL posts? This resets the bulk process memory completely.')) return;
					var btn = $(this);
					btn.prop('disabled', true).text('Resetting...');
					$.ajax({
						url: ajaxUrl, type: 'POST',
						data: { action: 'ilj_ai_bulk_reset_all', nonce: nonce },
						success: function(res) {
							if (res.success) {
								alert('All AI-processed flags removed successfully.');
								loadReport();
							} else {
								alert('Error: ' + (res.data || 'Failed to reset.'));
							}
						},
						error: function() {
							alert('Network error.');
						},
						complete: function() {
							btn.prop('disabled', false).html('&#10006; Reset All History');
						}
					});
				});
			});
		})(jQuery);
		</script>
		<?php

		// ---- Report section below the main tool ----
		$processed_count = (int) (new \WP_Query(array(
			'post_type'      => 'any',
			'post_status'    => 'publish',
			'meta_key'       => '_ilj_ai_bulk_processed',
			'fields'         => 'ids',
			'posts_per_page' => -1,
			'no_found_rows'  => false,
		)))->found_posts;
		?>
		<div style="margin-top: 20px;">
			<button type="button" id="ilj-view-report-btn" class="button button-secondary" style="font-size:1em;">
				&#128202; <?php printf(__('View AI Bulk Report (%d posts processed)', 'internal-links'), $processed_count); ?>
			</button>
		</div>

		<div id="ilj-bulk-report-wrap" style="display:none; margin-top:16px; background:#fff; border:1px solid #ccd0d4; border-radius:6px; padding:20px;">
			<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px;">
				<h3 style="margin:0;">
					<?php _e('Posts Processed by AI Bulk', 'internal-links'); ?>
					<span style="font-size:0.8em;font-weight:normal;color:#646970;" id="ilj-bulk-report-count"></span>
				</h3>
				<button type="button" id="ilj-reset-all-ai" class="button" style="color:#d63638; border-color:#d63638; background:#fff;">
					&#10006; <?php _e('Reset All History', 'internal-links'); ?>
				</button>
			</div>
			<div style="overflow-x:auto;">
				<table class="wp-list-table widefat striped" style="border-collapse:collapse;">
					<thead>
						<tr>
							<th style="padding:8px 12px;"><?php _e('Post Title', 'internal-links'); ?></th>
							<th style="padding:8px 12px;"><?php _e('Kiểu', 'internal-links'); ?></th>
							<th style="padding:8px 12px;"><?php _e('Processed At', 'internal-links'); ?></th>
							<th style="padding:8px 12px;"><?php _e('Từ khóa', 'internal-links'); ?></th>
							<th style="padding:8px 12px;"><?php _e('Hoạt động', 'internal-links'); ?></th>
						</tr>
					</thead>
					<tbody id="ilj-bulk-report-tbody">
						<tr><td colspan="5" style="text-align:center;color:#646970;padding:16px;"><?php _e('Click the button above to load the report.', 'internal-links'); ?></td></tr>
					</tbody>
				</table>
			</div>
		</div>

		<?php
		echo '</div>';
	}

	protected function getBulkGeneratorForm($available_post_types) {
		ob_start();
		?>
		<div class="ilj-ai-bulk-container" style="padding: 10px 0;">
			<p style="font-size: 1.1em; line-height: 1.6; margin-bottom: 20px;">
				<?php _e('Use this tool to automatically generate and assign SEO keywords for multiple posts at once using your configured AI model.', 'internal-links'); ?>
			</p>

			<div class="ilj-ai-bulk-form" style="background: #fafafa; border: 1px solid #e5e5e5; padding: 20px; border-radius: 6px; margin-bottom: 20px;">
				<div style="margin-bottom: 20px;">
					<label style="display: block; font-weight: bold; margin-bottom: 8px;" for="ilj-bulk-post-types">
						<?php _e('Select Post Types to Process', 'internal-links'); ?>
					</label>
					<?php if (empty($available_post_types)) : ?>
						<p style="color: #d63638; font-style: italic;">
							<?php _e('No whitelisted post types found. Please configure them in Settings -> Content -> Whitelisted Post Types first.', 'internal-links'); ?>
						</p>
					<?php else : ?>
						<select id="ilj-bulk-post-types" multiple="multiple" style="width: 100%; max-width: 400px;" class="ilj-select2">
							<?php foreach ($available_post_types as $name => $label) : ?>
								<option value="<?php echo esc_attr($name); ?>" selected><?php echo esc_html($label); ?></option>
							<?php endforeach; ?>
						</select>
					<?php endif; ?>
				</div>

				<div style="margin-bottom: 20px;">
					<label style="display: block; font-weight: bold; margin-bottom: 8px;" for="ilj-bulk-mode">
						<?php _e('Generation Mode', 'internal-links'); ?>
					</label>
					<select id="ilj-bulk-mode" style="width: 100%; max-width: 400px; height: 35px; border-radius: 4px; border: 1px solid #ccd0d4;">
						<option value="no_keywords" selected><?php _e('Only generate for posts without keywords (Recommended)', 'internal-links'); ?></option>
						<option value="skip_processed"><?php _e('Skip posts already processed by AI Bulk (from previous runs)', 'internal-links'); ?></option>
						<option value="all"><?php _e('Generate for all posts (Overwrite existing keywords)', 'internal-links'); ?></option>
					</select>
				</div>

				<div style="margin-bottom: 20px;">
					<label style="display: block; font-weight: bold; margin-bottom: 8px;" for="ilj-bulk-delay">
						<?php _e('Request Delay (seconds)', 'internal-links'); ?>
					</label>
					<select id="ilj-bulk-delay" style="width: 100%; max-width: 400px; height: 35px; border-radius: 4px; border: 1px solid #ccd0d4;">
						<option value="1">1 <?php _e('second', 'internal-links'); ?></option>
						<option value="3">3 <?php _e('seconds', 'internal-links'); ?></option>
						<option value="5">5 <?php _e('seconds', 'internal-links'); ?></option>
						<option value="7" selected>7 <?php _e('seconds (Recommended for Free Tier RPM limits)', 'internal-links'); ?></option>
						<option value="10">10 <?php _e('seconds', 'internal-links'); ?></option>
						<option value="15">15 <?php _e('seconds', 'internal-links'); ?></option>
					</select>
					<p style="margin: 4px 0 0; color: #646970; font-size: 0.9em; font-style: italic;">
						<?php _e('Google Gemini Free Tier limit is 15 requests per minute (RPM). Using a delay of 7 seconds ensures highly stable operation.', 'internal-links'); ?>
					</p>
				</div>

				<div style="margin-bottom: 20px;">
					<label style="display: block; font-weight: bold; margin-bottom: 8px;" for="ilj-bulk-exec-mode">
						<?php _e('Execution Method', 'internal-links'); ?>
					</label>
					<select id="ilj-bulk-exec-mode" style="width: 100%; max-width: 400px; height: 35px; border-radius: 4px; border: 1px solid #ccd0d4;">
						<option value="tab" selected><?php _e('Run in Browser Tab (Keep tab open - recommended for debugging)', 'internal-links'); ?></option>
						<option value="bg"><?php _e('Run in Background Server (Safe to close tab / turn off PC)', 'internal-links'); ?></option>
					</select>
				</div>

				<button type="button" id="ilj-start-bulk-ai" class="button button-primary button-large" <?php echo empty($available_post_types) ? 'disabled' : ''; ?> style="background: #2271b1; border-color: #2271b1; height: 40px; font-size: 1.1em;">
					<?php _e('Analyze & Start Bulk Generation', 'internal-links'); ?>
				</button>
			</div>

			<!-- Progress & Results Area (Hidden initially) -->
			<div id="ilj-bulk-progress-area" style="display: none; background: #fff; border: 1px solid #ccd0d4; padding: 25px; border-radius: 6px; box-shadow: 0 1px 1px rgba(0,0,0,.04);">
				<h3 style="margin-top: 0; display: flex; justify-content: space-between; align-items: center;">
					<span><?php _e('Bulk AI Processing...', 'internal-links'); ?></span>
					<span id="ilj-bulk-percentage" style="font-size: 0.9em; font-weight: normal; color: #646970;">0%</span>
				</h3>

				<!-- Progress bar -->
				<div style="background: #f0f0f1; border-radius: 10px; height: 20px; overflow: hidden; margin-bottom: 20px; position: relative;">
					<div id="ilj-bulk-progress-bar" style="width: 0%; height: 100%; background: linear-gradient(90deg, #3858e9 0%, #2271b1 100%); transition: width 0.3s ease;"></div>
				</div>

				<div style="display: flex; gap: 40px; margin-bottom: 20px; font-size: 1.1em;">
					<div><strong><?php _e('Processed:', 'internal-links'); ?></strong> <span id="ilj-bulk-processed-count">0</span> / <span id="ilj-bulk-total-count">0</span></div>
					<div><strong><?php _e('Success:', 'internal-links'); ?></strong> <span id="ilj-bulk-success-count" style="color: #46b450;">0</span></div>
					<div><strong><?php _e('Failed:', 'internal-links'); ?></strong> <span id="ilj-bulk-failed-count" style="color: #dc3232;">0</span></div>
				</div>

				<div id="ilj-bulk-current-post-info" style="font-style: italic; color: #646970; margin-bottom: 20px; word-break: break-all;">
					<?php _e('Starting process...', 'internal-links'); ?>
				</div>

				<div style="display: flex; gap: 10px; align-items: center;">
					<button type="button" id="ilj-stop-bulk-ai" class="button button-secondary" style="height: 35px; border-color: #d63638; color: #d63638;">
						<?php _e('Stop & Pause', 'internal-links'); ?>
					</button>
					<button type="button" id="ilj-cancel-bulk-ai" class="button" style="height: 35px; border-color: #d63638; background: #fff; color: #d63638; display: none;">
						<?php _e('Cancel & Reset Queue', 'internal-links'); ?>
					</button>
				</div>

				<!-- Console output log -->
				<div style="margin-top: 25px;">
					<label style="display: block; font-weight: bold; margin-bottom: 8px;"><?php _e('Activity Log', 'internal-links'); ?></label>
					<div id="ilj-bulk-log" style="height: 200px; overflow-y: scroll; background: #222; color: #00ff00; font-family: monospace; padding: 15px; border-radius: 4px; font-size: 0.9em; line-height: 1.5;"></div>
				</div>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}
}
