<?php
namespace ILJ\Backend\MenuPage\Includes;

use ILJ\Backend\User;
use ILJ\Backend\AdminMenu;
use ILJ\Backend\Menupage\Settings;
use ILJ\Core\Options\CustomFieldsToLinkPost;

/**
 * Backend Sidebar
 *
 * Responsible for displaying the sidebar
 *
 * @package ILJ\Backend\Menupage
 * @since   1.0.1
 */
trait SidebarTrait {

	/**
	 * Renders the sidebar
	 *
	 * @since  1.0.1
	 * @return void
	 */
	protected function renderSidebar() {
		$screen = get_current_screen();
		if (\ILJ\ilj_fs()->is_free_plan() && !User::get('hide_promo') && 'toplevel_page_internal_link_juicer' == $screen->id) {
			$this->renderPromo();
		}
		?>
		<div class="postbox ilj-postbox info">
			<h3 class="title"><?php esc_html_e('Hỗ trợ chúng tôi', 'internal-links'); ?></h3>
			<div class="inside">
				<p>
					<?php
						echo wp_kses(__('Bạn có thích plugin này không?', 'internal-links'), array('strong' => array()));
						echo ' ' . wp_kses(__('<strong>Vui lòng đánh giá chúng tôi</strong> hoặc <strong>nói với bạn bè của bạn</strong> về Internal Link Juicer.', 'internal-links'), array('strong' => array()));
					?>
				</p>
				<p>
					<a href="https://wordpress.org/support/plugin/internal-links/reviews/" class="button button-primary"
					   target="_blank" rel="noopener">&raquo;
						<?php esc_html_e('Hãy cho chúng tôi đánh giá của bạn', 'internal-links'); ?>
					</a>
				</p>
				<p class="divide">
					<?php
						echo wp_kses(__('Bạn đang tìm kiếm một <strong>tính năng mới</strong> hoặc có <strong>đề xuất cải tiến</strong>?', 'internal-links'), array('strong' => array()));
						echo ' ' . wp_kses(__('Bạn có <strong>tìm thấy lỗi</strong> không?', 'internal-links'), array('strong' => array()));
						echo ' ' . wp_kses(__('Xin vui lòng cho chúng tôi biết về nó.', 'internal-links'), array('strong' => array()));
					?>
				</p>
				<p>
					<a href="<?php echo esc_url(get_admin_url(null, 'admin.php?page=' . AdminMenu::ILJ_MENUPAGE_SLUG . '-contact')); ?>"
					   class="button">&raquo;
						<?php esc_html_e('Hãy liên lạc với chúng tôi', 'internal-links'); ?>
					</a>
				</p>
				<p class="divide">
					<strong><?php esc_html_e('Cảm ơn bạn đã sử dụng Máy ép trái cây liên kết nội bộ', 'internal-links'); ?></strong>
				</p>
				<p class="character">
					<img src="<?php echo esc_url(ILJ_URL . '/admin/img/character.png'); ?>" alt="The Internal Link Juicer"/>
				</p>
			</div>
		</div>
		<?php
	}

	/**
	 * Renders informational promotion for pro version of ILJ
	 *
	 * @since  1.1.1
	 * @return void
	 */
	protected function renderPromo() {
		$kses = array('strong' => array());
		?>
		<div class="postbox ilj-postbox promo">
			<button type="button" class="handlediv" aria-expanded="true">
				<span class="close"
					  title="<?php esc_attr_e('Ẩn thông tin này mãi mãi', 'internal-links'); ?>"
					  aria-hidden="true"></span></button>
			<h3 class="title"><?php esc_html_e('Kích hoạt phiên bản chuyên nghiệp', 'internal-links'); ?></h3>
			<div class="inside">
				<h4><?php esc_html_e('Đạt được nhiều hơn nữa với Internal Link Juicer Pro:', 'internal-links'); ?></h4>
				<ul>
					<li>
						<span><?php esc_html_e('Liên kết riêng lẻ', 'internal-links'); ?></span>: <?php echo wp_kses(__('Liên kết linh hoạt hơn với <strong>URL riêng lẻ</strong> của riêng bạn làm mục tiêu liên kết.', 'internal-links'), $kses); ?>
					</li>
					<li>
						<span><?php esc_html_e('Kiểm soát tối đa', 'internal-links'); ?></span>: <?php echo wp_kses(__('<strong>Mã ngắn</strong> và <strong>cài đặt</strong> để <strong>loại trừ</strong> các khu vực nội dung cụ thể <strong>khỏi quá trình tạo liên kết</strong>.', 'internal-links'), $kses); ?>
					</li>
					<li>
						<span><?php esc_html_e('Tối ưu hóa tập trung', 'internal-links'); ?></span>: <?php echo wp_kses(__('Tối đa hóa kết quả của bạn với <strong>Trang tổng quan thống kê</strong> toàn diện.', 'internal-links'), $kses); ?>
					</li>
					<li>
						<span><?php esc_html_e('Kích hoạt phân loại', 'internal-links'); ?></span>: <?php echo wp_kses(__('Khả năng không giới hạn bằng cách liên kết thậm chí từ và đến <strong>danh mục và thẻ</strong>.', 'internal-links'), $kses); ?>
					</li>

					<?php
					/**
					 * Adds Additional Pro Features
					 *
					 * @since 2.1.0
					 */
					do_action(CustomFieldsToLinkPost::ILJ_ACTION_ADD_PRO_FEATURES);
					?>
					<li>
						<span><?php esc_html_e('Thông báo từ khóa trùng lặp', 'internal-links'); ?></span>: <?php echo wp_kses(__('Nhận thông báo khi cùng một từ khóa được sử dụng nhiều lần để liên kết, giúp bạn duy trì chiến lược liên kết nội bộ cân bằng và hiệu quả.', 'internal-links'), $kses); ?>
					</li>
				</ul>
				<p>
					<a href="<?php echo esc_url(get_admin_url(null, 'admin.php?page=' . AdminMenu::ILJ_MENUPAGE_SLUG . '-pricing')); ?>"
					   class="button button-primary">&raquo; <?php esc_html_e('Nâng cấp ngay bây giờ', 'internal-links'); ?></a>
				</p>
			</div>
		</div>
		<?php
	}
}
