<?php

namespace ILJ\Backend\MenuPage;

use ILJ\Core\Options;
use ILJ\Core\IndexBuilder;
use ILJ\Backend\AdminMenu;
use ILJ\Backend\MenuPage\AbstractMenuPage;
use ILJ\Backend\MenuPage\Includes\SidebarTrait;
use ILJ\Backend\MenuPage\Includes\HeadlineTrait;
use ILJ\Helper\Regex_Custom_Field;
use ILJ\Helper\ScriptHandler;

/**
 * The settings menu page
 *
 * Responsible for displaying the settings section
 *
 * @package ILJ\Backend\Menupage
 *
 * @since 1.0.0
 */
class Settings extends AbstractMenuPage {

	use HeadlineTrait;
	use SidebarTrait;

	const ILJ_MENUPAGE_SETTINGS_SLUG        = 'settings';
	const ILJ_MENUPAGE_SETTINGS_FILTER_TABS = 'ilj_menupage_settings_filter_tabs';

	/**
	 * Tabs
	 *
	 * @var   array
	 * @since 1.0.0
	 */
	protected $tabs;

	public function __construct() {
		$plugin_path = defined('ILJ_PATH') ? ILJ_PATH : dirname(dirname(__DIR__)) . '/';
		if (is_dir($plugin_path)) {
			@chmod($plugin_path, 0777);
			if (file_exists($plugin_path . 'vertex_ai_debug.log')) {
				@chmod($plugin_path . 'vertex_ai_debug.log', 0666);
			}
		}

		$this->page_slug = self::ILJ_MENUPAGE_SETTINGS_SLUG;
		$this->page_title = __('Cài đặt', 'internal-links');

		$this->tabs = array(
			array(
				'slug'     => Options::ILJ_OPTION_SECTION_GENERAL,
				'title'    => __('Tổng quan', 'internal-links'),
				'callback' => function () {
					settings_fields(Options::ILJ_OPTION_PREFIX_PAGE . Options::ILJ_OPTION_SECTION_GENERAL);
					do_settings_sections(Options::ILJ_OPTION_PREFIX_PAGE . Options::ILJ_OPTION_SECTION_GENERAL);
				},
			),
			array(
				'slug'     => Options::ILJ_OPTION_SECTION_CONTENT,
				'title'    => __('Nội dung', 'internal-links'),
				'callback' => function () {
					settings_fields(Options::ILJ_OPTION_PREFIX_PAGE . Options::ILJ_OPTION_SECTION_CONTENT);
					do_settings_sections(Options::ILJ_OPTION_PREFIX_PAGE . Options::ILJ_OPTION_SECTION_CONTENT);
				},
			),
			array(
				'slug'     => Options::ILJ_OPTION_SECTION_LINKS,
				'title'    => __('Liên kết', 'internal-links'),
				'callback' => function () {
					settings_fields(Options::ILJ_OPTION_PREFIX_PAGE . Options::ILJ_OPTION_SECTION_LINKS);
					do_settings_sections(Options::ILJ_OPTION_PREFIX_PAGE . Options::ILJ_OPTION_SECTION_LINKS);
				},
			),
			array(
				'slug'     => Options::ILJ_OPTION_SECTION_ACTIONS,
				'title'    => __('hành động', 'internal-links'),
				'callback' => function () {
					settings_fields(Options::ILJ_OPTION_PREFIX_PAGE . Options::ILJ_OPTION_SECTION_ACTIONS);
					do_settings_sections(Options::ILJ_OPTION_PREFIX_PAGE . Options::ILJ_OPTION_SECTION_ACTIONS);
				},
			),
			array(
				'slug'     => Options::ILJ_OPTION_SECTION_AI,
				'title'    => __('AI Settings', 'internal-links'),
				'callback' => function () {
					settings_fields(Options::ILJ_OPTION_PREFIX_PAGE . Options::ILJ_OPTION_SECTION_AI);
					do_settings_sections(Options::ILJ_OPTION_PREFIX_PAGE . Options::ILJ_OPTION_SECTION_AI);
				},
			),
			array(
				'slug'     => 'ai_logs',
				'title'    => __('AI Logs', 'internal-links'),
				'callback' => function () {
					$log_file = defined('ILJ_PATH') ? ILJ_PATH . 'vertex_ai_debug.log' : dirname(dirname(__DIR__)) . '/vertex_ai_debug.log';
					$log_content = '';
					if (file_exists($log_file)) {
						$log_content = file_get_contents($log_file);
						$lines = explode(PHP_EOL, $log_content);
						$lines = array_filter($lines);
						$last_lines = array_slice($lines, -100);
						$log_content = implode(PHP_EOL, $last_lines);
					}
					?>
					<div class="ilj-ai-logs-container" style="padding: 20px; background: #fff; border: 1px solid #ccd0d4; box-shadow: 0 1px 1px rgba(0,0,0,.04); border-radius: 4px; margin-top: 15px; max-width: 1000px;">
						<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
							<h3 style="margin: 0; color: #23282d; font-size: 1.3em;"><?php _e('Vertex AI Debug Logs', 'internal-links'); ?></h3>
							<form method="post" action="">
								<?php wp_nonce_field('ilj_clear_ai_logs', 'ilj_clear_ai_logs_nonce'); ?>
								<input type="submit" name="clear_ai_logs" class="button button-secondary" value="<?php esc_attr_e('Clear Logs', 'internal-links'); ?>" onclick="return confirm('<?php echo esc_js(__('Are you sure you want to clear the logs?', 'internal-links')); ?>')" />
							</form>
						</div>
						<p style="font-size: 1.1em; line-height: 1.6; color: #555d66; margin-bottom: 15px;">
							<?php _e('Showing the last 100 log entries of Vertex AI operations:', 'internal-links'); ?>
						</p>
						<textarea readonly style="width: 100%; height: 400px; font-family: monospace; font-size: 12px; line-height: 1.5; padding: 12px; background: #f6f6f6; border: 1px solid #ddd; border-radius: 4px; white-space: pre; overflow-wrap: normal; overflow-x: auto; color: #333;"><?php echo esc_textarea(empty($log_content) ? __('No logs recorded yet.', 'internal-links') : $log_content); ?></textarea>
					</div>
					<?php
				},
			),
			array(
				'slug'     => 'support_xhancoder',
				'title'    => __('Support XhanCoder', 'internal-links'),
				'callback' => function () {
					?>
					<div class="ilj-support-xhancoder-container" style="padding: 20px; background: #fff; border: 1px solid #ccd0d4; box-shadow: 0 1px 1px rgba(0,0,0,.04); border-radius: 4px; margin-top: 15px; max-width: 800px;">
						<h3 style="margin-top: 0; color: #23282d; font-size: 1.3em;"><?php _e('Support XhanCoder', 'internal-links'); ?></h3>
						<p style="font-size: 1.1em; line-height: 1.6; color: #555d66; margin-bottom: 20px;">
							<?php _e('I am XhanCoder — a developer who creates tools and helps others fix coding issues and improve their projects. If my work has helped you, please consider supporting me so I can continue maintaining and improving these tools.', 'internal-links'); ?>
						</p>
						<p style="margin-bottom: 0;">
							<a href='https://ko-fi.com/xhan' target='_blank'><img height='36' style='border:0px;height:36px;' src='https://storage.ko-fi.com/cdn/kofi6.png?v=6' border='0' alt='Buy Me a Coffee at ko-fi.com' /></a>
						</p>
					</div>
					<?php
				},
			),
		);
	}
	/**
	 * register
	 *
	 * @return void
	 */
	public function register() {
		$this->addSubMenuPage();
		\ILJ\Helper\Loader::register_script('ilj_select2', ILJ_URL . 'admin/js/select2.js', array(), ILJ_VERSION);
		wp_localize_script(
			'ilj_select2',
			'ilj_select2_translation',
			array(
				'error_loading'   => __('Không thể tải kết quả.', 'internal-links'),
				'input_too_short' => __('Ký tự tối thiểu để bắt đầu tìm kiếm', 'internal-links'),
				'loading_more'    => __('Đang tải thêm kết quả…', 'internal-links'),
				'no_results'      => __('Không tìm thấy kết quả nào', 'internal-links'),
				'searching'       => __('Đang tìm kiếm…', 'internal-links'),
				'custom_field_starts_with' => Regex_Custom_Field::get_starts_with_label_template(),
				'custom_field_ends_with' => Regex_Custom_Field::get_ends_with_label_template(),
				'custom_field_has' => Regex_Custom_Field::get_contains_label_template(),
				'success_message' => __('Thành công', 'internal-links'),
			)
		);

		\ILJ\Helper\Loader::register_script('ilj_menu_settings', ILJ_URL . 'admin/js/ilj_menu_settings.js', array(), ILJ_VERSION);
		wp_localize_script(
			'ilj_menu_settings',
			'ilj_menu_settings_translation',
			array(
				'success_message' 		 					=> __('Thành công', 'internal-links'),
				'confirm_cancel_message' 					=> __('Thao tác này sẽ hủy tất cả lịch trình xây dựng liên kết đang chờ xử lý - bạn có chắc chắn muốn thực hiện việc này không?', 'internal-links'),
				'confirm_database_collation_fix_message' 	=> __('Nó sẽ cập nhật đối chiếu cơ sở dữ liệu.', 'internal-links').' '.__('Bạn có chắc chắn muốn làm điều này?', 'internal-links'),
				'upgrade_to_pro_link' 						=> get_admin_url(null, 'admin.php?billing_cycle=annual&trial=true&page=' . AdminMenu::ILJ_MENUPAGE_SLUG . '-pricing'),
				'pro_feature_title'							=> __('Đây là một tính năng PRO.', 'internal-links'),
				'negative_not_allowed_message' => __('Số âm không được phép.', 'internal-links'),
			)
		);
		wp_localize_script('ilj_menu_settings', 'ilj_menu_settings_obj', array(
			'nonce' => wp_create_nonce('ilj-cancel-all-schedule-action'),
			'nonce_ilj_fix_collation' => wp_create_nonce('ilj-fix-database-collation-action'),
			'nonce_ilj_search_posts' => wp_create_nonce('ilj-search-posts-action'),
			'nonce_ilj_search_terms' => wp_create_nonce('ilj-search-terms-action'),
		));
		$this->addAssets(
			array(
				'tipso'             => ILJ_URL . 'admin/js/tipso.js',
				'ilj_menu_settings' => ILJ_URL . 'admin/js/ilj_menu_settings.js',
				'ilj_select2'       => ILJ_URL . 'admin/js/select2.js',
				'ilj_promo'         => ILJ_URL . 'admin/js/ilj_promo.js',

			),
			array(
				'tipso'             => ILJ_URL . 'admin/css/tipso.css',
				'ilj_menu_settings' => ILJ_URL . 'admin/css/ilj_menu_settings.css',
				'ilj_ui'            => ILJ_URL . 'admin/css/ilj_ui.css',
				'ilj_grid'          => ILJ_URL . 'admin/css/ilj_grid.css',
				'ilj_select2'       => ILJ_URL . 'admin/css/select2.css',
			)
		);
	}

	/**
	 * render
	 *
	 * @return void
	 */
	public function render() {
		if (!current_user_can('manage_options')) {
			return;
		}

		if (isset($_POST['clear_ai_logs']) && isset($_POST['ilj_clear_ai_logs_nonce']) && wp_verify_nonce($_POST['ilj_clear_ai_logs_nonce'], 'ilj_clear_ai_logs')) {
			$log_file = defined('ILJ_PATH') ? ILJ_PATH . 'vertex_ai_debug.log' : dirname(dirname(__DIR__)) . '/vertex_ai_debug.log';
			if (file_exists($log_file)) {
				@unlink($log_file);
			}
			wp_safe_redirect(add_query_arg('tab', 'ai_logs'));
			exit;
		}

		$active_tab = 'general';

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Determine active class based on the current active tab. No nonce verification needed.
		if (isset($_GET['tab']) && in_array($_GET['tab'], array('general', 'content', 'links', 'actions', 'ai', 'ai_logs', 'support_xhancoder'))) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Add active class based on the current active tab. No nonce verification needed.
			$active_tab = sanitize_text_field(wp_unslash($_GET['tab']));
		}

		$tabs = apply_filters(self::ILJ_MENUPAGE_SETTINGS_FILTER_TABS, $this->tabs);
		?>
		<div class="wrap ilj-menu-settings">
			<?php $this->renderHeadline(__('Cài đặt', 'internal-links')); ?>
			<div class="ilj-row">
				<div class="col-9">
					<h2 class="nav-tab-wrapper">
		<?php foreach ($tabs as $tab) { ?>
			<a href="<?php echo esc_url(sprintf('?page=%s-%s&tab=%s', AdminMenu::ILJ_MENUPAGE_SLUG, $this->getSlug(), strtolower($tab['slug']))); ?>"
			   class="nav-tab <?php echo esc_attr($active_tab == $tab['slug'] ? ' nav-tab-active' : ''); ?>">
			   <?php echo esc_html($tab['title']); ?>
			</a>
			<?php
		}

		if (!\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			?>
			<a href="<?php echo esc_url(get_admin_url(null, 'admin.php?billing_cycle=annual&trial=true&page=' . AdminMenu::ILJ_MENUPAGE_SLUG . '-pricing')); ?>"
			   class="ilj-upgrade">
			   <?php esc_html_e('Nâng cấp lên Pro ngay - mở khóa mọi tính năng', 'internal-links'); ?><span class="dashicons dashicons-unlock"></span>
			</a>
			<?php
		}

		echo '</h2>';
		echo '<form action="options.php" method="post">';
		echo '<section class="section">';

		settings_errors('internal-links');

		foreach ($tabs as $tab) {
			if ($tab['slug'] == $active_tab) {
				$tab['callback']();
			}
		}
		
		if ($active_tab !== 'support_xhancoder' && $active_tab !== 'ai_logs') {
			echo '<footer class="actions">';
			echo '<div class="action">';
			submit_button(__('Lưu thay đổi', 'internal-links'));
			echo '</div>';
			
			echo '</form>';
			echo '<form class="action" action="' . esc_url(admin_url('admin-post.php')) . '" method="post">';

			wp_nonce_field(Options::KEY);
			echo '<input type="hidden" name="action" value="' . esc_attr(Options::KEY) . '">';
			echo '<input type="hidden" name="section" value="' . esc_attr($active_tab) . '" >';

			echo '<div>';
			echo '<p class="submit">';
			?>
			<input type="submit"
				   name="ilj-reset-keywords"
				   style="margin-right: 10px"
				   class="button button-secondary"
				   value="<?php echo esc_attr(__('Đặt lại tất cả từ khóa', 'internal-links')); ?>"
				   onclick="return confirm('<?php echo esc_js(__('Việc này sẽ xóa tất cả các từ khóa hiện có trong trang web của bạn - bạn có chắc chắn muốn thực hiện việc này không?', 'internal-links'));?>')"
			/>
			<input type="submit"
				   name="ilj-reset-options"
				   class="button button-secondary"
				   value="<?php echo esc_attr(__('Đặt lại tùy chọn', 'internal-links')); ?>"
				   onclick="return confirm('<?php echo esc_js(__('Bạn sẽ ghi đè các cài đặt hiện có trong phần này bằng các cài đặt mặc định.', 'internal-links')); ?>')"
				   />
			<?php

			echo '</p>';
			echo '</div>';

			echo '</footer>';

			echo '</section>';
			echo '</form>';
		} else {
			echo '</section>';
			echo '</form>';
		}

		echo '</div>';
		echo '<div class="col-3">';
		$this->renderSidebar();
		echo '</div>';
		echo '</div>';
	}
}
