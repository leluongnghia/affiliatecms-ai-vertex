<?php
namespace ILJ\Backend\MenuPage;

use ILJ\Backend\AdminMenu;
use ILJ\Backend\Editor;
use ILJ\Backend\MenuPage\Keywords_Editor\Link_Repository;
use ILJ\Backend\MenuPage\Keywords_Editor\Post_Repository;
use ILJ\Backend\MenuPage\Keywords_Editor\Table;
use ILJ\Backend\MenuPage\Keywords_Editor\Context;
use ILJ\Backend\MenuPage\Keywords_Editor\Term_Repository;
use ILJ\Helper\Post;

/**
 * The Keywords editor menu page
 *
 * Responsible for displaying the settings section
 *
 * @package ILJ\Backend\Menupage
 *
 * @since 2.23.5
 */
final class Keywords_Editor extends AbstractMenuPage {
	public function __construct() {
		$this->page_slug = 'keywords-editor';
		$this->page_title = __('Trình chỉnh sửa từ khóa', 'internal-links');
	}


	public function register() {
		$this->addSubMenuPage();
	}

	/**
	 * {@inheritDoc}
	 */
	public function render() {
		$current_page_slug = sprintf('%s-%s', AdminMenu::ILJ_MENUPAGE_SLUG, $this->page_slug);
		wp_enqueue_style('ilj_select2', ILJ_URL . 'admin/css/select2.css', array(), ILJ_VERSION);
		wp_register_script('ilj_select2', ILJ_URL . 'admin/js/select2.js', array(), ILJ_VERSION);
		\ILJ\Helper\Loader::enqueue_style('ilj_keywords_editor', ILJ_URL . 'admin/css/ilj_keyword_editor.css', array(), ILJ_VERSION);
		wp_enqueue_script('ilj_keywords_editor',  ILJ_URL . 'admin/js/ilj-keywords-editor.js', array('wp-polyfill', 'ilj_select2'), ILJ_VERSION);
		wp_localize_script('ilj_keywords_editor', 'ilj_editor_translation', Editor::getTranslation());
		wp_localize_script('ilj_keywords_editor', 'ilj_editor_duplicate', array(
			'nonce' => wp_create_nonce('ilj-editor-action'),
		));
		\ILJ\Helper\Loader::register_script(Editor::ILJ_MODAL, ILJ_URL . 'admin/js/ilj_modal.js', array(), ILJ_VERSION);
		\ILJ\Helper\Loader::enqueue_script(Editor::ILJ_MODAL);
		?>
		<div class="wrap">
			<h1 class="wp-heading-inline">
				<?php esc_html_e('Trình chỉnh sửa từ khóa', 'internal-links'); ?>
			</h1>
			<style>
				.ilj-spinner {
					float: none;
				}
			</style>
			<hr class="wp-header-end">
			<form id="internal-link-juicer-keywords-editor-form" method="get">

				<?php
					$context = Context::from_request_params();
					$table = Table::from_context($context);
					$table->prepare_items();
					$table->views();
				?>
				<?php $table->search_box(__('Tìm kiếm', 'internal-links'), 'search_ilj_edit_keywords'); ?>
				<?php
					$table->display();
					// Below input is needed to retain the page when search is made, otherwise it will get redirected to admin.php where it wont be handled.
				?>
				<input type="hidden" name="page" value="<?php echo esc_attr($current_page_slug); ?>">
				<input type="hidden" name="current_view" value="<?php echo esc_attr($context->get_current_view()); ?>">
				<!-- When search query or filter is submitted, pagination should be reset -->
				<input type="hidden" name="paged" value="0" />
			</form>
		</div>
		<?php
	}
}