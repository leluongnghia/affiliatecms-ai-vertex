<?php
namespace ILJ\Backend;

use ILJ\Core\Options;
use ILJ\Core\Options\CacheToggleBtnSwitch;
use ILJ\Data\Content;
use ILJ\Database\Linkindex;
use ILJ\Helper\Help;
use ILJ\Type\KeywordList;
use ILJ\Database\Postmeta;
use ILJ\Database\Termmeta;
use ILJ\Helper\Capabilities;
use ILJ\Helper\IndexAsset as IndexAsset;
use ILJ\Helper\Statistic;

/**
 * Admin views
 *
 * Responsible for all view elements which are required on the backend
 *
 * @package ILJ\Backend
 *
 * @since 1.0.0
 */
class Editor {

	const ILJ_ADMINVIEW_NONCE                 = '_ilj_adminview_nonce';
	const ILJ_ACTION_AFTER_KEYWORDS_UPDATE    = 'ilj_after_keywords_update';
	const ILJ_EDITOR_HANDLE                   = 'ilj_editor';
	const ILJ_KEYWORDS_HANDLE                 = 'ilj_keywords';
	const ILJ_IS_BLACKLISTED                  = 'ilj_is_blacklisted';
	const ILJ_META_KEY_LIMITINCOMINGLINKS     = 'ilj_limitincominglinks';
	const ILJ_META_KEY_MAXINCOMINGLINKS       = 'ilj_maxincominglinks';
	const ILJ_META_KEY_BLACKLISTDEFINITION    = 'ilj_blacklistdefinition';
	const ILJ_META_KEY_LIMITLINKSPERPARAGRAPH = 'ilj_limitlinksperparagraph';
	const ILJ_META_KEY_LINKSPERPARAGRAPH      = 'ilj_linksperparagraph';
	const ILJ_META_KEY_LIMITOUTGOINGLINKS     = 'ilj_limitoutgoinglinks';
	const ILJ_META_KEY_MAXOUTGOINGLINKS       = 'ilj_maxoutgoinglinks';
	const ILJ_KEYWORD_METABOX_FOOTER_HOOK     = 'ilj_keyword_metabox_footer';
	const ILJ_MODAL = 'ilj_modal';

	/**
	 * Registers the keyword metabox on all public post types
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function addKeywordMetaBox() {
		foreach (get_post_types(array('public' => true)) as $type) {
			add_meta_box(
				Postmeta::ILJ_META_KEY_LINKDEFINITION,
				__('Liên kết nội bộ', 'internal-links'),
				array(__CLASS__, 'renderKeywordMetaBox'),
				$type,
				'side',
				'default'
			);
		}

		if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			add_meta_box(
				Postmeta::ILJ_META_KEY_LINKDEFINITION,
				__('Liên kết nội bộ', 'internal-links'),
				array(__CLASS__, 'renderKeywordMetaBox'),
				\ILJ\Posttypes\CustomLinks::ILJ_POSTTYPE_CUSTOM_LINKS_SLUG,
				'side',
				'default'
			);
		}
	}

	/**
	 * Renders the keyword metabox
	 *
	 * @since 1.0.0
	 *
	 * @param  \WP_Post $post The post object of the current page
	 * @return void
	 */
	public static function renderKeywordMetaBox(\WP_Post $post) {
		$keyword_list      = KeywordList::fromMeta($post->ID, 'post', Postmeta::ILJ_META_KEY_LINKDEFINITION);
		$blacklist_keywords = KeywordList::fromMeta($post->ID, 'post', self::ILJ_META_KEY_BLACKLISTDEFINITION);

		wp_nonce_field(basename(__FILE__), self::ILJ_ADMINVIEW_NONCE);
		?>
		<p>
		<label for="<?php echo esc_attr(Postmeta::ILJ_META_KEY_LINKDEFINITION . '_keys'); ?>"><?php esc_html_e('Các từ khóa', 'internal-links'); ?>:</label>
		<br />
		<input
				type="text"
				name="<?php echo esc_attr(Postmeta::ILJ_META_KEY_LINKDEFINITION . '_keys'); ?>"
				value="<?php echo esc_attr($keyword_list->encoded()); ?>" size="30"/>
		<?php
		if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			$limit_links                = get_post_meta($post->ID, self::ILJ_META_KEY_LIMITINCOMINGLINKS, true);
			$max_limit_links             = get_post_meta($post->ID, self::ILJ_META_KEY_MAXINCOMINGLINKS, true);
			$limit_links_per_paragraph = get_post_meta($post->ID, self::ILJ_META_KEY_LIMITLINKSPERPARAGRAPH, true);
			$links_per_paragraph       = get_post_meta($post->ID, self::ILJ_META_KEY_LINKSPERPARAGRAPH, true);
			$limit_outgoing_links      = get_post_meta($post->ID, self::ILJ_META_KEY_LIMITOUTGOINGLINKS, true);
			$max_outgoing_links        = get_post_meta($post->ID, self::ILJ_META_KEY_MAXOUTGOINGLINKS, true);
			?>
			<input type="text"
				   name="<?php echo esc_attr(self::ILJ_META_KEY_LIMITINCOMINGLINKS); ?>"
				   value="<?php echo esc_attr($limit_links); ?>"
				   style="display:none"/>
			<input type="text"
				   name="<?php echo esc_attr(self::ILJ_META_KEY_MAXINCOMINGLINKS); ?>"
				   value="<?php echo esc_attr($max_limit_links); ?>"
				   style="display:none"/>
			<input type="number"
				   name="<?php echo esc_attr(self::ILJ_META_KEY_LIMITLINKSPERPARAGRAPH); ?>"
				   value="<?php echo esc_attr($limit_links_per_paragraph); ?>"
				   style="display:none"/>
			<input type="number"
				   name="<?php echo esc_attr(self::ILJ_META_KEY_LINKSPERPARAGRAPH); ?>"
				   value="<?php echo esc_attr($links_per_paragraph); ?>"
				   style="display:none"/>
			<input type="text"
				   name="<?php echo esc_attr(self::ILJ_META_KEY_LIMITOUTGOINGLINKS); ?>"
				   value="<?php echo esc_attr($limit_outgoing_links); ?>"
				   style="display:none"/>
			<input type="text"
				   name="<?php echo esc_attr(self::ILJ_META_KEY_MAXOUTGOINGLINKS); ?>"
				   value="<?php echo esc_attr($max_outgoing_links); ?>"
				   style="display:none"/>
			<?php
		}
		?>
			<input type="text"
				   name="<?php echo esc_attr(self::ILJ_IS_BLACKLISTED); ?>"
				   value="<?php echo esc_attr(self::isBlacklisted($post->ID, 'post')); ?>"
				   style="display:none"/>

			<input type="text"
				   name="<?php echo esc_attr(self::ILJ_META_KEY_BLACKLISTDEFINITION); ?>"
				   value="<?php echo esc_attr($blacklist_keywords->encoded()); ?>"
				   size="30"
				   style="display:none"/>
					</p>
		<template id="ilj_keyword_metabox_footer">
			<?php
				$content = Content::from_post($post);
				/**
				 * This action is used to render content dynamically in to metabox footer.
				 * The HTML content inside <template> tag will rendered at the footer of editor.
				 *
				 * @param $content Content|null The content, null if its rendered on add post or add term page.
				 * @since 2.23.5
				 */
				do_action(self::ILJ_KEYWORD_METABOX_FOOTER_HOOK, $content);
			?>
		</template>
		<?php
	}

	/**
	 * Hooks in to {@link self::ILJ_KEYWORD_METABOX_FOOTER_HOOK} to add custom html to <template> tag
	 *
	 * @param Content|null $content The content, null if its rendered on add post or add term page.
	 * @return void
	 */
	public static function render_keyword_metabox_footer($content) {
		?>
		<div class="ilj-row">
			<div class="col-12 ilj-footer">
				<a href="https://internallinkjuicer.com/docs/editor/?utm_source=editor&utm_medium=help&utm_campaign=plugin"
				   rel="noopener" target="_blank" class="help">
					<span class="dashicons dashicons-editor-help"></span>
					<?php esc_html_e('Nhận trợ giúp', 'internal-links'); ?>
				</a>
				<?php self::render_delete_cache_button($content); ?>
			</div>
		</div>
		<?php
	}

	/**
	 * Renders delete cache button inside metabox.
	 *
	 * @param Content|null $content The content, null if its rendered on add post or add term page.
	 * @return void
	 */
	private static function render_delete_cache_button($content) {
		if (!$content) {
			return;
		}
		$link = admin_url(
			sprintf( 'admin-ajax.php?action=%s&_wpnonce=%s&ilj_transient_id=%d&ilj_transient_type=%s&ilj_skip_notice=true',
				'ilj_clear_single_transient',
				wp_create_nonce('ilj_clear_single_transient'),
				$content->get_id(),
				$content->get_type()
			)
		);
		$cache_option = Options::getOption(CacheToggleBtnSwitch::getKey());
		if ($cache_option) {
		?>
		<div class="ilj-delete-cache-container">
			<button class="ilj-button-danger button" id="ilj-delete-cache" type="button" data-ilj-delete-cache-url="<?php echo esc_attr($link); ?>">
				<?php esc_html_e('Xóa bộ nhớ đệm', 'internal-links'); ?>
			</button>
			<span class="spinner is-active ilj-spinner ilj-hidden"></span>
		</div>
		<?php
		}
	}

	/**
	 * Responsible for saving keyword meta values and
	 * stores limit linking settings for posts and
	 * stores limit linking settings for posts
	 *
	 * @since 1.0.0
	 *
	 * @param  int      $post_id The ID of the post
	 * @param  \WP_Post $post    The post object
	 * @return void
	 */
	public static function saveKeywordMeta($post_id, \WP_Post $post) {
		if (is_null($post_id) || is_null($post)) {
			return;
		}

		if (!isset($_POST[self::ILJ_ADMINVIEW_NONCE]) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST[self::ILJ_ADMINVIEW_NONCE])), basename(__FILE__))
		) {
			return $post_id;
		}

		$post_type = get_post_type_object($post->post_type);

		if (!current_user_can($post_type->cap->edit_post, $post_id)) {
			return $post_id;
		}

		if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			self::saveLimitIncomingLinksMeta__premium_only($post_id, $_POST);
			self::save_limit_outgoing_links_meta__premium_only($post_id, $_POST);

			if (array_key_exists(self::ILJ_META_KEY_LIMITLINKSPERPARAGRAPH, $_POST)) {
				$sanitized_limit_links_per_paragraph_meta_value = sanitize_text_field(wp_unslash($_POST[self::ILJ_META_KEY_LIMITLINKSPERPARAGRAPH]));

				update_post_meta(
					$post_id,
					self::ILJ_META_KEY_LIMITLINKSPERPARAGRAPH,
					$sanitized_limit_links_per_paragraph_meta_value
				);
			}
			if (array_key_exists(self::ILJ_META_KEY_LINKSPERPARAGRAPH, $_POST)) {
				$sanitized_links_per_paragraph_meta_value = sanitize_text_field(wp_unslash($_POST[self::ILJ_META_KEY_LINKSPERPARAGRAPH]));

				update_post_meta(
					$post_id,
					self::ILJ_META_KEY_LINKSPERPARAGRAPH,
					$sanitized_links_per_paragraph_meta_value
				);
			}
		}

		if (array_key_exists(self::ILJ_META_KEY_BLACKLISTDEFINITION, $_POST)) {
			$sanitized_blacklist_meta_value = sanitize_text_field(wp_unslash($_POST[self::ILJ_META_KEY_BLACKLISTDEFINITION]));
			$keywordsblacklist              = KeywordList::fromInput($sanitized_blacklist_meta_value);

			if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
				update_post_meta(
					$post_id,
					self::ILJ_META_KEY_BLACKLISTDEFINITION,
					$keywordsblacklist->getKeywords()
				);
			} else {
				update_post_meta(
					$post_id,
					self::ILJ_META_KEY_BLACKLISTDEFINITION,
					array_slice($keywordsblacklist->getKeywords(), 0, 2)
				);
			}
		}

		if (array_key_exists(self::ILJ_IS_BLACKLISTED, $_POST) && true == $_POST[self::ILJ_IS_BLACKLISTED]) {
			self::addToBlacklist($post_id, 'post');
		} else {
			self::removeFromBlacklist($post_id, 'post');
		}

		if (array_key_exists(Postmeta::ILJ_META_KEY_LINKDEFINITION . '_keys', $_POST)) {

			$sanitized_meta_value = sanitize_text_field(wp_unslash($_POST[Postmeta::ILJ_META_KEY_LINKDEFINITION . '_keys']));
			$keywords             = KeywordList::fromInput($sanitized_meta_value);

			// Retrieve the old keywords before updating
			$old_keyword_list = KeywordList::fromMeta($post_id, 'post', Postmeta::ILJ_META_KEY_LINKDEFINITION);
			$old_keyword_count = $old_keyword_list->getCount();
			$update_status = self::set_keywords($post_id, $keywords);

			/**
			 * Fires after keyword meta got saved
			 *
			 * @since 1.0.0
			 */
			if (true == $update_status) {
				$post_id       = isset($_POST['post_ID']) ? intval($_POST['post_ID']) : 0;
				$post_status   = isset($_POST['post_status']) ? sanitize_text_field(wp_unslash($_POST['post_status'])) : '';
				$keyword_list  = KeywordList::fromMeta($post_id, 'post', Postmeta::ILJ_META_KEY_LINKDEFINITION);
				$keyword_count = $keyword_list->getCount();
				if ($old_keyword_count > 0 && 0 == $keyword_count) {
					Linkindex::delete_link_to($post_id, 'post');
					Statistic::updateStatisticsInfo();
				} elseif ($keyword_count > 0) {
					do_action(self::ILJ_ACTION_AFTER_KEYWORDS_UPDATE, $post_id, 'post', $post_status);
				}
			}
		}

	}

	/**
	 * Set keywords for a post id, returns boolean or int based on the value.
	 *
	 * @param int         $post_id  The post id.
	 * @param KeywordList $keywords The keyword list for post.
	 *
	 * @return bool|int
	 */
	public static function set_keywords($post_id, $keywords) {
		$prev_value = get_post_meta($post_id, Postmeta::ILJ_META_KEY_LINKDEFINITION, true);
		return update_post_meta(
			$post_id,
			Postmeta::ILJ_META_KEY_LINKDEFINITION,
			$keywords->getKeywords(),
			$prev_value
		);
	}

	/**
	 * Logic for adding the assets based on subscription
	 *
	 * @since 1.1.0
	 *
	 * @return void
	 */
	public static function addAssets() {
		$required_role = 'administrator';

		if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			$required_role = Capabilities::mapRoleToCapability(Options::getOption(\ILJ\Core\Options\EditorRole::getKey()));
		}

		if (!current_user_can($required_role)) {
			return;
		}

		global $pagenow;

		if (in_array($pagenow, array('post-new.php', 'post.php'))) {

			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- It gets the post type on the add/edit post admin dashboard page. No nonce verification needed.
			if (!isset($_GET['post_type'])) {
				self::registerAssets();
				return;
			}

			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- It gets the post type on the add/edit post admin dashboard page. No nonce verification needed.
			$post_type = get_post_type_object(sanitize_text_field(wp_unslash($_GET['post_type'])));

			if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
				if (\ILJ\Posttypes\CustomLinks::ILJ_POSTTYPE_CUSTOM_LINKS_SLUG == $post_type->name) {
					self::registerAssets();
					return;
				}
			}

			if (!$post_type || !$post_type->public) {
				return;
			}

			self::registerAssets();
		}

		if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- It gets the taxonomy on the add/edit taxonomy admin dashboard page. No nonce verification needed.
			if (('term.php' === $pagenow || 'edit-tags.php' === $pagenow) && isset($_GET['taxonomy'])) {
				// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- It gets the taxonomy on the add/edit taxonomy admin dashboard page. No nonce verification needed.
				$taxonomy = get_taxonomy(sanitize_text_field(wp_unslash($_GET['taxonomy'])));

				if ($taxonomy && $taxonomy->public) {
					self::registerAssets();
				}
			}
		}
	}

	/**
	 * Registering the assets for editor frontend
	 *
	 * @since 1.1.0
	 *
	 * @return void
	 */
	private static function registerAssets() {
		add_action(
			'admin_enqueue_scripts',
			function () {
				\ILJ\Helper\Loader::enqueue_script('jquery-ui-sortable');
				\ILJ\Helper\Loader::register_script(Editor::ILJ_KEYWORDS_HANDLE, ILJ_URL . 'admin/js/ilj_keywords.js', array(), ILJ_VERSION . '.' . time());
				\ILJ\Helper\Loader::register_script(Editor::ILJ_EDITOR_HANDLE, ILJ_URL . 'admin/js/ilj_editor.js', array(), ILJ_VERSION . '.' . time());
				\ILJ\Helper\Loader::register_script(Editor::ILJ_MODAL, ILJ_URL . 'admin/js/ilj_modal.js', array(), ILJ_VERSION . '.' . time());
				wp_localize_script(Editor::ILJ_EDITOR_HANDLE, 'ilj_editor_duplicate', array(
					'nonce' => wp_create_nonce('ilj-editor-action'),
				));
				wp_localize_script(Editor::ILJ_EDITOR_HANDLE, 'ilj_editor_translation', array_merge(
					Editor::getTranslation(),
					array(
						'nonce' => wp_create_nonce('render-keyword-meta-box-nonce'),
						'has_gemini_key' => (
							\ILJ\Core\Options::getOption(\ILJ\Core\Options\AiSource::getKey()) === 'vertex_ai_agent'
								? !empty(\ILJ\Core\Options::getOption(\ILJ\Core\Options\VertexJsonPath::getKey())) && !empty(\ILJ\Core\Options::getOption(\ILJ\Core\Options\VertexAgentId::getKey()))
								: (\ILJ\Core\Options::getOption(\ILJ\Core\Options\AiSource::getKey()) === 'vertex_ai_api'
									? !empty(\ILJ\Core\Options::getOption(\ILJ\Core\Options\VertexJsonPath::getKey()))
									: (\ILJ\Core\Options::getOption(\ILJ\Core\Options\AiSource::getKey()) === 'ckey'
										? !empty(\ILJ\Core\Options::getOption(\ILJ\Core\Options\CkeyKey::getKey()))
										: (\ILJ\Core\Options::getOption(\ILJ\Core\Options\AiSource::getKey()) === 'cliproxy'
											? !empty(\ILJ\Core\Options::getOption(\ILJ\Core\Options\CliproxyKey::getKey()))
											: !empty(\ILJ\Core\Options::getOption(\ILJ\Core\Options\GeminiKey::getKey()))
										)
									)
								)
						),
						'ai_overwrite_focus_keywords' => \ILJ\Core\Options::getOption(\ILJ\Core\Options\AiOverwriteFocusKeywords::getKey())
					)
				));
				wp_add_inline_script(Editor::ILJ_EDITOR_HANDLE, 'const ilj_editor_basic_restriction = ' . wp_json_encode(Editor::getBasicRestrictions()), 'before');
				\ILJ\Helper\Loader::enqueue_script('ilj_tipso', ILJ_URL . 'admin/js/tipso.js', array(), ILJ_VERSION);
				\ILJ\Helper\Loader::enqueue_script(Editor::ILJ_KEYWORDS_HANDLE);
				\ILJ\Helper\Loader::enqueue_script(Editor::ILJ_EDITOR_HANDLE);
				\ILJ\Helper\Loader::enqueue_script(Editor::ILJ_MODAL);
				\ILJ\Helper\Loader::enqueue_style('ilj_tipso', ILJ_URL . 'admin/css/tipso.css', array(), ILJ_VERSION);
				\ILJ\Helper\Loader::enqueue_style(Editor::ILJ_EDITOR_HANDLE, ILJ_URL . 'admin/css/ilj_editor.css', array(), ILJ_VERSION);
				\ILJ\Helper\Loader::enqueue_style(Editor::ILJ_EDITOR_HANDLE, ILJ_URL . 'admin/css/ilj_modal.css', array(), ILJ_VERSION);
				\ILJ\Helper\Loader::enqueue_style('ilj_ui', ILJ_URL . 'admin/css/ilj_ui.css', array(), ILJ_VERSION);
			},
			10,
			1
		);

	}

	/**
	 * Returns the frontend translation
	 *
	 * @since 1.0.1
	 *
	 * @return array
	 */
	public static function getTranslation() {
		$translation = array(
			'add_keyword'                               => __('Thêm từ khóa', 'internal-links'),
			'placeholder_keyword'                       => __('Từ khóa', 'internal-links'),
			'howto_case'                                => __('Từ khóa được sử dụng <strong>không phân biệt chữ hoa chữ thường</strong>', 'internal-links'),
			'howto_keyword'                             => __('Phân tách nhiều từ khóa bằng dấu phẩy', 'internal-links'),
			'howto_gap'                                 => __('Định cấu hình kích thước khoảng cách.', 'internal-links') . ' ' . __('Nó thể hiện số lượng từ khóa xuất hiện linh hoạt giữa các từ khóa khác của bạn.', 'internal-links') . ' ' . __('Tìm hiểu thêm trong tài liệu của chúng tôi:', 'internal-links') . '<br><strong><a target="_blank" rel="noopener" href="' . Help::getLinkUrl('editor/', 'gaps', 'gap help', 'editor') . '">' . __('Bấm vào đây để mở', 'internal-links') . '</a></strong>',
			'headline_gaps'                             => __('Khoảng trống từ khóa', 'internal-links'),
			'add_gap'                                   => __('Thêm khoảng cách', 'internal-links'),
			'gap_type'                                  => __('Loại khoảng cách', 'internal-links'),
			'type_min'                                  => __('tối thiểu', 'internal-links'),
			'type_exact'                                => __('Chính xác', 'internal-links'),
			'type_max'                                  => __('Tối đa', 'internal-links'),
			'howto_gap_min'                             => __('Số lượng từ khóa tối thiểu trong khoảng trống.', 'internal-links') . ' ' . __('Không có giới hạn trên.', 'internal-links'),
			'howto_gap_exact'                           => __('Số lượng từ khóa chính xác trong khoảng trống.', 'internal-links'),
			'howto_gap_max'                             => __('Số lượng từ khóa tối đa trong khoảng trống.', 'internal-links'),
			'howto_links_per_paragraph'                 => __('Ghi đè cài đặt chung cho nội dung hiện tại.', 'internal-links'),
			'howto_add_to_blacklist'                    => __('Chuyển đổi để thêm/xóa khỏi danh sách đen toàn cầu.', 'internal-links'),
			'howto_limit_incoming_links'                => __('Chuyển đổi để thêm/xóa giới hạn liên kết đến.', 'internal-links'),
			'howto_limit_outgoing_links'                => __('Chuyển đổi để thêm/xóa giới hạn liên kết gửi đi.', 'internal-links'),
			'insert_gaps'                               => __('Chèn khoảng cách giữa các từ khóa', 'internal-links'),
			'headline_configured_keywords'              => __('Từ khóa được định cấu hình', 'internal-links'),
			'message_keyword_exists'                    => __('Từ khóa này đã tồn tại.', 'internal-links'),
			'message_no_keyword'                        => __('Không có từ khóa được xác định.', 'internal-links'),
			'message_length_not_valid'                  => __('Độ dài của từ khóa đã cho không hợp lệ.', 'internal-links'),
			'message_multiple_placeholder'              => __('Nhiều phần giữ chỗ liên tiếp không được phép.', 'internal-links'),
			'no_keywords'                               => __('Không có từ khóa nào được định cấu hình.', 'internal-links'),
			'gap_hover_exact'                           => __('Khoảng cách từ khóa chính xác:', 'internal-links'),
			'gap_hover_max'                             => __('Khoảng cách từ khóa tối đa:', 'internal-links'),
			'gap_hover_min'                             => __('Khoảng cách từ khóa tối thiểu:', 'internal-links'),
			'limit_incoming_links'                      => __('Giới hạn các liên kết đến:', 'internal-links'),
			'max_incoming_links'                        => __('Liên kết đến tối đa:', 'internal-links'),
			'blacklist_incoming_links'                  => __('Từ khóa không được liên kết trong nội dung hiện tại:', 'internal-links'),
			'message_limited_blacklist_keyword'         => __('Với phiên bản Basic miễn phí của Iternal Link Juicer, bạn có thể chặn 2 từ khóa được liên kết.', 'internal-links'),
			'message_limited_blacklist_keyword_upgrade' => sprintf('&raquo; <a href="%s">', get_admin_url(null, 'admin.php?page=' . AdminMenu::ILJ_MENUPAGE_SLUG . '-pricing')) . __('Nâng cấp lên Pro và thêm từ khóa không giới hạn', 'internal-links') . '</a>',
			'headline_configured_keywords_blacklist'    => __('Danh sách đen từ khóa được cấu hình:', 'internal-links'),
			'is_blacklisted'                            => __('Nằm trong danh sách đen toàn cầu:', 'internal-links'),
			'limit_links_per_paragraph'                 => __('Giới hạn liên kết trên mỗi đoạn:', 'internal-links'),
			'max_links_per_paragraph'                   => __('Số liên kết tối đa trên mỗi đoạn:', 'internal-links'),
			'limit_outgoing_links'                      => __('Giới hạn các liên kết đi:', 'internal-links'),
			'max_outgoing_links'                        => __('Liên kết đi tối đa:', 'internal-links'),
			'cache_cleared' 							=> __('Đã xóa bộ nhớ đệm.', 'internal-links'),
			'upgrade_to_pro_button_text' 				=> __('Nâng cấp lên Pro', 'internal-links'),
			'upgrade_to_pro_link'						=> get_admin_url(null, 'admin.php?billing_cycle=annual&trial=true&page=' . AdminMenu::ILJ_MENUPAGE_SLUG . '-pricing'),
			'pro_feature_title'							=> __('Đây là một tính năng PRO.', 'internal-links'),
			'keyword_duplicate_title'					=> __('Từ khóa trùng lặp cho:', 'internal-links')
		);
		return $translation;
	}

	/**
	 * Sets Basic version restrictions
	 *
	 * @version 1.2.15
	 *
	 * @return array
	 */
	protected static function getBasicRestrictions() {
		$current_screen     = get_current_screen();
		$basic_restrictions = array(
			'blacklist_limit' => 2,
			'is_active'       => true,
			'disable_title'   => 'class="pro-title"',
			'disable_setting' => 'pro-setting',
			'disabled'        => 'disabled',
			'lock_icon'       => '<span class="dashicons dashicons-lock tip" title="' . __('Tính năng này là một phần của phiên bản Pro', 'internal-links') . '"></span>',
			'current_screen'  => $current_screen->post_type,
		);

		if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			$basic_restrictions['is_active']       = false;
			$basic_restrictions['disable_title']   = '';
			$basic_restrictions['disable_setting'] = '';
			$basic_restrictions['disabled']        = '';
			$basic_restrictions['lock_icon']       = '';
		}

		return $basic_restrictions;
	}

	/**
	 * [PRO] Renders the editor metabox on term editing screen
	 *
	 * @since 1.0.1
	 *
	 * @param        \WP_Term|null $tax     The current term, null when its rendered on create term screen
	 * @param        string        $context The context in which this metabox is rendered. Currently, it is rendered on two screens: the create and edit term screens. Possible values are 'edit' and 'create'.
	 * @return void
	 */
	public static function render_keyword_meta_box_taxonomy__premium_only($tax, $context = 'edit') {
		$is_valid_term = $tax instanceof \WP_Term;
		$keyword_list = $is_valid_term ? KeywordList::fromMeta($tax->term_id, 'term', Postmeta::ILJ_META_KEY_LINKDEFINITION) : KeywordList::empty();
		$blacklist_keywords = $is_valid_term ? KeywordList::fromMeta($tax->term_id, 'term', self::ILJ_META_KEY_BLACKLISTDEFINITION) : KeywordList::empty();
		wp_nonce_field(basename(__FILE__), self::ILJ_ADMINVIEW_NONCE);
		?>
		<table class="form-table" data-ilj-screen-context="term_<?php echo esc_attr($context); ?>">
			<tr class="form-field term-meta-text-wrap"
				id="<?php echo esc_attr(Postmeta::ILJ_META_KEY_LINKDEFINITION); ?>">
				<th scope="row">
					<label for="<?php echo esc_attr(Postmeta::ILJ_META_KEY_LINKDEFINITION . '_keys'); ?>"><?php esc_html_e('Liên kết nội bộ', 'internal-links'); ?></label>
				</th>
				<td>
					<div class="inside box">
						<input type="text"
							   name="<?php echo esc_attr(Postmeta::ILJ_META_KEY_LINKDEFINITION . '_keys'); ?>"
							   value="<?php echo esc_attr($keyword_list->encoded()); ?>"
							   size="30"/>
						<?php
						if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
							$limit_links = $max_limit_links = $limit_links_per_paragraph = $links_per_paragraph = $limit_outgoing_links = $max_outgoing_links = '';
							if ($is_valid_term) {
								$limit_links               = get_term_meta($tax->term_id, self::ILJ_META_KEY_LIMITINCOMINGLINKS, true);
								$max_limit_links           = get_term_meta($tax->term_id, self::ILJ_META_KEY_MAXINCOMINGLINKS, true);
								$limit_links_per_paragraph = get_term_meta($tax->term_id, self::ILJ_META_KEY_LIMITLINKSPERPARAGRAPH, true);
								$links_per_paragraph       = get_term_meta($tax->term_id, self::ILJ_META_KEY_LINKSPERPARAGRAPH, true);
								$limit_outgoing_links      = get_term_meta($tax->term_id, self::ILJ_META_KEY_LIMITOUTGOINGLINKS, true);
								$max_outgoing_links        = get_term_meta($tax->term_id, self::ILJ_META_KEY_MAXOUTGOINGLINKS, true);
							}
							?>
							<input type="text"
								   name="<?php echo esc_attr(self::ILJ_META_KEY_LIMITINCOMINGLINKS); ?>"
								   value="<?php echo esc_attr($limit_links); ?>"
								   size="30"
								   style="display:none"/>
							<input type="text"
								   name="<?php echo esc_attr(self::ILJ_META_KEY_MAXINCOMINGLINKS); ?>"
								   value="<?php echo esc_attr($max_limit_links); ?>"
								   size="30"
								   style="display:none"/>
							<input type="number"
								   name="<?php echo esc_attr(self::ILJ_META_KEY_LIMITLINKSPERPARAGRAPH); ?>"
								   value="<?php echo esc_attr($limit_links_per_paragraph); ?>"
								   style="display:none"/>
							<input type="number"
								   name="<?php echo esc_attr(self::ILJ_META_KEY_LINKSPERPARAGRAPH); ?>"
								   value="<?php echo esc_attr($links_per_paragraph); ?>"
								   style="display:none"/>
							<input type="text"
								   name="<?php echo esc_attr(self::ILJ_META_KEY_LIMITOUTGOINGLINKS); ?>"
								   value="<?php echo esc_attr($limit_outgoing_links); ?>"
								   style="display:none"/>
							<input type="text"
								   name="<?php echo esc_attr(self::ILJ_META_KEY_MAXOUTGOINGLINKS); ?>"
								   value="<?php echo esc_attr($max_outgoing_links); ?>"
								   style="display:none"/>
							<?php
						}
						?>
						<?php $is_blacklisted = $is_valid_term ? self::isBlacklisted($tax->term_id, 'term') : false; ?>
						<input type="text"
							   name="<?php echo esc_attr(self::ILJ_IS_BLACKLISTED); ?>"
							   value="<?php echo esc_attr($is_blacklisted); ?>"
							   style="display:none"/>
						<input type="text"
							   name="<?php echo esc_attr(self::ILJ_META_KEY_BLACKLISTDEFINITION); ?>"
							   value="<?php echo esc_attr($blacklist_keywords->encoded()); ?>"
							   size="30"
							   style="display:none"/>
					</div>
				</td>
			</tr>
		</table>
		<template id="ilj_keyword_metabox_footer">
			<?php
			/**
			 * This action is used to render content dynamically in to metabox footer.
			 * The HTML content inside <template> tag will be rendered at the footer of editor.
			 *
			 * @param $content Content|null The content, null if its rendered on add post or add term page.
			 * @since 2.23.5
			 */
			do_action(self::ILJ_KEYWORD_METABOX_FOOTER_HOOK, $is_valid_term ? Content::from_term($tax) : null);
			?>
		</template>
		<?php
	}

	/**
	 * Stores the configured keywords in the meta data of a saved term and
	 * Stores limit linking settings
	 *
	 * @since 1.0.1
	 *
	 * @param  int $term_id The id of the term that gets saved
	 * @return void
	 */
	public static function save_keyword_meta_taxonomy__premium_only($term_id) {
		if (!isset($_POST[self::ILJ_ADMINVIEW_NONCE]) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST[self::ILJ_ADMINVIEW_NONCE])), basename(__FILE__))) {
			return;
		}
		if (is_null($term_id)) {
			return;
		}
		if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			self::saveLimitIncomingLinkMetaTaxonomy__premium_only($term_id);
			self::save_limit_outgoing_links_meta_taxonomy__premium_only($term_id);
			
			$prev_value_limit_links_per_paragraph = get_term_meta($term_id, self::ILJ_META_KEY_LIMITLINKSPERPARAGRAPH, true);
			if (array_key_exists(self::ILJ_META_KEY_LIMITLINKSPERPARAGRAPH, $_POST)) {
				$sanitized_limit_links_per_paragraph_meta_value = sanitize_text_field(wp_unslash($_POST[self::ILJ_META_KEY_LIMITLINKSPERPARAGRAPH]));

				update_term_meta(
					$term_id,
					self::ILJ_META_KEY_LIMITLINKSPERPARAGRAPH,
					$sanitized_limit_links_per_paragraph_meta_value,
					$prev_value_limit_links_per_paragraph
				);
			}

			$prev_value_links_per_paragraph = get_term_meta($term_id, self::ILJ_META_KEY_LINKSPERPARAGRAPH, true);

			if (array_key_exists(self::ILJ_META_KEY_LINKSPERPARAGRAPH, $_POST)) {
				$sanitized_links_per_paragraph_meta_value = sanitize_text_field(wp_unslash($_POST[self::ILJ_META_KEY_LINKSPERPARAGRAPH]));

				update_term_meta(
					$term_id,
					self::ILJ_META_KEY_LINKSPERPARAGRAPH,
					$sanitized_links_per_paragraph_meta_value,
					$prev_value_links_per_paragraph
				);
			}
		}

		$prev_value_blacklist = get_term_meta($term_id, self::ILJ_META_KEY_BLACKLISTDEFINITION, true);
		if (array_key_exists(self::ILJ_META_KEY_BLACKLISTDEFINITION, $_POST)) {
			$sanitized_blacklist_meta_value = sanitize_text_field(wp_unslash($_POST[self::ILJ_META_KEY_BLACKLISTDEFINITION]));
			$blacklist_keywords             = KeywordList::fromInput($sanitized_blacklist_meta_value);

			if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
				update_term_meta($term_id, self::ILJ_META_KEY_BLACKLISTDEFINITION, $blacklist_keywords->getKeywords(), $prev_value_blacklist);
			} else {
				update_term_meta($term_id, self::ILJ_META_KEY_BLACKLISTDEFINITION, array_slice($blacklist_keywords->getKeywords(), 0, 2), $prev_value_blacklist);
			}
		}

		if (array_key_exists(self::ILJ_IS_BLACKLISTED, $_POST) && true == $_POST[self::ILJ_IS_BLACKLISTED]) {
			self::addToBlacklist($term_id, 'term');
		} else {
			self::removeFromBlacklist($term_id, 'term');
		}

		$prev_value = get_term_meta($term_id, Termmeta::ILJ_META_KEY_LINKDEFINITION, true);
		if (array_key_exists(Termmeta::ILJ_META_KEY_LINKDEFINITION . '_keys', $_POST)) {
			$sanitized_meta_value = sanitize_text_field(wp_unslash($_POST[Termmeta::ILJ_META_KEY_LINKDEFINITION . '_keys']));
			$keywords             = KeywordList::fromInput($sanitized_meta_value);

			$old_keyword_list = KeywordList::fromMeta($term_id, 'term', Termmeta::ILJ_META_KEY_LINKDEFINITION);
			$old_keyword_count = $old_keyword_list->getCount();
			$update_status = update_term_meta($term_id, Termmeta::ILJ_META_KEY_LINKDEFINITION, $keywords->getKeywords(), $prev_value);

			/**
			 * Fires after keyword meta got saved
			 *
			 * @since 1.0.1
			 */
			if (true == $update_status) {
				$keyword_list      = KeywordList::fromMeta($term_id, 'term', Termmeta::ILJ_META_KEY_LINKDEFINITION);
				$keyword_count = $keyword_list->getCount();

				if ($old_keyword_count > 0 && 0 == $keyword_count) {
					Linkindex::delete_link_to($term_id, 'term');
					Statistic::updateStatisticsInfo();
				} elseif ($keyword_count > 0) {
					do_action(self::ILJ_ACTION_AFTER_KEYWORDS_UPDATE, $term_id, 'term', 'publish');
				}
			}
		}
	}

	/**
	 * [PRO] Responsible for saving limit incoming meta values
	 *
	 * @since 1.2.15
	 *
	 * @param  int   $post_id   The ID of the post
	 * @param  array $post_data The post request data that got submitted
	 * @return void
	 */
	protected static function saveLimitIncomingLinksMeta__premium_only($post_id, $post_data) {
		if (!array_key_exists(self::ILJ_META_KEY_LIMITINCOMINGLINKS, $post_data)) {
			return;
		}

		$limitlinks    = wp_unslash($post_data[self::ILJ_META_KEY_LIMITINCOMINGLINKS]);
		$maxlimitlinks = wp_unslash($post_data[self::ILJ_META_KEY_MAXINCOMINGLINKS]);
		update_post_meta(
			$post_id,
			self::ILJ_META_KEY_LIMITINCOMINGLINKS,
			$limitlinks
		);

		update_post_meta(
			$post_id,
			self::ILJ_META_KEY_MAXINCOMINGLINKS,
			$maxlimitlinks
		);
	}

	/**
	 * [PRO] Responsible for saving limit outgoing meta values
	 *
	 * @since 2.1.1
	 *
	 * @param  int   $post_id   The ID of the post
	 * @param  array $post_data The post request data that got submitted
	 * @return void
	 */
	protected static function save_limit_outgoing_links_meta__premium_only($post_id, $post_data) {
		if (!array_key_exists(self::ILJ_META_KEY_LIMITOUTGOINGLINKS, $post_data)) {
			return;
		}

		if (array_key_exists(self::ILJ_META_KEY_LIMITOUTGOINGLINKS, $post_data)) {
			$limit_outgoing_links = wp_unslash($post_data[self::ILJ_META_KEY_LIMITOUTGOINGLINKS]);
			update_post_meta(
				$post_id,
				self::ILJ_META_KEY_LIMITOUTGOINGLINKS,
				$limit_outgoing_links
			);
		}

		if (array_key_exists(self::ILJ_META_KEY_MAXOUTGOINGLINKS, $post_data)) {
			$max_outgoing_limit_links = wp_unslash($post_data[self::ILJ_META_KEY_MAXOUTGOINGLINKS]);
			// If the condition is not met, set the value to 1
			$max_outgoing_limit_links = ($max_outgoing_limit_links > 0) ? $max_outgoing_limit_links : 1;

			update_post_meta(
				$post_id,
				self::ILJ_META_KEY_MAXOUTGOINGLINKS,
				$max_outgoing_limit_links
			);
		}
	}

	 /**
	  * [PRO] Stores the limit incoming meta values in the meta data of a saved term
	  *
	  * @since 1.0.1
	  *
	  * @param  int $term_id The id of the term that gets saved
	  * @return void
	  */
	public static function saveLimitIncomingLinkMetaTaxonomy__premium_only($term_id) {
		if (!isset($_POST[self::ILJ_ADMINVIEW_NONCE]) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST[self::ILJ_ADMINVIEW_NONCE])), basename(__FILE__))) {
			return;
		}

		$prev_value_limitlinks    = get_term_meta($term_id, self::ILJ_META_KEY_LIMITINCOMINGLINKS, true);
		$prev_value_maxlimitlinks = get_term_meta($term_id, self::ILJ_META_KEY_MAXINCOMINGLINKS, true);

		if (array_key_exists(self::ILJ_META_KEY_LIMITINCOMINGLINKS, $_POST)) {
			$limitlinks    = sanitize_text_field(wp_unslash($_POST[self::ILJ_META_KEY_LIMITINCOMINGLINKS]));
			$maxlimitlinks = isset($_POST[self::ILJ_META_KEY_MAXINCOMINGLINKS]) ? sanitize_text_field(wp_unslash($_POST[self::ILJ_META_KEY_MAXINCOMINGLINKS])) : '';

			update_term_meta($term_id, self::ILJ_META_KEY_LIMITINCOMINGLINKS, $limitlinks, $prev_value_limitlinks);
			update_term_meta($term_id, self::ILJ_META_KEY_MAXINCOMINGLINKS, $maxlimitlinks, $prev_value_maxlimitlinks);
		}
	}

	/**
	 * [PRO] Responsible for saving limit outgoing meta values
	 *
	 * @since 2.2.23
	 *
	 * @param  int $term_id The ID of the term
	 * @return void
	 */
	protected static function save_limit_outgoing_links_meta_taxonomy__premium_only($term_id) {
		if (!isset($_POST[self::ILJ_ADMINVIEW_NONCE]) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST[self::ILJ_ADMINVIEW_NONCE])), basename(__FILE__))) {
			return;
		}

		if (array_key_exists(self::ILJ_META_KEY_LIMITOUTGOINGLINKS, $_POST)) {
			$limit_outgoing_links = (int) sanitize_text_field(wp_unslash($_POST[self::ILJ_META_KEY_LIMITOUTGOINGLINKS]));
			update_term_meta($term_id, self::ILJ_META_KEY_LIMITOUTGOINGLINKS, $limit_outgoing_links);
		}

		if (array_key_exists(self::ILJ_META_KEY_MAXOUTGOINGLINKS, $_POST)) {
			$max_limit_links = (int) sanitize_text_field(wp_unslash($_POST[self::ILJ_META_KEY_MAXOUTGOINGLINKS]));
			// If the condition is not met, set the value to 1
			$max_limit_links = ($max_limit_links > 0) ? $max_limit_links : 1;
			update_term_meta($term_id, self::ILJ_META_KEY_MAXOUTGOINGLINKS, $max_limit_links);
		}
	}

	/**
	 * Checks if an asset is on the blacklist
	 *
	 * @since 1.2.15
	 *
	 * @param  int    $id   The asset ID
	 * @param  string $type The asset type
	 * @return bool True if blacklisted , false if not
	 */
	public static function isBlacklisted($id, $type) {
		if ('post' == $type) {
			$postBlacklist = Options::getOption(\ILJ\Core\Options\Blacklist::getKey());
			$blacklisted   = false;
			if (is_array($postBlacklist)) {
				if (in_array($id, $postBlacklist)) {
					$blacklisted = true;
				}
			}
			return $blacklisted;
		}

		if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			if ('term' == $type) {
				$termBlacklist = Options::getOption(\ILJ\Core\Options\TermBlacklist::getKey());
				$blacklisted   = false;
				if (is_array($termBlacklist)) {
					if (in_array($id, $termBlacklist)) {
						$blacklisted = true;
					}
				}
				return $blacklisted;
			}
		}

		return false;
	}

	/**
	 * Removes an asset from blacklist
	 *
	 * @since 1.2.15
	 *
	 * @param  int    $id   The asset id
	 * @param  string $type The asset type
	 * @return void
	 */
	protected static function removeFromBlacklist($id, $type) {
		$blacklist = array();

		if ('post' == $type) {
			$blacklist = Options::getOption(\ILJ\Core\Options\Blacklist::getKey());
		}

		if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			if ('term' == $type) {
				$blacklist = Options::getOption(\ILJ\Core\Options\TermBlacklist::getKey());
			}
		}

		$blacklist = is_array($blacklist) ? $blacklist : array();

		if (($key = array_search($id, $blacklist)) !== false) {
			unset($blacklist[$key]);
		} else {
			return;
		}

		if ('post' == $type) {
			Options::setOption(\ILJ\Core\Options\Blacklist::getKey(), $blacklist);
		}

		if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			if ('term' == $type) {
				Options::setOption(\ILJ\Core\Options\TermBlacklist::getKey(), $blacklist);
			}
		}
	}

	/**
	 * Adds ID to Blacklist Option of post/terms
	 *
	 * @since 1.2.15
	 *
	 * @param  int    $id   The asset id
	 * @param  string $type The asset type
	 * @return void
	 */
	protected static function addToBlacklist($id, $type) {
		$blacklist = array();

		if ('post' == $type) {
			$blacklist = Options::getOption(\ILJ\Core\Options\Blacklist::getKey());
		}

		if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			if ('term' == $type) {
				$blacklist = Options::getOption(\ILJ\Core\Options\TermBlacklist::getKey());
			}
		}

		$blacklist = is_array($blacklist) ? $blacklist : array();

		if (in_array($id, $blacklist)) {
			return;
		}

		$blacklist[] = $id;

		if ('post' == $type) {
			Options::setOption(\ILJ\Core\Options\Blacklist::getKey(), $blacklist);
		}

		if (\ILJ\ilj_fs()->can_use_premium_code__premium_only()) {
			if ('term' == $type) {
				Options::setOption(\ILJ\Core\Options\TermBlacklist::getKey(), $blacklist);
			}
		}
	}
	
	/**
	 * Ajax callback that reset keyword meta box for terms
	 *
	 * @return void
	 */
	public static function render_keyword_meta_box_callback() {
		if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'render-keyword-meta-box-nonce')) {
			die();
		}
		if (!current_user_can('manage_options')) {
			return;
		}
		ob_start();
		self::render_keyword_meta_box_taxonomy__premium_only(null, 'create');
		$output = ob_get_clean();

		wp_send_json_success($output);
	}
}
